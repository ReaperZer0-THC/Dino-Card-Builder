﻿using ARKBreedingStats.Library;
using ARKBreedingStats.species;
using ARKBreedingStats.SpeciesImages;
using ARKBreedingStats.utils;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ARKBreedingStats.values;
using static ARKBreedingStats.InfoGraphic.InfoGraphicSettings;
using Brush = System.Drawing.Brush;
using Brushes = System.Drawing.Brushes;
using Color = System.Drawing.Color;
using Pen = System.Drawing.Pen;
using PixelFormat = System.Drawing.Imaging.PixelFormat;

namespace ARKBreedingStats.InfoGraphic
{
    public static class CreatureInfoGraphic
    {
        /// <summary>
        /// Creates an image with infos about the creature, using the user settings.
        /// </summary>
        /// <param name="cc">CreatureCollection for server settings.</param>
        public static Task<Bitmap> InfoGraphicAsync(this Creature creature, CreatureCollection cc) =>
            creature.InfoGraphicAsync(cc,
                new InfoGraphicSettings
                {
                    infoGraphicHeight = Properties.Settings.Default.InfoGraphicHeight,
                    fontName = GetUserFont(),
                    foreColor = Properties.Settings.Default.InfoGraphicForeColor,
                    backColor = Properties.Settings.Default.InfoGraphicBackColor,
                    borderColor = Properties.Settings.Default.InfoGraphicBorderColor,
                    borderWidth = Properties.Settings.Default.InfoGraphicBorderWidth,
                    borderRadius = Properties.Settings.Default.InfoGraphicBorderRadius,
                    Padding = Properties.Settings.Default.InfoGraphicPadding,
                    colorOutlineText = Properties.Settings.Default.InfoGraphicTextOutlineColor,
                    widthOutlineText = Properties.Settings.Default.InfoGraphicTextOutlineWidth,
                    displayCreatureName = Properties.Settings.Default.InfoGraphicDisplayName,
                    displayWithDomLevels = Properties.Settings.Default.InfoGraphicWithDomLevels,
                    displaySumWildMutLevels = Properties.Settings.Default.InfoGraphicDisplaySumWildMut,
                    displayMutations = Properties.Settings.Default.InfoGraphicDisplayMutations,
                    displayGenerations = Properties.Settings.Default.InfoGraphicDisplayGeneration,
                    displayStatValues = Properties.Settings.Default.InfoGraphicShowStatValues,
                    displayMaxWildLevel = Properties.Settings.Default.InfoGraphicShowMaxWildLevel,
                    displayExtraRegionNames = Properties.Settings.Default.InfoGraphicExtraRegionNames,
                    displayRegionNamesIfNoImage = Properties.Settings.Default.InfoGraphicShowRegionNamesIfNoImage,
                    colorOutlineCreature = Properties.Settings.Default.InfoGraphicCreatureOutlineColor,
                    backgroundImagePath = Properties.Settings.Default.InfoGraphicBackgroundImagePath,
                    BackgroundImageResizing = Properties.Settings.Default.InfoGraphicBackgroundSizing,
                    widthOutlineCreature = Properties.Settings.Default.InfoGraphicCreatureOutlineWidth,
                    creatureOutlineBlurring = Properties.Settings.Default.InfoGraphicCreatureOutlineBlurring,
                    creatureScaling = Properties.Settings.Default.InfoGraphicCreatureScaling,
                    ColorBasedOnCreature = Properties.Settings.Default.InfographicColorByCreature,
                    TintBackgroundImage = Properties.Settings.Default.InfographicTintBackgroundImage
                });

        /// <summary>
        /// Gets user set font. If not font is set, Arial is set.
        /// </summary>
        /// <returns></returns>
        private static string GetUserFont()
        {
            var fontName = Properties.Settings.Default.InfoGraphicFontName;
            if (string.IsNullOrWhiteSpace(fontName))
            {
                fontName = "Arial";
                Properties.Settings.Default.InfoGraphicFontName = fontName;
            }
            return fontName;
        }

        /// <summary>
        /// Creates an image with infos about the creature.
        /// </summary>
        /// <param name="cc">CreatureCollection for server settings.</param>
        public static async Task<Bitmap> InfoGraphicAsync(this Creature creature, CreatureCollection cc, InfoGraphicSettings settings)
        {
            if (creature?.Species == null) return null;
            var secondaryCulture = Loc.UseSecondaryCulture;
            var maxGraphLevel = cc?.maxChartLevel ?? 0;
            if (maxGraphLevel < 1) maxGraphLevel = 50;
            settings.Padding ??= [3, 3, 3, 3];

            var borderAndPaddings = new int[] { settings.borderWidth + settings.Padding[0], settings.borderWidth + settings.Padding[1], settings.borderWidth + settings.Padding[2], settings.borderWidth + settings.Padding[3] }; // top, right, bottom, left
            var heightBox = settings.infoGraphicHeight < 5 ? 180 : settings.infoGraphicHeight; // 180
            var contentHeight = heightBox - borderAndPaddings[0] - borderAndPaddings[2];
            var contentWidth = contentHeight * 2;
            var widthBox = contentWidth + borderAndPaddings[3] + borderAndPaddings[1] + 8; // 360
            if (settings.displayExtraRegionNames)
                widthBox += contentHeight / 2;

            var fontSize = Math.Max(5, contentHeight / 18); // 10
            var fontSizeSmall = Math.Max(5, contentHeight * 2 / 45); // 8
            var fontSizeHeader = Math.Max(5, contentHeight / 15); // 12

            var statLineHeight = contentHeight * 5 / 59; // 15

            var widthImage = widthBox;
            var heightImage = heightBox;
            var yOffsetBox = 0;
            if (settings.creatureScaling > 1)
            {
                widthImage = (int)(widthImage * 0.5 * (1 + settings.creatureScaling));
                var enlargedBy = widthImage - widthBox;
                heightImage += enlargedBy;
                yOffsetBox = (int)(0.8 * enlargedBy);
            }

            var mainColor = settings.TintBackgroundImage || settings.ColorBasedOnCreature ? GetMainColor(creature) : Color.Black;
            var colorHue = (int)mainColor.GetHue();
            Color foreColor, backColor, colorOutlineText, borderColor;
            if (settings.ColorBasedOnCreature)
            {
                foreColor = Utils.AdjustColorLight(Utils.ColorFromHsv(colorHue, mainColor.GetSaturation(), settings.foreColor.GetValue(), settings.foreColor.A), 2 * settings.foreColor.GetBrightness() - 1);
                colorOutlineText = Utils.AdjustColorLight(Utils.ColorFromHsv(colorHue, mainColor.GetSaturation(), settings.colorOutlineText.GetValue(), settings.colorOutlineText.A), 2 * settings.colorOutlineText.GetBrightness() - 1);
                backColor = Utils.AdjustColorLight(Utils.ColorFromHsv(colorHue, mainColor.GetSaturation(), settings.backColor.GetValue(), settings.backColor.A), 2 * settings.backColor.GetBrightness() - 1);
                borderColor = Utils.AdjustColorLight(Utils.ColorFromHsv(colorHue, mainColor.GetSaturation(), settings.borderColor.GetValue(), settings.borderColor.A), 2 * settings.borderColor.GetBrightness() - 1);
            }
            else
            {
                foreColor = settings.foreColor;
                backColor = settings.backColor;
                colorOutlineText = settings.colorOutlineText;
                borderColor = settings.borderColor;
            }

            var bmp = new Bitmap(widthImage, heightImage);
            using (var g = Graphics.FromImage(bmp))
            using (var font = new Font(settings.fontName, fontSize))
            using (var fontSmall = new Font(settings.fontName, fontSizeSmall))
            using (var fontHeader = new Font(settings.fontName, fontSizeHeader, FontStyle.Bold))
            using (var fontBrush = new SolidBrush(foreColor))
            using (var penOutline = new Pen(colorOutlineText, settings.widthOutlineText * 2 + 1) { LineJoin = LineJoin.Round })
            using (var borderAroundColors = new Pen(Utils.ForeColor(backColor), 1))
            using (var stringFormatRight = new StringFormat { Alignment = StringAlignment.Far })
            using (var stringFormatRightUp = new StringFormat
            { Alignment = StringAlignment.Far, LineAlignment = StringAlignment.Far })
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAlias;

                var backgroundImageIsDrawn = false;
                if (backColor.A != 255)
                {
                    backgroundImageIsDrawn = DrawBackgroundImage(g, settings.backgroundImagePath, 0, yOffsetBox,
                        widthBox, heightBox, settings.BackgroundImageResizing);
                    if (settings.TintBackgroundImage)
                        //ImageTools.TintImage(bmp, backColor);
                        ImageTools.TintImage(bmp, Utils.ColorFromHsv(colorHue, settings.backColor.GetSaturation(), settings.backColor.GetValue()));
                }

                var currentYPosition = borderAndPaddings[0] + yOffsetBox;
                if (backColor.A != 0)
                {
                    using var backgroundBrush = new SolidBrush(backColor);
                    g.FillRectangle(backgroundBrush, 0, yOffsetBox, widthBox, heightBox);
                }

                var headerText = creature.Species.Name(creature.sex, true, true) +
                                 (settings.displayCreatureName ? $" - {creature.name}" : string.Empty);

                var fontSizeHeaderCalculated = CalculateFontSize(g, headerText, fontHeader, contentWidth);

                // offset considering the rounded border
                var xRadius = Math.Max(0, Math.Min(widthBox / 2f, settings.borderRadius));
                var yRadius = Math.Max(0, Math.Min(heightBox / 2f, settings.borderRadius));
                var xOffset = borderAndPaddings[3] + OffsetArc(xRadius, yRadius, currentYPosition - yOffsetBox);

                if (fontSizeHeaderCalculated < fontSizeHeader)
                {
                    using var fontHeaderScaled = new Font(settings.fontName, (int)fontSizeHeaderCalculated, FontStyle.Bold);
                    DrawTextWithOutline(g, headerText, fontHeaderScaled, fontBrush, penOutline, xOffset, currentYPosition);
                }
                else
                    DrawTextWithOutline(g, headerText, fontHeader, fontBrush, penOutline, xOffset, currentYPosition);

                currentYPosition += contentHeight * 19 / 180; //19
                var creatureLevel = settings.displayWithDomLevels ? $"{creature.Level}/{creature.LevelHatched + cc?.maxDomLevel ?? 0}" : creature.LevelHatched.ToString();

                var creatureInfos =
                    $"{Loc.S("Level", secondaryCulture: secondaryCulture)} {creatureLevel} | {Utils.SexSymbol(creature.sex) + (creature.flags.HasFlag(CreatureFlags.Neutered) ? $" ({Loc.S(creature.sex == Sex.Female ? "Spayed" : "Neutered", secondaryCulture: secondaryCulture)})" : string.Empty)}";
                if (settings.displayMutations)
                    creatureInfos +=
                        $" | {Loc.S("mutation counter", secondaryCulture: secondaryCulture)} {creature.Mutations}";
                if (settings.displayGenerations)
                    creatureInfos +=
                        $" | {Loc.S("generation", secondaryCulture: secondaryCulture)} {creature.generation}";

                xOffset = borderAndPaddings[3] + OffsetArc(xRadius, yRadius, currentYPosition - yOffsetBox);
                var availableWidth = widthBox - 2 * xOffset;
                var textWidth = g.MeasureString(creatureInfos, font).Width;
                Font resizedFont = null;
                if (textWidth > availableWidth)
                {
                    var adjustedSize = Math.Max(5, fontSize * availableWidth / textWidth);
                    resizedFont = new Font(font.FontFamily, adjustedSize);
                }

                DrawTextWithOutline(g, creatureInfos, resizedFont ?? font, fontBrush, penOutline, xOffset, currentYPosition);
                resizedFont?.Dispose();
                currentYPosition += contentHeight * 17 / 180; //17

                var lineWidth = Math.Max(1, heightBox / 180);
                if (!backgroundImageIsDrawn)
                {
                    if (settings.widthOutlineText > 0)
                    {
                        using var outlineBrush = new SolidBrush(colorOutlineText);
                        g.FillRectangle(outlineBrush, 0, currentYPosition - lineWidth / 2 - settings.widthOutlineText,
                            widthBox, lineWidth + settings.widthOutlineText * 2);
                    }
                    using var p = new Pen(Color.FromArgb(50, foreColor), lineWidth);
                    g.DrawLine(p, 0, currentYPosition - lineWidth / 2, widthBox, currentYPosition - lineWidth / 2);
                }

                currentYPosition += lineWidth;

                // levels
                var meanLetterWidth = fontSize * 7d / 10;

                var yBox = currentYPosition - yOffsetBox;
                var yOfLastStat = yBox + (contentHeight / 9) + Enumerable.Range(0, Stats.StatsCount).Count(s => s != Stats.Torpidity && creature.Species.UsesStat(s)) * statLineHeight;
                xOffset = borderAndPaddings[3] + Math.Max(OffsetArc(xRadius, yRadius, yBox), OffsetArc(xRadius, yRadius, heightBox - yOfLastStat));
                var xStatName = xOffset;
                var displayMutatedLevels =
                    !settings.displaySumWildMutLevels && creature.levelsMutated != null && cc?.Game == Ark.Asa;
                // x position of level number. torpor is the largest level number.
                var xRightLevelValue = (int)(xStatName +
                                             (6 + creature.levelsWild[Stats.Torpidity].ToString().Length) *
                                             meanLetterWidth);
                var xRightLevelMutValue = xRightLevelValue + (!displayMutatedLevels
                    ? 0
                    : (int)((creature.levelsMutated.Max().ToString().Length + 2) * meanLetterWidth));
                var xRightLevelDomValue = xRightLevelMutValue + (!settings.displayWithDomLevels
                    ? 0
                    : (int)((creature.levelsDom.Max().ToString().Length + 1) * meanLetterWidth));
                var xRightBrValue =
                    (int)(xRightLevelDomValue + (2 + MaxCharLength(creature.valuesBreeding)) * meanLetterWidth);
                var maxBoxLength = xRightBrValue - xStatName;
                var statBoxHeight = Math.Max(2, contentHeight / 90);
                DrawTextWithOutline(g, Loc.S("W", secondaryCulture: secondaryCulture) + (settings.displaySumWildMutLevels
                        ? "+" + Loc.S("M", secondaryCulture: secondaryCulture)
                        : string.Empty)
                    , font, fontBrush, penOutline,
                    xRightLevelValue - (displayMutatedLevels || settings.displayWithDomLevels ? (int)meanLetterWidth : 0),
                    currentYPosition, stringFormatRight);
                if (displayMutatedLevels)
                    DrawTextWithOutline(g, Loc.S("M", secondaryCulture: secondaryCulture), font, fontBrush, penOutline,
                        xRightLevelMutValue - (settings.displayWithDomLevels ? (int)meanLetterWidth : 0), currentYPosition,
                        stringFormatRight);
                if (settings.displayWithDomLevels)
                    DrawTextWithOutline(g, Loc.S("D", secondaryCulture: secondaryCulture), font, fontBrush, penOutline, xRightLevelDomValue,
                        currentYPosition, stringFormatRight);
                if (settings.displayStatValues)
                    DrawTextWithOutline(g, Loc.S("Values", secondaryCulture: secondaryCulture), font, fontBrush, penOutline, xRightBrValue,
                        currentYPosition, stringFormatRight);
                var statDisplayIndex = 0;
                foreach (var si in Stats.DisplayOrder)
                {
                    if (si == Stats.Torpidity || !creature.Species.UsesStat(si))
                        continue;

                    var y = currentYPosition + (contentHeight / 9) + (statDisplayIndex++) * statLineHeight;

                    // box
                    // empty box to show the max possible length
                    using (var b = new SolidBrush(Color.DarkGray))
                        g.FillRectangle(b, xStatName, y + statLineHeight - 1, maxBoxLength, statBoxHeight);
                    var levelFractionOfMax = Math.Min(1, (double)creature.levelsWild[si] / maxGraphLevel);
                    if (levelFractionOfMax < 0) levelFractionOfMax = 0;
                    var levelPercentageOfMax = (int)(100 * levelFractionOfMax);
                    var statBoxLength = Math.Max((int)(maxBoxLength * levelFractionOfMax), 1);
                    var statColor = Utils.GetColorFromPercent(levelPercentageOfMax);
                    using (var b = new SolidBrush(statColor))
                        g.FillRectangle(b, xStatName, y + statLineHeight - 1, statBoxLength, statBoxHeight);
                    using (var b = new SolidBrush(Color.FromArgb(10, statColor)))
                    {
                        for (var r = 4; r > 0; r--)
                            g.FillRectangle(b, xStatName - r, y + statLineHeight - 2 - r, statBoxLength + 2 * r,
                                statBoxHeight + 2 * r);
                    }

                    using (var p = new Pen(Utils.GetColorFromPercent(levelPercentageOfMax, -0.5), 1))
                        g.DrawRectangle(p, xStatName, y + statLineHeight - 1, statBoxLength, statBoxHeight);

                    // stat name
                    DrawTextWithOutline(g, $"{Utils.StatName(si, true, creature.Species.statNames, secondaryCulture)}",
                        font, fontBrush, penOutline, xStatName, y);
                    // stat level number
                    var displayedLevel = creature.levelsWild[si] +
                                         (settings.displaySumWildMutLevels && creature.levelsMutated != null &&
                                          creature.levelsMutated[si] > 0
                                             ? creature.levelsMutated[si]
                                             : 0);
                    DrawTextWithOutline(g,
                        $"{(creature.levelsWild[si] < 0 ? "?" : displayedLevel.ToString())}{(displayMutatedLevels || settings.displayWithDomLevels ? " |" : string.Empty)}",
                        font, fontBrush, penOutline, xRightLevelValue, y, stringFormatRight);
                    if (displayMutatedLevels)
                        DrawTextWithOutline(g,
                            $"{(creature.levelsMutated[si] < 0 ? string.Empty : creature.levelsMutated[si].ToString())}{(settings.displayWithDomLevels ? " |" : string.Empty)}",
                            font, fontBrush, penOutline, xRightLevelMutValue, y, stringFormatRight);
                    // dom level number
                    if (settings.displayWithDomLevels)
                        DrawTextWithOutline(g, $"{creature.levelsDom[si]}",
                            font, fontBrush, penOutline, xRightLevelDomValue, y, stringFormatRight);
                    // stat breeding value
                    if (settings.displayStatValues && creature.valuesBreeding != null)
                    {
                        var displayedValue =
                            settings.displayWithDomLevels ? creature.valuesCurrent[si] : creature.valuesBreeding[si];
                        string statValueRepresentation;
                        if (displayedValue < 0)
                        {
                            statValueRepresentation = "?";
                        }
                        else
                        {
                            if (Stats.IsPercentage(si))
                            {
                                statValueRepresentation = (100 * displayedValue).ToString("0.0");
                                DrawTextWithOutline(g, "%", font, fontBrush, penOutline, xRightBrValue, y);
                            }
                            else
                                statValueRepresentation = displayedValue.ToString("0.0");
                        }

                        DrawTextWithOutline(g, statValueRepresentation, font, fontBrush, penOutline, xRightBrValue, y, stringFormatRight);
                    }
                }

                // colors
                var xColor = (int)(xRightBrValue + meanLetterWidth * 3.5);
                var circleDiameter = contentHeight * 4 / 45;
                var colorRowHeight = circleDiameter + 2;

                var extraMarginBottom = settings.displayMaxWildLevel ? fontSizeSmall : 0;

                var (bmpCreature, bmpCreatureOutline, rectCreature, rectCreatureOutline, imageSizeInBox) =
                    await GetImage(widthImage, heightImage, widthBox,
                        (int)(xColor + borderAndPaddings[1] + circleDiameter + 8 * meanLetterWidth),
                        currentYPosition + borderAndPaddings[2] + extraMarginBottom - heightImage + heightBox,
                        borderAndPaddings, settings.creatureScaling, creature, cc.Game, settings.widthOutlineCreature, settings.creatureOutlineBlurring, settings.colorOutlineCreature);

                var creatureImageShown = bmpCreature != null;
                var maxColorNameLength =
                    (int)((widthBox - 2 * settings.borderWidth - xColor - circleDiameter - (creatureImageShown ? imageSizeInBox : 0)) * 1.5 /
                          meanLetterWidth); // max char length for the color region name
                if (maxColorNameLength < 0) maxColorNameLength = 0;

                if (creature.colors != null)
                {
                    DrawTextWithOutline(g, Loc.S("Colors", secondaryCulture: secondaryCulture), font, fontBrush, penOutline, xColor, currentYPosition);
                    DrawColors(creature.Species, creature.colors, settings.displayExtraRegionNames, settings.displayRegionNamesIfNoImage,
                        currentYPosition, contentHeight, colorRowHeight,
                        g, xColor, circleDiameter, borderAroundColors, creatureImageShown, maxColorNameLength,
                        fontSmall, fontBrush, penOutline);
                }

                // mutagen
                if (creature.flags.HasFlag(CreatureFlags.MutagenApplied))
                    DrawTextWithOutline(g, "Mutagen applied",
                        fontSmall, fontBrush, penOutline, xColor, heightBox - fontSizeSmall - borderAndPaddings[2]);

                // imprinting
                if (settings.displayWithDomLevels)
                {
                    if (creature.isBred || creature.imprintingBonus > 0)
                        DrawTextWithOutline(g, $"Imp: {creature.imprintingBonus * 100:0.0} %", font, fontBrush, penOutline,
                            xColor + (int)((Loc.S("Colors", secondaryCulture: secondaryCulture).Length + 3) *
                                           meanLetterWidth), currentYPosition);
                    else if (creature.tamingEff >= 0)
                        DrawTextWithOutline(g, $"TE: {creature.tamingEff * 100:0.0} %", font, fontBrush, penOutline,
                            xColor + (int)((Loc.S("Colors", secondaryCulture: secondaryCulture).Length + 3) *
                                           meanLetterWidth), currentYPosition);
                }

                // max wild level on server
                if (cc != null && settings.displayMaxWildLevel)
                {
                    DrawTextWithOutline(g, $"{Loc.S("max wild level", secondaryCulture: secondaryCulture)}: {cc.maxWildLevel}",
                        fontSmall, fontBrush, penOutline, widthBox - borderAndPaddings[1], heightBox - borderAndPaddings[2], stringFormatRightUp);
                }

                var drawBorder = settings.borderWidth > 0 || settings.borderRadius > 0;
                if (settings.creatureScaling > 1)
                {
                    if (drawBorder)
                        DrawBorder(borderColor, settings.borderWidth, settings.borderRadius, widthBox, heightBox, g, yOffsetBox, widthImage, heightImage);
                    DrawCreature(g, bmpCreature, rectCreature, bmpCreatureOutline, rectCreatureOutline);
                }
                else
                {
                    DrawCreature(g, bmpCreature, rectCreature, bmpCreatureOutline, rectCreatureOutline);
                    if (drawBorder)
                        DrawBorder(borderColor, settings.borderWidth, settings.borderRadius, widthBox, heightBox, g, yOffsetBox, widthImage, heightImage);
                }

                bmpCreature?.Dispose();
                bmpCreatureOutline?.Dispose();
            }
            if (settings.creatureScaling > 1)
                bmp = ImageTools.TrimTransparency(bmp);
            return bmp;
        }

        private static void DrawCreature(Graphics g, Bitmap bmpCreature, Rectangle rectCreature, Bitmap bmpCreatureOutline,
            Rectangle rectCreatureOutline)
        {
            if (bmpCreature == null) return;
            if (bmpCreatureOutline != null)
                g.DrawImage(bmpCreatureOutline, rectCreatureOutline);
            g.DrawImage(bmpCreature, rectCreature);
        }

        /// <summary>
        /// Draws a border. Clears the content outside the border.
        /// </summary>
        private static void DrawBorder(Color borderColor, int borderWidth, float borderRadius, int widthBox, int heightBox,
            Graphics g, int yOffset, int widthImage, int heightImage)
        {
            var bxy = borderWidth / 2f;
            var bWidth = widthBox - borderWidth;
            var bHeight = heightBox - borderWidth;
            if (borderRadius == 0)
            {
                g.SmoothingMode = SmoothingMode.None;
                using var p = new Pen(borderColor, borderWidth);
                g.DrawRectangle(p, bxy, bxy + yOffset, bWidth, bHeight);
            }
            else
            {
                using var pRoundedRectangle = PathRoundedRectangle(bxy, bxy + yOffset, bWidth - 1, bHeight - 1, borderRadius);
                using var pRoundedRectangleInverted = new GraphicsPath();
                pRoundedRectangleInverted.AddRectangle(new RectangleF(0, 0, widthImage, heightImage));
                pRoundedRectangleInverted.AddPath(pRoundedRectangle, false);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.CompositingMode = CompositingMode.SourceCopy;
                g.FillPath(Brushes.Transparent, pRoundedRectangleInverted);
                g.CompositingMode = CompositingMode.SourceOver;
                if (borderWidth <= 0) return;
                using var p = new Pen(borderColor, borderWidth);
                g.DrawPath(p, pRoundedRectangle);
            }
        }

        private static void DrawTextWithOutline(Graphics g, string text, Font font, Brush fontBrush, Pen outlinePen, int x, int y, StringFormat stringFormat = null)
        {
            stringFormat ??= StringFormat.GenericDefault;
            if (outlinePen.Width > 1)
            {
                using var path = new GraphicsPath();
                path.AddString(text, font.FontFamily, (int)font.Style, g.DpiY * font.Size / 72, new PointF(x - .5f, y - .5f), stringFormat);
                // outline
                g.DrawPath(outlinePen, path);
            }

            g.DrawString(text, font, fontBrush, x, y, stringFormat);
        }

        /// <summary>
        /// Get Bitmap of creature (this has to be disposed after use) and Bitmap of creature outline (do not dispose) and the according drawing rectangles.
        /// </summary>
        private static async Task<(Bitmap bmpCreature, Bitmap bmpCreatureOutline, Rectangle rectCreature, Rectangle rectCreatureOutline, int imageSizeInBox)>
            GetImage(int widthImage, int heightImage, int widthBox, int widthOfNonImage, int heightOfNonImage, int[] borderAndPaddings, float creatureScaling, Creature creature, string game,
            int widthOutlineCreature, float creatureOutlineBlurring, Color colorOutlineCreature)
        {
            var rectCreature = Rectangle.Empty;
            var rectCreatureOutline = Rectangle.Empty;
            var imageSizeInBox = 0;
            const int blurRadius = 1; // seems to result in good enough smoothing of the outline brush
            var outlinePadding = widthOutlineCreature > 0 ? widthOutlineCreature + blurRadius : 0;
            var creatureImageSize = Math.Min(
                    widthImage - widthOfNonImage - 2 * outlinePadding,
                    heightImage - heightOfNonImage - 2 * outlinePadding);
            if (creatureImageSize <= 5) return (null, null, rectCreature, rectCreatureOutline, imageSizeInBox);

            var bmpCreature = (await CreatureColored.GetColoredCreatureAsync(creature.colors, creature.Species, creature.Species.EnabledColorRegions,
                creatureImageSize, onlyImage: true, creatureSex: creature.sex, game: game).ConfigureAwait(false)).Bmp;

            if (bmpCreature == null) return (null, null, rectCreature, rectCreatureOutline, imageSizeInBox);
            imageSizeInBox = creatureImageSize - widthImage + widthBox;
            Bitmap bmpCreatureOutline = null;
            var moveImageDown = creatureScaling > 1 ? (int)(Math.Min(1, creatureScaling - 1) * borderAndPaddings[0]) : 0;

            rectCreature = new Rectangle(widthImage - creatureImageSize - outlinePadding - borderAndPaddings[1],
                                        heightImage - creatureImageSize - outlinePadding + Math.Min(0, moveImageDown - borderAndPaddings[2]),
                                        creatureImageSize, creatureImageSize);

            if (widthOutlineCreature > 0 && colorOutlineCreature.A != 0)
            {
                bmpCreatureOutline = ImageTools.BlurImageAlpha(
                        ImageTools.OutlineOpacities(bmpCreature, colorOutlineCreature, widthOutlineCreature, creatureOutlineBlurring), blurRadius);

                rectCreatureOutline = Rectangle.Inflate(rectCreature, outlinePadding, outlinePadding);
            }

            return (bmpCreature, bmpCreatureOutline, rectCreature, rectCreatureOutline, imageSizeInBox);
        }

        private static bool DrawBackgroundImage(Graphics g, string imagePath, int x, int y, int width, int height, BackgroundImageResizings backgroundSizeBehavior)
        {
            if (string.IsNullOrEmpty(imagePath) || !File.Exists(imagePath)) return false;
            try
            {
                using var bgImg = new Bitmap(imagePath);
                var xSource = 0;
                var ySource = 0;
                var widthSource = bgImg.Width;
                var heightSource = bgImg.Height;

                switch (backgroundSizeBehavior)
                {
                    case BackgroundImageResizings.Original:
                        xSource = widthSource > width ? (widthSource - width) / 2 : 0;
                        ySource = heightSource > height ? (heightSource - height) / 2 : 0;
                        if (widthSource > width) widthSource -= widthSource - width;
                        if (heightSource > height) heightSource -= heightSource - height;
                        break;
                    case BackgroundImageResizings.Contain:
                    case BackgroundImageResizings.Cover:
                        var widthRatio = (float)width / bgImg.Width;
                        var heightRatio = (float)height / bgImg.Height;
                        var scaleFactor = backgroundSizeBehavior == BackgroundImageResizings.Contain ? Math.Min(widthRatio, heightRatio) : Math.Max(widthRatio, heightRatio);
                        var widthScaled = (int)Math.Round(bgImg.Width * scaleFactor);
                        var heightScaled = (int)Math.Round(bgImg.Height * scaleFactor);
                        xSource = widthScaled > width ? (int)((widthScaled - width) / (2 * scaleFactor)) : 0;
                        ySource = heightScaled > height ? (int)((heightScaled - height) / (2 * scaleFactor)) : 0;
                        widthSource = (int)Math.Round(width / scaleFactor);
                        heightSource = (int)Math.Round(height / scaleFactor);
                        break;
                }

                g.DrawImage(bgImg, new Rectangle(x, y, width, height), new Rectangle(xSource, ySource, widthSource, heightSource), GraphicsUnit.Pixel);
                return true;
            }
            catch (Exception ex)
            {
                MessageBoxes.ExceptionMessageBox(ex, "Error when trying to draw the background image of the infographic with the path\n" + imagePath);
                return false;
            }
        }

        private static void DrawColors(Species species, byte[] creatureColors, bool displayExtraRegionNames, bool displayRegionNamesIfNoImage,
            int currentYPosition, int height, int colorRowHeight, Graphics g, int xColor, int circleDiameter,
            Pen borderAroundColors, bool creatureImageShown, int maxColorNameLength, Font fontSmall, SolidBrush fontBrush, Pen penOutline)
        {
            var colorRow = 0;
            for (var ci = 0; ci < Ark.ColorRegionCount; ci++)
            {
                if (!species.EnabledColorRegions[ci])
                    continue;

                var y = currentYPosition + (height / 9) + (colorRow++) * colorRowHeight;

                var c = CreatureColors.CreatureColor(creatureColors[ci]);
                //Color fc = Utils.ForeColor(c);

                using (var b = new SolidBrush(c))
                    g.FillEllipse(b, xColor, y, circleDiameter, circleDiameter);
                g.DrawEllipse(borderAroundColors, xColor, y, circleDiameter, circleDiameter);

                string colorRegionName = null;
                //string colorName = CreatureColors.CreatureColorName(creature.colors[ci]);

                if (displayExtraRegionNames || (!creatureImageShown && displayRegionNamesIfNoImage))
                {
                    colorRegionName = species.colors?[ci]?.name;
                    if (colorRegionName != null)
                    {
                        var totalColorLength = colorRegionName.Length + 11;
                        if (totalColorLength > maxColorNameLength)
                        {
                            // shorten color region name
                            var lengthForRegionName =
                                colorRegionName.Length - (totalColorLength - maxColorNameLength);
                            colorRegionName = lengthForRegionName < 2
                                ? string.Empty
                                : colorRegionName.Substring(0, lengthForRegionName - 1) + "…";
                        }

                        if (!string.IsNullOrEmpty(colorRegionName))
                            colorRegionName = " (" + colorRegionName + ")";
                    }
                }

                DrawTextWithOutline(g, $"[{ci}] {creatureColors[ci]}{colorRegionName}",
                    fontSmall, fontBrush, penOutline, xColor + circleDiameter + 4, y);
            }
        }

        /// <summary>
        /// If the text is too long, the smaller font size is returned to fit the available width.
        /// </summary>
        private static float CalculateFontSize(Graphics g, string text, Font font, int availableWidth)
        {
            var size = g.MeasureString(text, font);
            if (availableWidth < size.Width)
                return Math.Max(5, font.Size * availableWidth / size.Width);
            return Math.Max(5, font.Size);
        }

        /// <summary>
        /// Maximal character length of numbers, also considering percentage signs.
        /// </summary>
        private static int MaxCharLength(double[] values)
        {
            var max = 0;
            for (var si = 0; si < Stats.StatsCount; si++)
            {
                var l = values[si].ToString("0").Length + Stats.Precision(si);
                if (l > max) max = l;
            }
            return max;
        }

        private static Color GetMainColor(Creature c)
        {
            // get main color
            var tintColorRegionId = Array.FindIndex(c.Species.colors,
                r => r?.name != null && r.name.Contains("main", StringComparison.InvariantCultureIgnoreCase));
            if (tintColorRegionId == -1)
            {
                tintColorRegionId = Array.FindIndex(c.Species.colors,
                    r => r?.name != null && r.name.Contains("body", StringComparison.InvariantCultureIgnoreCase));
            }

            if (tintColorRegionId == -1) tintColorRegionId = Array.FindIndex(c.Species.colors, r => r?.name != null);
            if (tintColorRegionId == -1) return Values.V.Colors.ById(0).Color;
            return Values.V.Colors.ById(c.colors[tintColorRegionId]).Color;
        }

        /// <summary>
        /// Creates infoGraphic and copies it to the clipboard.
        /// </summary>
        /// <param name="creature"></param>
        /// <param name="cc">CreatureCollection for server settings.</param>
        public static async Task ExportInfoGraphicToClipboard(this Creature creature, CreatureCollection cc)
        {
            if (creature == null) return;
            ClipboardHandler.SetImageWithAlphaToClipboard(await creature.InfoGraphicAsync(cc).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns the coloredCreature Image with additional info about the colors.
        /// </summary>
        public static Image GetImageWithColors(Image coloredCreature, byte[] creatureColors, Species species)
        {
            return CreateImageWithColors(coloredCreature, creatureColors, species,
                Properties.Settings.Default.InfoGraphicHeight,
                GetUserFont(),
                Properties.Settings.Default.InfoGraphicForeColor,
                Properties.Settings.Default.InfoGraphicBackColor,
                Properties.Settings.Default.InfoGraphicTextOutlineColor,
                Properties.Settings.Default.InfoGraphicTextOutlineWidth,
                Properties.Settings.Default.InfoGraphicExtraRegionNames,
                Properties.Settings.Default.InfoGraphicShowRegionNamesIfNoImage);
        }

        /// <summary>
        /// Returns the coloredCreature Image with additional info about the colors.
        /// </summary>
        private static Image CreateImageWithColors(Image coloredCreature, byte[] creatureColors, Species species,
            int infoGraphicHeight, string fontName, Color foreColor, Color backColor, Color outlineColor, float outlineWidth,
            bool displayExtraRegionNames, bool displayRegionNamesIfNoImage)
        {
            const int margin = 10;
            var height = coloredCreature.Height;
            var width = (int)(coloredCreature.Width * (displayExtraRegionNames ? 2 : 1.5));
            var widthForColors = width - coloredCreature.Width;
            var circleDiameter = height * 4 / 45;
            var fontSize = circleDiameter * 6 / 10;
            var meanLetterWidth = fontSize * 7d / 10;
            var heightWithoutHeader = height;
            height += fontSize;

            var maxColorNameLength = (int)((widthForColors - circleDiameter) * 1.5 / meanLetterWidth); // max char length for the color region name
            if (maxColorNameLength < 0) maxColorNameLength = 0;

            var bmp = new Bitmap(width, height, PixelFormat.Format32bppArgb);
            using var g = Graphics.FromImage(bmp);
            using var font = new Font(fontName, fontSize);
            using var fontBrush = new SolidBrush(foreColor);
            using var borderAroundColors = new Pen(Utils.ForeColor(backColor), 1);
            using var penOutline = new Pen(outlineColor, outlineWidth * 2 + 1);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAlias;

            DrawTextWithOutline(g, species.DescriptiveNameAndMod, font, fontBrush, penOutline, margin, margin);

            g.DrawImage(coloredCreature, margin, margin + fontSize);
            DrawColors(species, creatureColors, displayExtraRegionNames, displayRegionNamesIfNoImage, fontSize,
                heightWithoutHeader, (heightWithoutHeader - 4 * margin) / Ark.ColorRegionCount, g, coloredCreature.Width + margin,
                circleDiameter, borderAroundColors, true, maxColorNameLength, font, fontBrush, penOutline);
            if (infoGraphicHeight != height)
            {
                var scaleFactor = (float)infoGraphicHeight / height;
                var scaledHeight = (int)(scaleFactor * height);
                var scaledWidth = (int)(scaleFactor * width);

                var bmpScaled = new Bitmap(scaledWidth, scaledHeight);
                using (var gs = Graphics.FromImage(bmpScaled))
                {
                    gs.CompositingMode = CompositingMode.SourceCopy;
                    gs.CompositingQuality = CompositingQuality.HighQuality;
                    gs.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    gs.SmoothingMode = SmoothingMode.HighQuality;
                    gs.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    gs.DrawImage(bmp, 0, 0, scaledWidth, scaledHeight);
                }
                bmp.Dispose();
                bmp = bmpScaled;
            }

            return bmp;
        }

        /// <summary>
        /// Returns a path around a rounded rectangle. Dispose after use.
        /// </summary>
        private static GraphicsPath PathRoundedRectangle(float x, float y, float width, float height, float radius)
        {
            var path = new GraphicsPath();

            var diameterX = Math.Min(width, radius * 2);
            var diameterY = Math.Min(height, radius * 2);
            var arc = new RectangleF(x, y, diameterX, diameterY);

            path.AddArc(arc, 180, 90); // top left

            arc.X = x + width - diameterX;
            path.AddArc(arc, 270, 90); // top right

            arc.Y = y + height - diameterY;
            path.AddArc(arc, 0, 90); // bottom right

            arc.X = x;
            path.AddArc(arc, 90, 90); // bottom left

            path.CloseFigure();
            return path;
        }

        /// <summary>
        /// Returns the x coordinate from the left of an arc defined by the xRadius and yRadius.
        /// </summary>
        private static int OffsetArc(float xRadius, float yRadius, int y)
        {
            if (yRadius <= 0 || y >= yRadius) return 0;
            if (y < 0) return (int)yRadius;
            var yMirrored = yRadius - y;
            return (int)Math.Round(xRadius - Math.Sqrt(xRadius * xRadius * (1 - yMirrored * yMirrored / (yRadius * yRadius))));
        }
    }
}
