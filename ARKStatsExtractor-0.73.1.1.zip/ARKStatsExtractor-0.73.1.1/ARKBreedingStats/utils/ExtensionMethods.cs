﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ARKBreedingStats.utils
{
    public static class ExtensionMethods
    {
        /// <summary>
        /// Returns the float precision of a given number.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static float FloatPrecision(this float x)
        {
            // Handle NaNs
            if (float.IsNaN(x))
                return x;

            // Return the correct EPSILON either side of zero
            float v;
            if (x == 0.0f)
            {
                v = BitConverter.ToSingle(BitConverter.GetBytes((UInt32)1), 0);
                return (x > 0) ? v : -v;
            }

            // Move one value to the next larger possible value
            UInt32 i = BitConverter.ToUInt32(BitConverter.GetBytes(x), 0) + 1;
            v = BitConverter.ToSingle(BitConverter.GetBytes(i), 0);

            return v - x;
        }

        /// <summary>
        /// Sets the Image property of the PictureBox to the passed Bitmap and disposes the previous Bitmap.
        /// </summary>
        public static void SetImageAndDisposeOld(this PictureBox pb, Bitmap bmp)
        {
            var oldBmp = pb.Image as Bitmap;
            pb.Image = bmp;
            oldBmp?.Dispose();
        }

        /// <summary>
        /// Sets the Image property of the Button to the passed Bitmap and disposes the previous Bitmap.
        /// </summary>
        public static void SetImageAndDisposeOld(this Button bt, Bitmap bmp)
        {
            var oldBmp = bt.Image as Bitmap;
            bt.Image = bmp;
            oldBmp?.Dispose();
        }

        /// <summary>
        /// Returns the value part of this color (HSV model) in the range 0...1.
        /// </summary>
        public static float GetValue(this Color c) => (float)Math.Max(c.R, Math.Max(c.G, c.B)) / byte.MaxValue;

        /// <summary>
        /// Returns the hsv values of this color.
        /// </summary>
        public static (float h, float s, float v) GetHsv(this Color c) => (c.GetHue(), c.GetSaturation(), c.GetValue());

        /// <summary>
        /// Call when parent of tooltip is closed to avoid memory leak.
        /// </summary>
        /// <param name="tt"></param>
        public static void RemoveAllAndDispose(this ToolTip tt)
        {
            tt.RemoveAll();
            tt.Dispose();
        }

        /// <summary>
        /// Returns the area of the Bitmap object in a RectangleF.
        /// </summary>
        public static RectangleF GetBounds(this Bitmap bmp)
            => bmp == null ? RectangleF.Empty : new RectangleF(0, 0, bmp.Width, bmp.Height);
    }
}
