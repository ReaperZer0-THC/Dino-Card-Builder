﻿using ARKBreedingStats.InfoGraphic;
using ARKBreedingStats.library;
using ARKBreedingStats.Library;
using ARKBreedingStats.NamePatterns;
using ARKBreedingStats.settings;
using ARKBreedingStats.species;
using ARKBreedingStats.uiControls;
using ARKBreedingStats.utils;
using ARKBreedingStats.values;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Threading;
using Color = System.Drawing.Color;
using KeyEventArgs = System.Windows.Forms.KeyEventArgs;

namespace ARKBreedingStats
{
    public partial class Form1
    {
        /// <summary>
        /// Creatures filtered according to the library-filter.
        /// Used so the live filter doesn't need to do the base filtering every time.
        /// </summary>
        private Creature[] _creaturesPreFiltered;

        private Species[] _speciesInLibraryOrdered;

        /// <summary>
        /// Add a new creature to the library based from the data of the extractor or tester
        /// </summary>
        /// <param name="fromExtractor">if true, take data from extractor-infoInput, else from tester</param>
        /// <param name="motherArkId">only pass if from import. Used for creating placeholder parents</param>
        /// <param name="fatherArkId">only pass if from import. Used for creating placeholder parents</param>
        /// <param name="goToLibraryTab">go to library tab after the creature is added</param>
        private Creature AddCreatureToCollection(bool fromExtractor = true, long motherArkId = 0, long fatherArkId = 0, bool goToLibraryTab = true)
        {
            var levelStep = _creatureCollection.getWildLevelStep();
            var species = speciesSelector1.SelectedSpecies;
            var creature = GetCreatureFromInput(fromExtractor, species, levelStep, motherArkId, fatherArkId);

            // if creature is placeholder: add it
            // if creature's ArkId is already in library, suggest updating of the creature
            //if (!IsArkIdUniqueOrOnlyPlaceHolder(creature))
            //{
            //    // if creature is already in library, suggest updating or dismissing

            //    //ShowDuplicateMergerAndCheckForDuplicates()

            //    return;
            //}

            creature.RecalculateCreatureValues(levelStep);
            creature.RecalculateNewMutations();

            if (_creatureCollection.DeletedCreatureGuids != null
                && _creatureCollection.DeletedCreatureGuids.Contains(creature.guid))
                _creatureCollection.DeletedCreatureGuids.RemoveAll(guid => guid == creature.guid);

            _creatureCollection.MergeCreatureList(new[] { creature });

            // set status of exportedCreatureControl if available
            _exportedCreatureControl?.setStatus(importExported.ExportedCreatureControl.ImportStatus.JustImported, DateTime.Now);

            // if creature already exists by guid, use the already existing creature object for the parent assignments
            creature = _creatureCollection.creatures.FirstOrDefault(c => c.guid == creature.guid) ?? creature;

            // if new creature is parent of existing creatures, update link
            var motherOf = _creatureCollection.creatures.Where(c => c.motherGuid == creature.guid).ToArray();
            foreach (Creature c in motherOf)
            {
                c.Mother = creature;
                c.RecalculateNewMutations();
            }
            var fatherOf = _creatureCollection.creatures.Where(c => c.fatherGuid == creature.guid).ToArray();
            foreach (Creature c in fatherOf)
            {
                c.Father = creature;
                c.RecalculateNewMutations();
            }

            // link new creature to its parents if they're available, or creature placeholders
            if (creature.Mother == null || creature.Father == null)
                UpdateParents(new List<Creature> { creature });

            // if the new creature is the ancestor of any other creatures, update the generation count of all creatures
            if (motherOf.Any() || fatherOf.Any())
            {
                var creaturesOfSpecies = _creatureCollection.creatures.Where(c => c.Species == creature.Species).ToArray();
                foreach (var cr in creaturesOfSpecies) cr.generation = -1;
                foreach (var cr in creaturesOfSpecies) cr.RecalculateAncestorGenerations();
            }
            else
            {
                creature.RecalculateAncestorGenerations();
            }

            if (Properties.Settings.Default.PauseGrowingTimerAfterAddingBaby)
                creature.StartStopMatureTimer(false);

            _filterListAllowed = false;
            UpdateCreatureListings(species, false);

            // show only the added creatures' species
            listBoxSpeciesLib.SelectedItem = creature.Species;
            _filterListAllowed = true;
            _libraryNeedsUpdate = true;

            if (goToLibraryTab)
            {
                tabControlMain.SelectedTab = tabPageLibrary;
                SelectCreatureInLibrary(creature);
            }

            creatureInfoInputExtractor.parentListValid = false;
            creatureInfoInputTester.parentListValid = false;

            SetCollectionChanged(true, species);
            return creature;
        }

        /// <summary>
        /// Deletes the creatures selected in the library after a confirmation.
        /// </summary>
        private void DeleteSelectedCreatures()
        {
            if (tabControlMain.SelectedTab == tabPageLibrary)
            {
                if (listViewLibrary.SelectedIndices.Count == 0) return;
                if ((ModifierKeys & Keys.Shift) == 0
                    && MessageBox.Show("Do you really want to delete the entry and all data for "
                                    + $"\"{_creaturesDisplayed[listViewLibrary.SelectedIndices[0]].name}\""
                                    + $"{(listViewLibrary.SelectedIndices.Count > 1 ? " and " + (listViewLibrary.SelectedIndices.Count - 1) + " other creatures" : null)}?\n\n"
                                    + "(Hold the Shift key to delete without this messagebox confirmation shown.)",
                        "Delete Creature?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
                    != DialogResult.Yes) return;

                bool onlyOneSpecies = true;
                Species species = _creaturesDisplayed[listViewLibrary.SelectedIndices[0]].Species;
                foreach (int i in listViewLibrary.SelectedIndices)
                {
                    var cr = _creaturesDisplayed[i];
                    if (onlyOneSpecies)
                    {
                        if (species != cr.Species)
                            onlyOneSpecies = false;
                    }
                    _creatureCollection.DeleteCreature(cr);
                }
                _creatureCollection.RemoveUnlinkedPlaceholders();
                UpdateCreatureListings(onlyOneSpecies ? species : null);
                SetCollectionChanged(true, onlyOneSpecies ? species : null);

                return;
            }

            if (tabControlMain.SelectedTab == tabPagePlayerTribes)
            {
                tribesControl1.RemoveSelected();
            }
        }

        /// <summary>
        /// Checks if the ArkId of the given creature is already in the collection. If a placeholder has this id, the placeholder is removed and the placeholder.Guid is set to the creature.
        /// </summary>
        /// <param name="creature">Creature whose ArkId will be checked</param>
        /// <returns>True if the ArkId is unique (or only a placeholder had it). False if there is a conflict.</returns>
        private bool IsArkIdUniqueOrOnlyPlaceHolder(Creature creature)
        {
            bool arkIdIsUnique = true;

            if (creature.ArkId != 0 && _creatureCollection.ArkIdAlreadyExist(creature.ArkId, creature, out Creature guidCreature))
            {
                // if the creature is a placeholder replace the placeholder with the real creature
                if (guidCreature.flags.HasFlag(CreatureFlags.Placeholder) && creature.sex == guidCreature.sex && creature.Species == guidCreature.Species)
                {
                    // remove placeholder-creature from collection (is replaced by new creature)
                    _creatureCollection.creatures.Remove(guidCreature);
                }
                else
                {
                    // creature is not a placeholder, warn about id-conflict and don't add creature.
                    // TODO offer merging of the two creatures if they are similar (e.g. same species). merge automatically if only the dom-levels are different?
                    MessageBox.Show("The entered ARK-ID is already existing in this library " +
                            $"({guidCreature.SpeciesName} (lvl {guidCreature.Level}): {guidCreature.name}).\n" +
                            "You have to choose a different ARK-ID or delete the other creature first.",
                            "ARK-ID already existing",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    arkIdIsUnique = false;
                }
            }

            return arkIdIsUnique;
        }

        /// <summary>
        /// Returns the wild levels from the extractor or tester in an array.
        /// </summary>
        private int[] GetCurrentWildLevels(bool fromExtractor = true)
            => (fromExtractor ? _statIOs : _testingIOs).Select(i => i.LevelWild).ToArray();

        /// <summary>
        /// Returns the mutated levels from the extractor or tester in an array.
        /// </summary>
        private int[] GetCurrentMutLevels(bool fromExtractor = true)
            => (fromExtractor ? _statIOs : _testingIOs).Select(i => i.LevelMut).ToArray();

        /// <summary>
        /// Returns the domesticated levels from the extractor or tester in an array.
        /// </summary>
        private int[] GetCurrentDomLevels(bool fromExtractor = true)
            => (fromExtractor ? _statIOs : _testingIOs).Select(i => i.LevelDom).ToArray();

        /// <summary>
        /// Returns the breeding values from the extractor or tester in an array.
        /// </summary>
        private double[] GetCurrentBreedingValues(bool fromExtractor = true)
            => (fromExtractor ? _statIOs : _testingIOs).Select(i => i.BreedingValue).ToArray();

        /// <summary>
        /// Call after the creatureCollection-object was created anew (e.g. after loading a file)
        /// </summary>
        /// <param name="keepCurrentSelection">True if synchronized library file is loaded.</param>
        private bool InitializeCollection(bool keepCurrentSelection = false)
        {
            // set pointer to current collection
            CreatureCollection.CurrentCreatureCollection = _creatureCollection;
            pedigree1.SetCreatures(_creatureCollection.creatures);
            breedingPlan1.CreatureCollection = _creatureCollection;
            tribesControl1.Tribes = _creatureCollection.tribes;
            tribesControl1.Players = _creatureCollection.players;
            timerList1.CreatureCollection = _creatureCollection;
            notesControl1.NoteList = _creatureCollection.noteList;
            raisingControl1.CreatureCollection = _creatureCollection;
            statsMultiplierTesting1.CreatureCollection = _creatureCollection;

            var duplicatesWereRemoved = UpdateParents(_creatureCollection.creatures);
            UpdateIncubationParents(_creatureCollection);

            CreateCreatureTagList();

            if (_creatureCollection.modIDs == null) _creatureCollection.modIDs = new List<string>();

            if (keepCurrentSelection)
            {
                pedigree1.RecreateAfterLoading(tabControlMain.SelectedTab == tabPagePedigree);
                breedingPlan1.RecreateAfterLoading(tabControlMain.SelectedTab == tabPageBreedingPlan);
            }
            else
            {
                pedigree1.Clear();
                breedingPlan1.Clear();
            }

            ApplySpeciesObjectsToCollection(_creatureCollection);

            currentBreeds1.CurrentBreedingPairs = _creatureCollection.CurrentBreedingPairs;

            UpdateTempCreatureDropDown();

            // if collection is loaded, set export folder to default if there's a match
            if (!keepCurrentSelection && !string.IsNullOrEmpty(_currentFilePath))
            {
                var exportFoldersString = Properties.Settings.Default.ExportCreatureFolders;
                if (exportFoldersString?.Any() == true)
                {
                    var currentDefault = ATImportExportedFolderLocation.CreateFromString(exportFoldersString[0]);
                    var exportFolders = exportFoldersString.Select(ATImportExportedFolderLocation.CreateFromString).ToArray();
                    var setToDefault = exportFolders.FirstOrDefault(f => f.IsDefaultForLibraryFile(_currentFilePath));
                    if (setToDefault != null && setToDefault.FolderPath != null &&
                        currentDefault.FolderPath != setToDefault.FolderPath)
                    {
                        Properties.Settings.Default.ExportCreatureFolders = exportFolders
                            .OrderByDescending(f => f == setToDefault)
                            .Select(location => location.ToString()).ToArray();
                        SetupExportFileWatcher();
                    }
                }
            }

            return duplicatesWereRemoved;
        }

        /// <summary>
        /// Applies the species object to the creatures and creatureValues of the collection.
        /// </summary>
        /// <param name="cc"></param>
        private static void ApplySpeciesObjectsToCollection(CreatureCollection cc)
        {
            if (cc == null) return;
            foreach (var cr in cc.creatures)
            {
                cr.Species = Values.V.SpeciesByBlueprint(cr.speciesBlueprint);
            }
            foreach (var cv in cc.creaturesValues)
            {
                cv.Species = Values.V.SpeciesByBlueprint(cv.speciesBlueprint);
            }
        }

        /// <summary>
        /// Calculates the top-stats in each species, sets the top-stat-flags in the creatures
        /// </summary>
        /// <param name="creatures">creatures to consider</param>
        /// <param name="onlySpecies">If not null, it's assumed only creatures of this species are recalculated</param>
        private void CalculateTopStats(List<Creature> creatures, Species onlySpecies = null)
        {
            if (onlySpecies == null)
            {
                // if all creatures are recalculated, clear all
                _creatureCollection.TopLevels.Clear();
            }
            else
            {
                _creatureCollection.TopLevels.Remove(onlySpecies);
                if (onlySpecies.matesWith?.Any() == true)
                {
                    foreach (var bp in onlySpecies.matesWith)
                    {
                        var sp = Values.V.SpeciesByBlueprint(bp);
                        if (sp != null)
                            _creatureCollection.TopLevels.Remove(sp);
                    }
                }
            }

            var filteredCreaturesHash = Properties.Settings.Default.useFiltersInTopStatCalculation ? new HashSet<Creature>(ApplyLibraryFilterSettings(creatures)) : null;

            var speciesList = creatures.Select(c => c.Species).Distinct().ToArray();

            foreach (var species in speciesList)
            {
                if (species == null)
                    continue;

                var speciesCreatures = _creatureCollection.GetSpeciesCompatibleCreatures(species);

                if (!speciesCreatures.Any()) continue;

                var usedStatIndices = new List<int>(8);
                var usedAndConsideredStatIndices = new List<int>();
                var highestLevels = new int[Stats.StatsCount];
                var lowestLevels = new int[Stats.StatsCount];
                var highestMutationLevels = new int[Stats.StatsCount];
                var lowestMutationLevels = new int[Stats.StatsCount];
                var considerAsTopStat = StatsOptionsConsiderTopStats.GetOptions(species).Options;
                var statWeights = breedingPlan1.StatWeighting.GetWeightingForSpecies(species);
                for (var s = 0; s < Stats.StatsCount; s++)
                {
                    highestLevels[s] = -1;
                    lowestLevels[s] = -1;
                    if (species.UsesStat(s))
                    {
                        usedStatIndices.Add(s);
                        if (considerAsTopStat[s].ConsiderStat)
                            usedAndConsideredStatIndices.Add(s);
                    }
                }
                var bestCreaturesWildLevels = new List<Creature>[Stats.StatsCount];
                var bestCreaturesMutatedLevels = new List<Creature>[Stats.StatsCount];
                var statPreferences = new StatWeighting.StatValuePreference[Stats.StatsCount];
                for (int s = 0; s < Stats.StatsCount; s++)
                {
                    var statWeight = statWeights.Item1[s];
                    statPreferences[s] = statWeight > 0 ? StatWeighting.StatValuePreference.High :
                        statWeight < 0 ? StatWeighting.StatValuePreference.Low :
                        StatWeighting.StatValuePreference.Indifferent;
                }

                foreach (var c in speciesCreatures)
                {
                    c.ResetTopStats();
                    c.ResetTopMutationStats();
                    c.topBreedingCreature = false;

                    if (
                        // if not in the filtered collection (using library filter settings), continue
                        (filteredCreaturesHash != null && !filteredCreaturesHash.Contains(c))
                        // only consider creature if it's available for breeding
                        || !(c.Status == CreatureStatus.Available
                            || c.Status == CreatureStatus.Cryopod
                            || c.Status == CreatureStatus.Obelisk
                            )
                        )
                    {
                        continue;
                    }

                    foreach (var s in usedStatIndices)
                    {
                        if (c.levelsWild[s] >= 0)
                        {
                            if (statPreferences[s] == StatWeighting.StatValuePreference.Low)
                            {
                                if (lowestLevels[s] == -1 || c.levelsWild[s] < lowestLevels[s])
                                {
                                    bestCreaturesWildLevels[s] = new List<Creature> { c };
                                    lowestLevels[s] = c.levelsWild[s];
                                }
                                else if (c.levelsWild[s] == lowestLevels[s])
                                {
                                    bestCreaturesWildLevels[s].Add(c);
                                }

                                if (c.levelsWild[s] > highestLevels[s])
                                {
                                    highestLevels[s] = c.levelsWild[s];
                                }
                            }
                            else if (statPreferences[s] == StatWeighting.StatValuePreference.High)
                            {
                                if (c.levelsWild[s] > highestLevels[s])
                                {
                                    // creature has a higher level than the current highest level
                                    // check if highest stats are only counted if odd or even
                                    if (statWeights.Item2[s] == StatWeighting.StatValueEvenOdd.Indifferent // even/odd doesn't matter
                                        || (statWeights.Item2[s] == StatWeighting.StatValueEvenOdd.Odd && c.levelsWild[s] % 2 == 1)
                                        || (statWeights.Item2[s] == StatWeighting.StatValueEvenOdd.Even && c.levelsWild[s] % 2 == 0)
                                       )
                                    {
                                        bestCreaturesWildLevels[s] = new List<Creature> { c };
                                        highestLevels[s] = c.levelsWild[s];
                                    }
                                }
                                else if (c.levelsWild[s] == highestLevels[s])
                                {
                                    bestCreaturesWildLevels[s].Add(c);
                                }
                                if (lowestLevels[s] == -1 || c.levelsWild[s] < lowestLevels[s])
                                {
                                    lowestLevels[s] = c.levelsWild[s];
                                }
                            }
                        }

                        if (c.levelsMutated != null && c.levelsMutated[s] >= 0)
                        {
                            if (statPreferences[s] == StatWeighting.StatValuePreference.Low)
                            {
                                if (c.levelsMutated[s] < lowestMutationLevels[s])
                                {
                                    bestCreaturesMutatedLevels[s] = new List<Creature> { c };
                                    lowestMutationLevels[s] = c.levelsMutated[s];
                                }
                                else if (c.levelsMutated[s] == lowestMutationLevels[s])
                                {
                                    if (bestCreaturesMutatedLevels[s] == null)
                                        bestCreaturesMutatedLevels[s] = new List<Creature> { c };
                                    else bestCreaturesMutatedLevels[s].Add(c);
                                }
                            }
                            else if (statPreferences[s] == StatWeighting.StatValuePreference.High
                                     && c.levelsMutated[s] > 0)
                            {
                                if (c.levelsMutated[s] > 0 && c.levelsMutated[s] > highestMutationLevels[s])
                                {
                                    bestCreaturesMutatedLevels[s] = new List<Creature> { c };
                                    highestMutationLevels[s] = c.levelsMutated[s];
                                }
                                else if (c.levelsMutated[s] == highestMutationLevels[s])
                                {
                                    bestCreaturesMutatedLevels[s].Add(c);
                                }
                            }
                        }
                    }
                }

                var topLevels = new TopLevels();
                _creatureCollection.TopLevels[species] = topLevels;

                topLevels.WildLevelsHighest = highestLevels;
                topLevels.WildLevelsLowest = lowestLevels;
                topLevels.MutationLevelsHighest = highestMutationLevels;
                topLevels.MutationLevelsLowest = lowestMutationLevels;

                // bestStat and bestCreatures now contain the best stats and creatures for each stat.

                int minTotalLevelWithAllTopLevels = 1;
                foreach (var si in usedStatIndices)
                {
                    if (si == Stats.Torpidity) continue;
                    switch (statPreferences[si])
                    {
                        case StatWeighting.StatValuePreference.High:
                            if (highestLevels[si] > 0)
                                minTotalLevelWithAllTopLevels += highestLevels[si];
                            break;
                        case StatWeighting.StatValuePreference.Low:
                            if (lowestLevels[si] > 0)
                                minTotalLevelWithAllTopLevels += lowestLevels[si];
                            break;
                    }
                }
                topLevels.MinLevelForTopCreature = minTotalLevelWithAllTopLevels;

                // set topness of each creature (== mean wildLevels/mean top wildLevels in permille)
                int sumTopLevels = 0;
                foreach (var s in usedAndConsideredStatIndices)
                {
                    switch (statPreferences[s])
                    {
                        case StatWeighting.StatValuePreference.Indifferent:
                            continue;
                        case StatWeighting.StatValuePreference.Low:
                            if (highestLevels[s] > 0 && lowestLevels[s] >= 0)
                                sumTopLevels += highestLevels[s] - lowestLevels[s];
                            if (lowestMutationLevels[s] >= 0)
                                sumTopLevels += highestMutationLevels[s] - lowestMutationLevels[s];
                            break;
                        case StatWeighting.StatValuePreference.High:
                            if (highestLevels[s] > 0)
                                sumTopLevels += highestLevels[s];
                            sumTopLevels += highestMutationLevels[s];
                            break;
                    }
                }
                if (sumTopLevels > 0)
                {
                    foreach (var c in speciesCreatures)
                    {
                        if (c.levelsWild == null || c.flags.HasFlag(CreatureFlags.Placeholder)) continue;
                        int sumCreatureLevels = 0;
                        foreach (var s in usedAndConsideredStatIndices)
                        {
                            switch (statPreferences[s])
                            {
                                case StatWeighting.StatValuePreference.Low:
                                    if (c.levelsWild[s] >= 0)
                                        sumCreatureLevels += highestLevels[s] - c.levelsWild[s] + highestMutationLevels[s] - (c.levelsMutated?[s] ?? 0);
                                    break;
                                case StatWeighting.StatValuePreference.High:
                                    sumCreatureLevels += (c.levelsWild[s] > 0 ? c.levelsWild[s] : 0)
                                        + (c.levelsMutated?[s] ?? 0);
                                    break;
                            }
                        }
                        c.topness = (short)(1000 * sumCreatureLevels / sumTopLevels);
                    }
                }

                // if any male is in more than 1 category, remove any male from the topBreedingCreatures that is not top in at least 2 categories himself
                for (int s = 0; s < Stats.StatsCount; s++)
                {
                    if (bestCreaturesMutatedLevels[s] != null)
                    {
                        foreach (var c in bestCreaturesMutatedLevels[s])
                            c.topBreedingCreature = true;
                    }

                    if (bestCreaturesWildLevels[s] == null || bestCreaturesWildLevels[s].Count == 0)
                        continue; // no creature has levelups in this stat or the stat is not used for this species

                    var crCount = bestCreaturesWildLevels[s].Count;
                    if (crCount == 1)
                    {
                        bestCreaturesWildLevels[s][0].topBreedingCreature = true;
                        continue;
                    }

                    foreach (var currentCreature in bestCreaturesWildLevels[s])
                    {
                        currentCreature.topBreedingCreature = true;
                        if (currentCreature.sex != Sex.Male)
                            continue;

                        // check how many best stat the male has
                        int maxval = 0;
                        for (int cs = 0; cs < Stats.StatsCount; cs++)
                        {
                            if ((statPreferences[s] == StatWeighting.StatValuePreference.High && currentCreature.levelsWild[cs] == highestLevels[cs])
                                || (statPreferences[s] == StatWeighting.StatValuePreference.Low && currentCreature.levelsWild[cs] == lowestLevels[cs])
                                )
                                maxval++;
                        }

                        if (maxval > 1)
                        {
                            // check now if the other males have only 1.
                            foreach (var otherMale in bestCreaturesWildLevels[s])
                            {
                                if (otherMale.sex != Sex.Male
                                    || currentCreature.Equals(otherMale))
                                    continue;

                                int othermaxval = 0;
                                for (int ocs = 0; ocs < Stats.StatsCount; ocs++)
                                {
                                    if ((statPreferences[s] == StatWeighting.StatValuePreference.High && otherMale.levelsWild[ocs] == highestLevels[ocs])
                                        || (statPreferences[s] == StatWeighting.StatValuePreference.Low && otherMale.levelsWild[ocs] == lowestLevels[ocs])
                                        )
                                    {
                                        othermaxval++;
                                    }
                                    if (otherMale.IsTopMutationStat(ocs))
                                    {
                                        // if this creature has top mutation levels, don't remove it from breeding pool
                                        othermaxval = 99;
                                        break;
                                    }
                                }
                                if (othermaxval == 1)
                                    otherMale.topBreedingCreature = false;
                            }
                        }
                    }
                }

                // now we have a list of all candidates for breeding. Iterate on stats.
                for (int s = 0; s < Stats.StatsCount; s++)
                {
                    if (bestCreaturesWildLevels[s] != null)
                    {
                        foreach (var c in bestCreaturesWildLevels[s])
                            c.SetTopStat(s, true);
                    }

                    if (bestCreaturesMutatedLevels[s] != null)
                    {
                        foreach (var c in bestCreaturesMutatedLevels[s])
                            c.SetTopMutationStat(s, true);
                    }
                }
            }

            bool considerWastedStatsForTopCreatures = Properties.Settings.Default.ConsiderWastedStatsForTopCreatures;

            var considerTopStats = new Dictionary<Species, bool[]>();
            foreach (Creature c in creatures)
            {
                if (c.Species == null || c.flags.HasFlag(CreatureFlags.Placeholder))
                    continue;
                if (!considerTopStats.TryGetValue(c.Species, out var consideredTopStats))
                {
                    consideredTopStats = StatsOptionsConsiderTopStats.GetOptions(c.Species).Options.Select(si => si.ConsiderStat).ToArray();
                    considerTopStats[c.Species] = consideredTopStats;
                }
                c.SetTopStatCount(consideredTopStats, considerWastedStatsForTopCreatures);
            }

            var selectedSpecies = speciesSelector1.SelectedSpecies;
            if (selectedSpecies != null)
                hatching1.SetSpecies(selectedSpecies, _creatureCollection.TopLevels.TryGetValue(selectedSpecies, out var tl) ? tl : null);
        }

        /// <summary>
        /// Sets the parents according to the guids. Call after a file is loaded. Returns true if duplicates were removed.
        /// </summary>
        private bool UpdateParents(IEnumerable<Creature> creatures)
        {
            Dictionary<Guid, Creature> creatureGuids;

            bool duplicatesWereRemoved = false;

            try
            {
                creatureGuids = _creatureCollection.creatures.ToDictionary(c => c.guid);
            }
            catch (ArgumentException)
            {
                // assuming there are somehow multiple creatures with the same guid
                // if it's only placeholders, remove the duplicates
                var guidGroups = _creatureCollection.creatures.GroupBy(c => c.guid);
                var uniqueList = new List<Creature>();

                foreach (var g in guidGroups)
                {
                    var count = g.Count();
                    var firstCreature = g.First();
                    if (count == 1)
                    {
                        uniqueList.Add(firstCreature);
                        continue;
                    }
                    // if only one creature is not a placeholder, use that
                    var nonPlaceholders = g.Where(c => !c.flags.HasFlag(CreatureFlags.Placeholder)).ToArray();
                    count = nonPlaceholders.Length;
                    if (count == 1)
                    {
                        uniqueList.Add(nonPlaceholders.First());
                        continue;
                    }


                    if (count == 0)
                    {
                        // just take the first placeholder
                        uniqueList.Add(firstCreature);
                        continue;
                    }

                    // there are more than 1 non-placeholder with the same guid. Check if the objects represent the same.
                    bool sameCreature = true;
                    for (int i = 1; i < count; i++)
                    {
                        var duplicateCreature = nonPlaceholders[i];
                        if (firstCreature.name.Trim() != duplicateCreature.name.Trim()
                            || !AreIntArraysEqual(firstCreature.levelsWild, duplicateCreature.levelsWild)
                            || !AreByteArraysEqual(firstCreature.colors, duplicateCreature.colors)
                            )
                        {
                            sameCreature = false;
                            break;
                        }
                    }

                    bool AreIntArraysEqual(int[] firstArray, int[] secondArray)
                    {
                        if (firstArray == null && secondArray == null) return true;
                        if (firstArray == null || secondArray == null) return false;
                        var firstCount = firstArray.Length;
                        var secondCount = secondArray.Length;
                        if (firstCount != secondCount) return false;

                        for (int i = 0; i < firstCount; i++)
                        {
                            if (firstArray[i] != secondArray[i])
                                return false;
                        }

                        return true;
                    }

                    bool AreByteArraysEqual(byte[] firstArray, byte[] secondArray)
                    {
                        if (firstArray == null && secondArray == null) return true;
                        if (firstArray == null || secondArray == null) return false;
                        var firstCount = firstArray.Length;
                        var secondCount = secondArray.Length;
                        if (firstCount != secondCount) return false;

                        for (int i = 0; i < firstCount; i++)
                        {
                            if (firstArray[i] != secondArray[i])
                                return false;
                        }

                        return true;
                    }

                    if (sameCreature)
                    {
                        uniqueList.Add(firstCreature);
                        continue;
                    }

                    // duplicate creatures differ
                    var text = new StringBuilder();
                    text.AppendLine($"There is an issue with some creatures of this library.\nEach creature must have a unique id (guid),\nbut all the following creatures share the same guid {firstCreature.guid}");
                    text.AppendLine();
                    for (int i = 0; i < count; i++)
                    {
                        var c = nonPlaceholders[i];
                        var species = Values.V.SpeciesByBlueprint(c.speciesBlueprint)?.DescriptiveNameAndMod ?? c.speciesBlueprint;
                        text.AppendLine($"{(i + 1)}: {species} - {c.name}");
                    }

                    text.AppendLine();
                    text.AppendLine("If you click on Yes, the first listed creature will be kept, all the other creatures will be removed. A backup file of the following library file will be created:");
                    text.AppendLine(_currentFilePath);
                    text.AppendLine("If you click on No, the application will quit.");
                    text.AppendLine("Remove duplicates?");

                    if (MessageBox.Show(text.ToString(), $"Duplicate creatures - {Utils.ApplicationNameVersion}",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        uniqueList.Add(firstCreature);
                        continue;
                    }

                    Environment.Exit(0);
                }

                _creatureCollection.creatures = uniqueList;

                creatureGuids = _creatureCollection.creatures.ToDictionary(c => c.guid);
                // create backup file of file before duplicates were removed
                if (!string.IsNullOrEmpty(_currentFilePath)
                    && File.Exists(_currentFilePath))
                {
                    File.Copy(_currentFilePath, Path.Combine(Path.GetDirectoryName(_currentFilePath), $"{Path.GetFileNameWithoutExtension(_currentFilePath)}_BackupBeforeRemovingDuplicates_{DateTime.Now:yyyy-MM-dd_HH-mm-ss-ffff}.asb"));
                }

                duplicatesWereRemoved = true;
            }

            var placeholderAncestors = new Dictionary<Guid, Creature>();

            foreach (Creature c in creatures)
            {
                if (c.motherGuid == Guid.Empty && c.fatherGuid == Guid.Empty) continue;

                Creature mother = null;
                if (c.motherGuid != Guid.Empty && !creatureGuids.TryGetValue(c.motherGuid, out mother))
                {
                    // Check for an archetype creature matching by name, species, and sex
                    if (!string.IsNullOrEmpty(c.motherName))
                    {
                        mother = _creatureCollection.creatures.FirstOrDefault(a =>
                            a.flags.HasFlag(CreatureFlags.Archetype) &&
                            a.Species == c.Species &&
                            a.name == c.motherName &&
                            (a.sex == Sex.Female || a.sex == Sex.Unknown));
                    }

                    mother ??= EnsurePlaceholderCreature(placeholderAncestors, c, c.motherGuid, c.motherName, Sex.Female);
                }

                Creature father = null;
                if (c.fatherGuid != Guid.Empty && !creatureGuids.TryGetValue(c.fatherGuid, out father))
                {
                    // Check for an archetype creature matching by name, species, and sex
                    if (!string.IsNullOrEmpty(c.fatherName))
                    {
                        father = _creatureCollection.creatures.FirstOrDefault(a =>
                            a.flags.HasFlag(CreatureFlags.Archetype) &&
                            a.Species == c.Species &&
                            a.name == c.fatherName &&
                            (a.sex == Sex.Male || a.sex == Sex.Unknown));
                    }

                    father ??= EnsurePlaceholderCreature(placeholderAncestors, c, c.fatherGuid, c.fatherName, Sex.Male);
                }

                c.Mother = mother;
                c.Father = father;
            }

            _creatureCollection.creatures.AddRange(placeholderAncestors.Values);

            return duplicatesWereRemoved;
        }

        /// <summary>
        /// Ensures the given placeholder ancestor exists in the list of placeholders.
        /// Does nothing when the details are not well specified.
        /// </summary>
        /// <param name="placeholders">List of placeholders to amend</param>
        /// <param name="tmpl">Descendant creature to use as a template</param>
        /// <param name="guid">GUID of creature to create</param>
        /// <param name="name">Name of the creature to create</param>
        /// <param name="sex">Sex of the creature to create</param>
        /// <returns></returns>
        private Creature EnsurePlaceholderCreature(Dictionary<Guid, Creature> placeholders, Creature tmpl, Guid guid, string name, Sex sex)
        {
            if (guid == Guid.Empty)
                return null;
            if (placeholders.TryGetValue(guid, out var existingCreature))
                return existingCreature;

            if (string.IsNullOrEmpty(name))
                name = (sex == Sex.Female ? "Mother" : sex == Sex.Male ? "Father" : "Parent") + " of " + tmpl.name;

            var creature = new Creature(tmpl.Species, name, null, null, sex, levelStep: _creatureCollection.getWildLevelStep())
            {
                guid = guid,
                Status = CreatureStatus.Unavailable,
                flags = CreatureFlags.Placeholder
            };

            placeholders.Add(creature.guid, creature);

            return creature;
        }

        /// <summary>
        /// Sets the parents of the incubation-timers according to the guids. Call after a file is loaded.
        /// </summary>
        /// <param name="cc"></param>
        private void UpdateIncubationParents(CreatureCollection cc)
        {
            if (!cc.incubationListEntries.Any()) return;

            var dict = cc.creatures.ToDictionary(c => c.guid);

            foreach (IncubationTimerEntry it in cc.incubationListEntries)
            {
                if (it.motherGuid != Guid.Empty && dict.TryGetValue(it.motherGuid, out var m))
                    it.Mother = m;
                if (it.fatherGuid != Guid.Empty && dict.TryGetValue(it.fatherGuid, out var f))
                    it.Father = f;
            }
        }

        private void ShowCreaturesInListView(IEnumerable<Creature> creatures)
        {
            listViewLibrary.BeginUpdate();
            _creaturesDisplayed = GetSortedCreatureList(creatures);
            listViewLibrary.VirtualListSize = _creaturesDisplayed.Length;
            _libraryListViewItemCache = null;
            listViewLibrary.EndUpdate();

            // highlight filter input if something is entered and no results are available
            if (string.IsNullOrEmpty(ToolStripTextBoxLibraryFilter.Text))
            {
                ToolStripTextBoxLibraryFilter.BackColor = SystemColors.Window;
                ToolStripButtonLibraryFilterClear.BackColor = SystemColors.Control;
            }
            else
            {
                // if no items are shown, shade red, if something is shown and potentially some are sorted out, shade yellow
                ToolStripTextBoxLibraryFilter.BackColor = _creaturesDisplayed.Any() ? UiColors.Current.FilterActive : UiColors.Current.FilterEmpty;
                ToolStripButtonLibraryFilterClear.BackColor = UiColors.Current.FilterButton;
            }
        }

        /// <summary>
        /// Returns array of creatures to display in the library list view, including dividers if option is set.
        /// </summary>
        private Creature[] GetSortedCreatureList(IEnumerable<Creature> creatures, int columnIndex = -1)
        {
            Dictionary<Species, int> speciesOrderIndex = null;
            if (Properties.Settings.Default.LibraryGroupBySpecies && _speciesInLibraryOrdered?.Any() == true)
            {
                if (Properties.Settings.Default.LibraryCombineBreedingCompatibleSpecies)
                {
                    var speciesIndex = -1;
                    speciesOrderIndex = new Dictionary<Species, int>();
                    foreach (var s in _speciesInLibraryOrdered)
                    {
                        if (speciesOrderIndex.ContainsKey(s)) continue;
                        speciesOrderIndex[s] = ++speciesIndex;
                        if (s.matesWith?.Any() != true) continue;
                        foreach (var bp in s.matesWith)
                        {
                            var connectedSpecies = Values.V.SpeciesByBlueprint(bp);
                            if (connectedSpecies == null) continue;
                            speciesOrderIndex[connectedSpecies] = speciesIndex;
                        }
                    }
                }
                else
                    speciesOrderIndex = _speciesInLibraryOrdered.Select((s, i) => (s, i)).ToDictionary(s => s.s, s => s.i);
            }
            var sorted = _creatureListSorter.DoSort(creatures, columnIndex, speciesOrderIndex);
            return Properties.Settings.Default.LibraryGroupBySpecies ? InsertDividers(sorted, Properties.Settings.Default.LibraryCombineBreedingCompatibleSpecies) : sorted;
        }

        private Creature[] InsertDividers(IList<Creature> creatures, bool combineBreedingCompatibleSpecies)
        {
            if (!creatures.Any())
            {
                return Array.Empty<Creature>();
            }
            var result = new List<Creature>();
            Species lastSpecies = null;
            foreach (var c in creatures)
            {
                if (lastSpecies == null
                    || (c.Species != lastSpecies
                        && (!combineBreedingCompatibleSpecies
                            || lastSpecies.matesWith?.Contains(c.Species.blueprintPath) != true)))
                {
                    result.Add(new Creature(c.Species)
                    {
                        flags = CreatureFlags.Placeholder | CreatureFlags.Divider,
                        Status = CreatureStatus.Unavailable
                    });
                }
                result.Add(c);
                lastSpecies = c.Species;
            }
            return result.ToArray();
        }

        #region ListViewLibrary virtual

        private Creature[] _creaturesDisplayed;
        private ListViewItem[] _libraryListViewItemCache; //array to cache items for the virtual list
        private int _libraryItemCacheFirstIndex; //stores the index of the first item in the cache

        private void ListViewLibrary_RetrieveVirtualItem(object sender, RetrieveVirtualItemEventArgs e)
        {
            // check to see if the requested item is currently in the cache
            if (_libraryListViewItemCache != null && e.ItemIndex >= _libraryItemCacheFirstIndex &&
                e.ItemIndex < _libraryItemCacheFirstIndex + _libraryListViewItemCache.Length)
            {
                // get the ListViewItem from the cache instead of making a new one.
                e.Item = _libraryListViewItemCache[e.ItemIndex - _libraryItemCacheFirstIndex];
            }
            else if (_creaturesDisplayed?.Length > e.ItemIndex)
            {
                // create item not available in the cache
                e.Item = CreateCreatureLvItem(_creaturesDisplayed[e.ItemIndex],
                    Properties.Settings.Default.DisplayLibraryCreatureIndex);
            }
            else
            {
                throw new Exception($"ListViewItem could not be retrieved. ItemIndex: {e.ItemIndex}. "
                                    + $"_creaturesDisplayedLength: {_creaturesDisplayed?.Length}. "
                                    + $"_libraryListViewItemCacheLength: {_libraryListViewItemCache?.Length}");
            }
        }

        private void ListViewLibrary_CacheVirtualItems(object sender, CacheVirtualItemsEventArgs e)
        {
            if (_libraryListViewItemCache != null && e.StartIndex >= _libraryItemCacheFirstIndex && e.EndIndex <= _libraryItemCacheFirstIndex + _libraryListViewItemCache.Length)
            {
                // cache already contains needed items, so do nothing.
                return;
            }

            // rebuild the cache.
            const int cacheMoreRows = 60;
            var indexStart = Math.Max(0, e.StartIndex - cacheMoreRows);
            var indexEnd = Math.Min(_creaturesDisplayed.Length - 1, e.EndIndex + cacheMoreRows);
            _libraryItemCacheFirstIndex = indexStart;
            var length = indexEnd - indexStart + 1;
            _libraryListViewItemCache = new ListViewItem[length];

            var displayIndex = Properties.Settings.Default.DisplayLibraryCreatureIndex;
            //Fill the cache with the appropriate ListViewItems.
            for (int i = 0; i < length; i++)
            {
                _libraryListViewItemCache[i] = CreateCreatureLvItem(_creaturesDisplayed[i + _libraryItemCacheFirstIndex], displayIndex);
            }
        }

        private void ListViewLibrary_DrawItem(object sender, DrawListViewItemEventArgs e)
        {
            e.DrawDefault = true;

            if (!(e.Item.Tag is Creature creature))
            {
                return;
            }

            if (creature.flags.HasFlag(CreatureFlags.Divider))
            {
                e.DrawDefault = false;
                var rect = e.Bounds;
                var count = 0;
                if (creature.Species.blueprintPath != null)
                    _creatureCollection.GetCreatureCountBySpecies()
                        .TryGetValue(creature.Species.blueprintPath, out count);

                var speciesName = creature.Species.DescriptiveNameAndMod;
                if (!string.IsNullOrEmpty(creature.Species.nameMale) && creature.Species.nameMale != creature.Species.name) speciesName = creature.Species.nameMale + " / " + speciesName;
                if (!string.IsNullOrEmpty(creature.Species.nameFemale) && creature.Species.nameFemale != creature.Species.name) speciesName = creature.Species.nameFemale + " / " + speciesName;
                var displayedText = speciesName + " (" + count + ")";

                if (Properties.Settings.Default.LibraryCombineBreedingCompatibleSpecies && creature.Species.matesWith?.Any() == true)
                {
                    var addTexts = new List<string>();
                    foreach (var bp in creature.Species.matesWith)
                    {
                        var sp = Values.V.SpeciesByBlueprint(bp);
                        if (sp == null) continue;
                        addTexts.Add($"{sp.DescriptiveNameAndMod} ({(_creatureCollection.GetCreatureCountBySpecies().TryGetValue(bp, out count) ? count : 0)})");
                    }

                    if (addTexts.Any())
                        displayedText += ", " + string.Join(", ", addTexts);
                }

                float middle = (rect.Top + rect.Bottom) / 2f;
                using var lineBrush = new SolidBrush(UiColors.Current.DividerLine);
                e.Graphics.FillRectangle(lineBrush, rect.Left, middle, rect.Width - 3, 1);
                SizeF strSize = e.Graphics.MeasureString(displayedText, e.Item.Font);
                e.Graphics.FillRectangle(new SolidBrush(e.Item.BackColor), rect.Left, rect.Top, strSize.Width + 15, rect.Height);
                using var textBrush = new SolidBrush(SystemColors.ControlText);
                e.Graphics.DrawString(displayedText, e.Item.Font, textBrush, rect.Left + 10, rect.Top + ((rect.Height - strSize.Height) / 2f));
            }
        }

        private void ListViewLibrary_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            // DrawBackground() uses the native visual styles renderer which ignores WinForms dark mode.
            // Fill manually with SystemColors so the background, dividers, and text respond to the theme.
            using (var backBrush = new SolidBrush(SystemColors.Window))
                e.Graphics.FillRectangle(backBrush, e.Bounds);
            using (var dividerPen = new Pen(SystemColors.ControlLight))
                e.Graphics.DrawLine(dividerPen, e.Bounds.Right - 2, e.Bounds.Top, e.Bounds.Right - 2, e.Bounds.Bottom);

            var textFlags = TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding;
            textFlags |= e.Header.TextAlign switch
            {
                HorizontalAlignment.Center => TextFormatFlags.HorizontalCenter,
                HorizontalAlignment.Right => TextFormatFlags.Right,
                _ => TextFormatFlags.Left,
            };
            const int headerPadding = 6;
            var textBounds = new Rectangle(e.Bounds.X + headerPadding, e.Bounds.Y, e.Bounds.Width - headerPadding * 2, e.Bounds.Height);
            TextRenderer.DrawText(e.Graphics, e.Header.Text, e.Font, textBounds, SystemColors.ControlText, textFlags);
        }

        private void ListViewLibrary_DrawSubItem(object sender, DrawListViewSubItemEventArgs e)
        {
            var isDivider = e.Item.Tag is Creature creature && creature.flags.HasFlag(CreatureFlags.Divider);
            e.DrawDefault = !isDivider;
        }

        #endregion

        /// <summary>
        /// Call this function to update the displayed values of a creature. Usually called after a creature was edited.
        /// </summary>
        /// <param name="cr">Creature that was changed</param>
        /// <param name="creatureStatusChanged"></param>
        private void UpdateDisplayedCreatureValues(Creature cr, bool creatureStatusChanged, bool ownerServerChanged)
        {
            // if row is selected, save and reselect later
            var selectedCreatures = new HashSet<Creature>();
            foreach (int i in listViewLibrary.SelectedIndices)
                selectedCreatures.Add(_creaturesDisplayed[i]);

            // data of the selected creature changed, update listview
            cr.RecalculateCreatureValues(_creatureCollection.getWildLevelStep());
            // if creatureStatus (available/dead) changed, recalculate topStats (dead creatures are not considered there)
            if (creatureStatusChanged)
            {
                CalculateTopStats(_creatureCollection.creatures.Where(c => c.Species == cr.Species).ToList(), cr.Species);
                FilterLibRecalculate();
                UpdateStatusBar();
            }
            else
            {
                UpdateCreatureListViewItem(cr);
            }

            // recreate ownerList
            if (ownerServerChanged)
                UpdateOwnerServerTagLists();
            SetCollectionChanged(true, cr.Species);

            SelectCreaturesInLibrary(selectedCreatures);
        }

        /// <summary>
        /// Selects the passed creatures in the library and sets _reactOnCreatureSelectionChange on true again.
        /// </summary>
        /// <param name="selectedCreatures"></param>
        private void SelectCreaturesInLibrary(HashSet<Creature> selectedCreatures, bool selectFirstIfNothingIsSelected = false)
        {
            var selectedCount = selectedCreatures?.Count ?? 0;
            if (selectedCount == 0)
            {
                listViewLibrary.SelectedIndices.Clear();
                SelectFirstItemIfNothingIsSelected();
                return;
            }

            _reactOnCreatureSelectionChange = false;

            listViewLibrary.SelectedIndices.Clear();

            var creatureSelected = false;
            // for loop is faster than foreach loop for small selected item amount, which is usually the case
            for (int i = 0; i < _creaturesDisplayed.Length; i++)
            {
                if (selectedCreatures.Contains(_creaturesDisplayed[i]))
                {
                    creatureSelected = true;
                    if (--selectedCount == 0)
                    {
                        _reactOnCreatureSelectionChange = true;
                        listViewLibrary.SelectedIndices.Add(i);
                        listViewLibrary.EnsureVisible(i);
                        break;
                    }
                    listViewLibrary.SelectedIndices.Add(i);
                }
            }

            if (!creatureSelected)
            {
                SelectFirstItemIfNothingIsSelected();
            }

            _reactOnCreatureSelectionChange = true; // make sure it reacts again even if the previous creature is not visible anymore

            void SelectFirstItemIfNothingIsSelected()
            {
                if (!selectFirstIfNothingIsSelected)
                {
                    creatureBoxListView.Clear();
                    return;
                }

                var firstCreatureIndex = Array.FindIndex(_creaturesDisplayed, c => !c.flags.HasFlag(CreatureFlags.Divider));

                if (firstCreatureIndex == -1)
                {
                    creatureBoxListView.Clear();
                    return;
                }

                _reactOnCreatureSelectionChange = true;
                listViewLibrary.SelectedIndices.Add(firstCreatureIndex);
                listViewLibrary.EnsureVisible(firstCreatureIndex);
            }
        }

        /// <summary>
        /// Selects a creature in the library
        /// </summary>
        /// <param name="creature"></param>
        private void SelectCreatureInLibrary(Creature creature)
        {
            if (creature == null) return;

            var index = Array.IndexOf(_creaturesDisplayed, creature);
            if (index == -1) return;

            _reactOnCreatureSelectionChange = false;
            listViewLibrary.SelectedIndices.Clear();
            _reactOnCreatureSelectionChange = true;
            listViewLibrary.SelectedIndices.Add(index);
            listViewLibrary.EnsureVisible(index);
        }

        private void UpdateCreatureListViewItem(Creature creature)
        {
            if (_libraryListViewItemCache == null) return;
            // int listViewLibrary replace old row with new one
            var index = Array.IndexOf(_creaturesDisplayed, creature);
            if (index == -1) return; // not in cache currently
            var cacheIndex = index - _libraryItemCacheFirstIndex;
            if (cacheIndex >= 0 && cacheIndex < _libraryListViewItemCache.Length)
            {
                _libraryListViewItemCache[cacheIndex] = CreateCreatureLvItem(creature, Properties.Settings.Default.DisplayLibraryCreatureIndex);
            }
        }

        private const int ColumnIndexName = 0;
        private const int ColumnIndexSex = 4;
        private const int ColumnIndexAdded = 5;
        private const int ColumnIndexTopness = 6;
        private const int ColumnIndexTopStats = 7;
        private const int ColumnIndexGeneration = 8;
        private const int ColumnIndexWildLevel = 9;
        private const int ColumnIndexMutations = 10;
        private const int ColumnIndexCountdown = 11;
        private const int ColumnIndexFirstStat = 12;
        private const int ColumnIndexFirstColor = 36;
        private const int ColumnIndexPostColor = 42;
        private const int ColumnIndexMutagenApplied = 46;

        private ListViewItem CreateCreatureLvItem(Creature cr, bool displayIndex = false)
        {
            if (cr.flags.HasFlag(CreatureFlags.Divider))
            {
                return new ListViewItem(Enumerable.Repeat(string.Empty, listViewLibrary.Columns.Count).ToArray())
                {
                    Tag = cr
                };
            }

            string[] subItems = new[]
                {
                    (displayIndex ? cr.ListIndex + " - " : string.Empty) +
                    cr.name,
                    cr.owner,
                    cr.note,
                    cr.server,
                    Utils.SexSymbol(cr.sex),
                    cr.domesticatedAt?.ToString("yyyy'-'MM'-'dd HH':'mm':'ss") ?? string.Empty,
                    (cr.topness / 10).ToString(),
                    cr.TopStatsConsideredCount.ToString(),
                    cr.generation.ToString(),
                    cr.levelFound.ToString(),
                    cr.Mutations.ToString(),
                    DisplayedCreatureCountdown(cr, out var cooldownForeColor, out var cooldownBackColor)
                }
                .Concat(cr.levelsWild.Select(l => l.ToString()))
                .Concat((cr.levelsMutated ?? new int[Stats.StatsCount]).Select(l => l.ToString()))
                .Concat(Properties.Settings.Default.showColorsInLibrary
                    ? cr.colors.Select(cl => cl.ToString())
                    : new string[Ark.ColorRegionCount]
                )
                .Concat(new[]
                {
                    cr.Species.DescriptiveNameAndMod,
                    cr.Status.ToString(),
                    cr.tribe,
                    Utils.StatusSymbol(cr.Status, string.Empty),
                    (cr.flags & CreatureFlags.MutagenApplied) != 0 ? "M" : string.Empty,
                    cr.Level.ToString(),
                    (CreatureCollection.CurrentCreatureCollection.maxServerLevel > 0
                        ? Math.Min(cr.LevelHatched + CreatureCollection.CurrentCreatureCollection.maxDomLevel,
                            CreatureCollection.CurrentCreatureCollection.maxServerLevel)
                        : cr.LevelHatched + CreatureCollection.CurrentCreatureCollection.maxDomLevel
                    ).ToString(),
                    cr.TraitsString
                })
                .ToArray();

            // check if groups for species are displayed
            ListViewItem lvi = new ListViewItem(subItems) { Tag = cr };

            // apply colors to the subItems
            var displayZeroMutationLevels = Properties.Settings.Default.LibraryDisplayZeroMutationLevels;

            var statOptionsColors = StatsOptionsLevelColors.GetOptions(cr.Species).Options;
            var statOptionsTopStats = StatsOptionsConsiderTopStats.GetOptions(cr.Species).Options;

            for (int s = 0; s < Stats.StatsCount; s++)
            {
                if (cr.valuesCurrent[s] == 0
                    || (!Properties.Settings.Default.LibraryShowStatLevelsThatCannotLevelup
                        && cr.Species?.CanLevelUpWildOrHaveMutations(s) == false))
                {
                    // not used
                    lvi.SubItems[ColumnIndexFirstStat + s].ForeColor = SystemColors.Window;
                    lvi.SubItems[ColumnIndexFirstStat + s].BackColor = SystemColors.Window;
                }
                else if (cr.levelsWild[s] < 0)
                {
                    // unknown level 
                    lvi.SubItems[ColumnIndexFirstStat + s].ForeColor = SystemColors.GrayText;
                    lvi.SubItems[ColumnIndexFirstStat + s].BackColor = SystemColors.Window;
                }
                else
                {
                    var backColor = Utils.AdjustColorLight(statOptionsColors[s].GetLevelColor(cr.levelsWild[s]),
                        statOptionsTopStats[s].ConsiderStat ? cr.IsTopStat(s) ? UiColors.DeltaLightnessTopStat : UiColors.DeltaLightnessConsideredStat : UiColors.DeltaLightnessUnconsideredStat);
                    lvi.SubItems[ColumnIndexFirstStat + s].SetBackColorAndAccordingForeColor(backColor);
                }

                // mutated levels
                if (cr.levelsMutated == null || (!displayZeroMutationLevels && cr.levelsMutated[s] == 0))
                {
                    lvi.SubItems[ColumnIndexFirstStat + Stats.StatsCount + s].ForeColor = SystemColors.Window;
                    lvi.SubItems[ColumnIndexFirstStat + Stats.StatsCount + s].BackColor = SystemColors.Window;
                }
                else
                {
                    var backColor = Utils.AdjustColorLight(statOptionsColors[s].GetLevelColor(cr.levelsMutated[s], false, true),
                        statOptionsTopStats[s].ConsiderStat ? cr.IsTopMutationStat(s) ? UiColors.DeltaLightnessTopStat : UiColors.DeltaLightnessConsideredStat : UiColors.DeltaLightnessUnconsideredStat);
                    lvi.SubItems[ColumnIndexFirstStat + Stats.StatsCount + s].SetBackColorAndAccordingForeColor(backColor);
                }
            }
            lvi.SubItems[ColumnIndexSex].BackColor = cr.flags.HasFlag(CreatureFlags.Neutered)
                    ? UiColors.Current.SexNeutered
                    : cr.sex == Sex.Female
                    ? UiColors.Current.SexFemale
                    : cr.sex == Sex.Male
                    ? UiColors.Current.SexMale
                    : SystemColors.Window;

            switch (cr.Status)
            {
                case CreatureStatus.Dead:
                    lvi.SubItems[ColumnIndexName].ForeColor = SystemColors.GrayText;
                    lvi.BackColor = UiColors.Current.DeadCreature;
                    break;
                case CreatureStatus.Unavailable:
                    lvi.SubItems[ColumnIndexName].ForeColor = SystemColors.GrayText;
                    break;
                case CreatureStatus.Obelisk:
                    lvi.SubItems[ColumnIndexName].ForeColor = UiColors.Current.ObeliskText;
                    break;
                default:
                    if (_creatureCollection.maxServerLevel > 0
                            && cr.levelsWild[Stats.Torpidity] + 1 + _creatureCollection.maxDomLevel > _creatureCollection.maxServerLevel + (cr.Species.name.StartsWith("X-") || cr.Species.name.StartsWith("R-") ? 50 : 0))
                    {
                        lvi.SubItems[ColumnIndexName].ForeColor = UiColors.Current.OverLevelWarning; // this creature may pass the max server level and could be deleted by the game
                    }
                    break;
            }

            lvi.UseItemStyleForSubItems = false;

            // color for top-stats-nr
            if (cr.TopStatsConsideredCount > 0)
            {
                if (Properties.Settings.Default.LibraryHighlightTopCreatures && cr.topBreedingCreature)
                {
                    lvi.BackColor = cr.onlyTopConsideredStats ? UiColors.Current.TopBreedingAll : UiColors.Current.TopBreedingSome;
                    lvi.ForeColor = Utils.ForeColor(lvi.BackColor);
                }
                lvi.SubItems[ColumnIndexTopStats].SetBackColorAndAccordingForeColor(Utils.GetColorFromPercent(cr.TopStatsConsideredCount * 8 + 44, UiColors.DeltaLightnessConsideredStat));
            }
            else
            {
                lvi.SubItems[ColumnIndexTopStats].ForeColor = SystemColors.GrayText;
            }

            // color for timestamp domesticated
            if (cr.domesticatedAt == null || cr.domesticatedAt.Value.Year < 2015)
            {
                lvi.SubItems[ColumnIndexAdded].Text = "n/a";
                lvi.SubItems[ColumnIndexAdded].ForeColor = SystemColors.GrayText;
            }

            // color for topness
            lvi.SubItems[ColumnIndexTopness].SetBackColorAndAccordingForeColor(Utils.GetColorFromPercent(cr.topness / 5 - 100, UiColors.DeltaLightnessConsideredStat)); // topness is in permille. gradient from 50-100

            // color for generation
            if (cr.generation == 0)
                lvi.SubItems[ColumnIndexGeneration].ForeColor = SystemColors.GrayText;

            // color of WildLevelColumn
            if (cr.levelFound == 0)
                lvi.SubItems[ColumnIndexWildLevel].ForeColor = SystemColors.GrayText;

            // color for mutations counter
            if (cr.Mutations > 0)
            {
                if (cr.Mutations < Ark.MutationPossibleWithLessThan)
                    lvi.SubItems[ColumnIndexMutations].SetBackColorAndAccordingForeColor(UiColors.Current.Mutation);
                else
                    lvi.SubItems[ColumnIndexMutations].SetBackColorAndAccordingForeColor(UiColors.Current.MutationOverLimit);
            }
            else
                lvi.SubItems[ColumnIndexMutations].ForeColor = SystemColors.GrayText;

            // color for cooldown
            lvi.SubItems[ColumnIndexCountdown].ForeColor = cooldownForeColor;
            lvi.SubItems[ColumnIndexCountdown].BackColor = cooldownBackColor;

            if (Properties.Settings.Default.showColorsInLibrary)
            {
                var desiredColors = ColorOptionsWantedRegions.GetOptions(cr.Species);

                // color for colors
                for (int cl = 0; cl < Ark.ColorRegionCount; cl++)
                {
                    if (cr.colors[cl] != 0)
                        lvi.SubItems[ColumnIndexFirstColor + cl].SetBackColorAndAccordingForeColor(CreatureColors.CreatureColor(cr.colors[cl]));
                    else
                        lvi.SubItems[ColumnIndexFirstColor + cl].ForeColor = cr.Species.EnabledColorRegions[cl] ? SystemColors.GrayText : SystemColors.Window;

                    if (desiredColors.Options[cl].IsColorWanted(cr.colors[cl]))
                        lvi.SubItems[ColumnIndexFirstColor + cl].Font = new Font(lvi.SubItems[ColumnIndexFirstColor + cl].Font, FontStyle.Bold);
                }
            }

            return lvi;
        }

        /// <summary>
        /// Returns the dateTime when the countdown of a creature is ready. Either the maturingTime, the matingCooldownTime or null if no countdown is set.
        /// </summary>
        /// <returns></returns>
        private string DisplayedCreatureCountdown(Creature cr, out Color foreColor, out Color backColor)
        {
            foreColor = SystemColors.ControlText;
            backColor = SystemColors.Window;
            DateTime dt;
            var isGrowing = true;
            var useGrowingLeft = false;
            var now = DateTime.Now;
            if (cr.cooldownUntil.HasValue && cr.cooldownUntil.Value > now)
            {
                isGrowing = false;
                dt = cr.cooldownUntil.Value;
            }
            else if (!cr.growingUntil.HasValue || cr.growingUntil.Value <= now)
            {
                foreColor = SystemColors.GrayText;
                return "-";
            }
            else if (!cr.growingPaused)
            {
                dt = cr.growingUntil.Value;
            }
            else
            {
                useGrowingLeft = true;
                dt = new DateTime();
            }

            if (!useGrowingLeft && now > dt)
            {
                foreColor = SystemColors.GrayText;
                return "-";
            }

            double minCld;
            if (useGrowingLeft)
                minCld = cr.growingLeft.TotalMinutes;
            else
                minCld = dt.Subtract(now).TotalMinutes;

            if (isGrowing)
            {
                // growing
                if (minCld < 1)
                    backColor = UiColors.Current.GrowingImminent;
                else if (minCld < 10)
                    backColor = UiColors.Current.GrowingSoon;
                else
                    backColor = UiColors.Current.GrowingLater;
            }
            else
            {
                // mating-cooldown
                if (minCld < 1)
                    backColor = UiColors.Current.CooldownImminent;
                else if (minCld < 10)
                    backColor = UiColors.Current.CooldownSoon;
                else
                    backColor = UiColors.Current.CooldownLater;
            }

            return useGrowingLeft ? Utils.Duration(cr.growingLeft) : dt.ToString();
        }

        private readonly CreatureListSorter _creatureListSorter = new CreatureListSorter();

        private void libraryListView_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            SortLibrary(e.Column);
        }

        /// <summary>
        /// /// Sort the library by given column index. If the columnIndex is -1, use last sorting.
        /// </summary>
        private void SortLibrary(int columnIndex = -1)
        {
            listViewLibrary.BeginUpdate();

            var selectedCreatures = new HashSet<Creature>();
            foreach (int i in listViewLibrary.SelectedIndices)
                selectedCreatures.Add(_creaturesDisplayed[i]);

            _creaturesDisplayed = GetSortedCreatureList(_creaturesDisplayed.Where(c => !c.flags.HasFlag(CreatureFlags.Divider)), columnIndex);
            _libraryListViewItemCache = null;
            listViewLibrary.EndUpdate();
            SelectCreaturesInLibrary(selectedCreatures);
        }

        private readonly Debouncer _libraryIndexChangedDebouncer = new Debouncer();

        // onLibraryChange
        private void listViewLibrary_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_reactOnCreatureSelectionChange)
                _libraryIndexChangedDebouncer.Debounce(100, LibrarySelectedIndexChanged, Dispatcher.CurrentDispatcher);
        }

        /// <summary>
        /// Updates infos about the selected creatures like tags, levels and stat-level distribution.
        /// </summary>
        private void LibrarySelectedIndexChanged()
        {
            // remove dividers from selection
            foreach (int i in listViewLibrary.SelectedIndices)
            {
                if (_creaturesDisplayed[i].flags.HasFlag(CreatureFlags.Divider))
                    listViewLibrary.SelectedIndices.Remove(i);
            }

            int cnt = listViewLibrary.SelectedIndices.Count;
            if (cnt == 0)
            {
                SetMessageLabelText();
                creatureBoxListView.Clear();
                return;
            }

            if (cnt == 1)
            {
                Creature c = _creaturesDisplayed[listViewLibrary.SelectedIndices[0]];
                creatureBoxListView.SetCreature(c);
                if (tabControlLibFilter.SelectedTab == tabPageLibRadarChart)
                    radarChartLibrary.SetLevels(c.levelsWild, c.levelsMutated, c.Species);
                pedigree1.PedigreeNeedsUpdate = true;
            }

            // display infos about the selected creatures
            var selCrs = new List<Creature>(cnt);

            foreach (int i in listViewLibrary.SelectedIndices)
                selCrs.Add(_creaturesDisplayed[i]);

            List<string> tagList = new List<string>();
            foreach (Creature cr in selCrs)
            {
                foreach (string t in cr.tags)
                    if (!tagList.Contains(t))
                        tagList.Add(t);
            }
            tagList.Sort();

            SetMessageLabelText($"{cnt} creatures selected, " +
                    $"{selCrs.Count(cr => cr.sex == Sex.Female)} females, " +
                    $"{selCrs.Count(cr => cr.sex == Sex.Male)} males\r\n" +
                    (cnt == 1
                        ? $"level: {selCrs[0].Level}; Ark-Id (ingame): " + (selCrs[0].ArkIdImported ? Utils.ConvertImportedArkIdToIngameVisualization(selCrs[0].ArkId) : selCrs[0].ArkId.ToString())
                        : $"level-range: {selCrs.Min(cr => cr.Level)} - {selCrs.Max(cr => cr.Level)}"
                    ) + "\r\n" +
                    $"Tags: {string.Join(", ", tagList)}");
        }

        /// <summary>
        /// Display the creatures with the current filter.
        /// Recalculate all filters.
        /// </summary>
        private void FilterLibRecalculate(bool selectFirstIfNothingIsSelected = false)
        {
            _creaturesPreFiltered = null;
            FilterLib(selectFirstIfNothingIsSelected);
        }

        /// <summary>
        /// Display the creatures with the current filter.
        /// Use the pre filtered list (if available) and only apply the live filter.
        /// </summary>
        private void FilterLib(bool selectFirstIfNothingIsSelected = false)
        {
            if (!_filterListAllowed)
                return;

            // save selected creatures to re-select them after the filtering
            var selectedCreatures = new HashSet<Creature>();
            foreach (int i in listViewLibrary.SelectedIndices)
                selectedCreatures.Add(_creaturesDisplayed[i]);

            IEnumerable<Creature> filteredList;

            if (_creaturesPreFiltered == null)
            {
                if (!_creatureCollection.creatures.Any())
                {
                    _creaturesPreFiltered = Array.Empty<Creature>();
                }
                else
                {
                    filteredList = from creature in _creatureCollection.creatures
                                   where creature.Species != null && !creature.flags.HasFlag(CreatureFlags.Placeholder)
                                   select creature;

                    // if only one species should be shown adjust headers if the selected species has custom statNames
                    Dictionary<string, string> customStatNames = null;
                    if (listBoxSpeciesLib.SelectedItem is Species selectedSpecies)
                    {
                        if (Properties.Settings.Default.LibraryCombineBreedingCompatibleSpecies)
                            filteredList = filteredList.Where(c => c.Species == selectedSpecies || selectedSpecies.matesWith?.Contains(c.Species.blueprintPath) == true);
                        else
                            filteredList = filteredList.Where(c => c.Species == selectedSpecies);
                        customStatNames = selectedSpecies.statNames;
                    }

                    for (int s = 0; s < Stats.StatsCount; s++)
                    {
                        listViewLibrary.Columns[ColumnIndexFirstStat + s].Text =
                            Utils.StatName(s, true, customStatNames);
                        listViewLibrary.Columns[ColumnIndexFirstStat + Stats.StatsCount + s].Text =
                            Utils.StatName(s, true, customStatNames) + "M";
                    }

                    _creaturesPreFiltered = ApplyLibraryFilterSettings(filteredList).ToArray();
                }
            }

            filteredList = _creaturesPreFiltered;
            // apply live filter
            var filterString = ToolStripTextBoxLibraryFilter.Text.Trim();
            if (!string.IsNullOrEmpty(filterString))
            {
                if (filterString.StartsWith("re:"))
                {
                    var regexString = filterString.Substring(3);
                    if (!string.IsNullOrEmpty(regexString))
                    {
                        try
                        {
                            SetMessageLabelText();
                            // do regex filtering
                            var re = new Regex(regexString);

                            filteredList = filteredList.Where(c =>
                                re.IsMatch(c.name)
                                || re.IsMatch(c.SpeciesName)
                                || (c.owner != null && re.IsMatch(c.owner))
                                || (c.tribe != null && re.IsMatch(c.tribe))
                                || (c.note != null && re.IsMatch(c.note))
                                || (c.ArkIdInGame != null && re.IsMatch(c.ArkIdInGame))
                                || (c.server != null && re.IsMatch(c.server))
                                || c.tags?.Any(t => re.IsMatch(t)) == true
                            );
                        }
                        catch (Exception ex)
                        {
                            SetMessageLabelText($"Error while doing regex filter in library using regex{Environment.NewLine}{regexString}{Environment.NewLine}{ex.Message}", MessageBoxIcon.Error, ignoreNextMessage: true);
                        }
                    }
                }
                else
                {
                    // filter parameter are separated by commas and all parameter must be found on an item to have it included
                    var filterStrings = filterString.Split(',').Select(f => f.Trim())
                        .Where(f => !string.IsNullOrEmpty(f)).ToList();

                    // extract stat level filter
                    var statGreaterThan = new Dictionary<int, int>();
                    var statLessThan = new Dictionary<int, int>();
                    var statEqualTo = new Dictionary<int, int>();
                    var statFilterRegex = new Regex(@"(\w{2}) ?(<|>|==) ?(\d+)");

                    // color filter
                    var colorFilterOr =
                        new Dictionary<int[], int[]>(); // includes creatures that have in one of the regions one of the colors
                    var colorFilterRegexOr = new Regex(@"c([0-5 ]+): ?([\d ]+)");

                    // mutation filter
                    var mutationFilterEqualTo = -1;
                    var mutationFilterGreaterThan = -1;
                    var mutationFilterLessThan = -1;

                    var removeFilterIndex =
                        new List<int>(); // remove all filter entries that are added to specific filter properties
                    // start at the end, so the removed filter indices are also removed from the end
                    for (var i = filterStrings.Count - 1; i >= 0; i--)
                    {
                        var f = filterStrings[i];

                        // color region filter
                        var m = colorFilterRegexOr.Match(f);
                        if (m.Success)
                        {
                            var colorIds = m.Groups[2].Value.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                                .Select(int.Parse).Distinct().ToArray();
                            if (!colorIds.Any()) continue;

                            var colorRegions = m.Groups[1].Value.Where(r => r != ' ')
                                .Select(r => int.Parse(r.ToString())).ToArray();

                            colorFilterOr[colorRegions] = colorIds;
                            removeFilterIndex.Add(i);
                            continue;
                        }

                        // stat filter
                        m = statFilterRegex.Match(f);
                        if (!m.Success) continue;
                        if (!Utils.StatAbbreviationToIndex.TryGetValue(m.Groups[1].Value, out var statIndex))
                        {
                            // mutations
                            if (m.Groups[1].Value == "mu")
                            {
                                switch (m.Groups[2].Value)
                                {
                                    case ">":
                                        mutationFilterGreaterThan = int.Parse(m.Groups[3].Value);
                                        break;
                                    case "<":
                                        mutationFilterLessThan = int.Parse(m.Groups[3].Value);
                                        break;
                                    case "==":
                                        mutationFilterEqualTo = int.Parse(m.Groups[3].Value);
                                        break;
                                }

                                removeFilterIndex.Add(i);
                            }

                            continue;
                        }

                        switch (m.Groups[2].Value)
                        {
                            case ">":
                                statGreaterThan[statIndex] = int.Parse(m.Groups[3].Value);
                                break;
                            case "<":
                                statLessThan[statIndex] = int.Parse(m.Groups[3].Value);
                                break;
                            case "==":
                                statEqualTo[statIndex] = int.Parse(m.Groups[3].Value);
                                break;
                        }

                        removeFilterIndex.Add(i);
                    }

                    if (!statGreaterThan.Any()) statGreaterThan = null;
                    if (!statLessThan.Any()) statLessThan = null;
                    if (!statEqualTo.Any()) statEqualTo = null;
                    if (!colorFilterOr.Any()) colorFilterOr = null;
                    foreach (var i in removeFilterIndex)
                        filterStrings.RemoveAt(i);

                    filteredList = filteredList.Where(c => filterStrings.All(f =>
                                                               c.name.IndexOf(f,
                                                                   StringComparison.InvariantCultureIgnoreCase) != -1
                                                               || (c.Species?.name.IndexOf(f,
                                                                       StringComparison.InvariantCultureIgnoreCase) ??
                                                                   -1) != -1
                                                               || (c.owner?.IndexOf(f,
                                                                       StringComparison.InvariantCultureIgnoreCase) ??
                                                                   -1) != -1
                                                               || (c.tribe?.IndexOf(f,
                                                                       StringComparison.InvariantCultureIgnoreCase) ??
                                                                   -1) != -1
                                                               || (c.note?.IndexOf(f,
                                                                       StringComparison.InvariantCultureIgnoreCase) ??
                                                                   -1) != -1
                                                               || (c.ArkIdInGame?.StartsWith(f) ?? false)
                                                               || (c.server?.IndexOf(f,
                                                                       StringComparison.InvariantCultureIgnoreCase) ??
                                                                   -1) != -1
                                                               || (c.tags?.Any(t =>
                                                                       string.Equals(t, f,
                                                                           StringComparison
                                                                               .InvariantCultureIgnoreCase)) ??
                                                                   false)
                                                           )
                                                           && (statGreaterThan?.All(si =>
                                                               c.levelsWild[si.Key] > si.Value) ?? true)
                                                           && (statLessThan?.All(si =>
                                                               c.levelsWild[si.Key] < si.Value) ?? true)
                                                           && (statEqualTo?.All(si =>
                                                               c.levelsWild[si.Key] == si.Value) ?? true)
                                                           && (colorFilterOr?.All(colorRegions =>
                                                               colorRegions.Key.Any(colorRegion =>
                                                                   colorRegions.Value.Contains(
                                                                       c.colors[colorRegion]))) ?? true)
                                                           && (mutationFilterGreaterThan == -1 ||
                                                               mutationFilterGreaterThan < c.Mutations)
                                                           && (mutationFilterLessThan == -1 ||
                                                               mutationFilterLessThan > c.Mutations)
                                                           && (mutationFilterEqualTo == -1 ||
                                                               mutationFilterEqualTo == c.Mutations)
                    );
                }
            }

            // display new results
            ShowCreaturesInListView(filteredList);

            // select previous selected creatures again
            SelectCreaturesInLibrary(selectedCreatures, selectFirstIfNothingIsSelected);
        }

        /// <summary>
        /// Apply library filter settings to a creature collection
        /// </summary>
        private IEnumerable<Creature> ApplyLibraryFilterSettings(IEnumerable<Creature> creatures)
        {
            if (creatures == null)
                return Enumerable.Empty<Creature>();

            var anyFilterSet = false;

            if (Properties.Settings.Default.FilterHideOwners?.Any() ?? false)
            {
                creatures = creatures.Where(c => !Properties.Settings.Default.FilterHideOwners.Contains(c.owner ?? string.Empty));
                anyFilterSet = true;
            }

            if (Properties.Settings.Default.FilterHideTribes?.Any() ?? false)
            {
                creatures = creatures.Where(c => !Properties.Settings.Default.FilterHideTribes.Contains(c.tribe ?? string.Empty));
                anyFilterSet = true;
            }

            if (Properties.Settings.Default.FilterHideServers?.Any() ?? false)
            {
                creatures = creatures.Where(c => !Properties.Settings.Default.FilterHideServers.Contains(c.server ?? string.Empty));
                anyFilterSet = true;
            }

            if (Properties.Settings.Default.FilterOnlyIfColorId != 0)
            {
                creatures = creatures.Where(c => c.colors.Contains(Properties.Settings.Default.FilterOnlyIfColorId));
                anyFilterSet = true;
            }

            if (Properties.Settings.Default.FilterHideAdults)
            {
                creatures = creatures.Where(c => c.Maturation < 1);
                anyFilterSet = true;
            }

            if (Properties.Settings.Default.FilterHideNonAdults)
            {
                creatures = creatures.Where(c => c.Maturation >= 1);
                anyFilterSet = true;
            }

            if (Properties.Settings.Default.FilterHideCooldowns)
            {
                creatures = creatures.Where(c => c.cooldownUntil == null || c.cooldownUntil < DateTime.Now);
                anyFilterSet = true;
            }

            if (Properties.Settings.Default.FilterHideNonCooldowns)
            {
                creatures = creatures.Where(c => c.cooldownUntil != null && c.cooldownUntil > DateTime.Now);
                anyFilterSet = true;
            }

            // tags filter
            if (Properties.Settings.Default.FilterHideTags?.Any() ?? false)
            {
                bool hideCreaturesWOTags = Properties.Settings.Default.FilterHideTags.Contains(string.Empty);
                creatures = creatures.Where(c =>
                    !hideCreaturesWOTags && c.tags.Count == 0 ||
                    c.tags.Except(Properties.Settings.Default.FilterHideTags).Any());
                anyFilterSet = true;
            }

            // hide creatures with the set hide flags
            if (Properties.Settings.Default.FilterFlagsExclude != 0)
            {
                creatures = creatures.Where(c => ((int)c.flags & Properties.Settings.Default.FilterFlagsExclude) == 0);
                anyFilterSet = true;
            }
            if (Properties.Settings.Default.FilterFlagsAllNeeded != 0)
            {
                creatures = creatures.Where(c => ((int)c.flags & Properties.Settings.Default.FilterFlagsAllNeeded) == Properties.Settings.Default.FilterFlagsAllNeeded);
                anyFilterSet = true;
            }
            if (Properties.Settings.Default.FilterFlagsOneNeeded != 0)
            {
                int flagsOneNeeded = Properties.Settings.Default.FilterFlagsOneNeeded |
                                     Properties.Settings.Default.FilterFlagsAllNeeded;
                creatures = creatures.Where(c => ((int)c.flags & flagsOneNeeded) != 0);
                anyFilterSet = true;
            }

            libraryFilterToolStripMenuItem.BackColor = anyFilterSet ? UiColors.Current.FilterActive : SystemColors.Control;

            return creatures;
        }

        private void listBoxSpeciesLib_Click(object sender, EventArgs e)
        {
            if (!(ModifierKeys == Keys.Control && listBoxSpeciesLib.SelectedItem is Species species)) return;

            Values.V.ToggleSpeciesFavorite(species);
            UpdateSpeciesLists(_creatureCollection.creatures);
        }

        private void listViewLibrary_KeyDown(object sender, KeyEventArgs e)
        {
            int index;
            switch (e.KeyCode)
            {
                case Keys.NumPad1:
                    index = 0;
                    break;
                case Keys.NumPad2:
                    index = 1;
                    break;
                case Keys.NumPad3:
                    index = 2;
                    break;
                case Keys.NumPad4:
                    index = 3;
                    break;
                case Keys.NumPad5:
                    index = 4;
                    break;
                case Keys.NumPad6:
                    index = 5;
                    break;
                default: return;
            }

            if (Keyboard.Modifiers.HasFlag(System.Windows.Input.ModifierKeys.Control))
                CopyCreatureNamePatternToClipboard(index);
            else GenerateCreatureNames(index, true);

            e.Handled = true;
            e.SuppressKeyPress = true;
        }

        private void listViewLibrary_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Delete:
                    DeleteSelectedCreatures();
                    break;
                case Keys.A when e.Control:
                    // select all list-entries
                    _reactOnCreatureSelectionChange = false;
                    listViewLibrary.BeginUpdate();
                    listViewLibrary.SelectAllItems();
                    listViewLibrary.EndUpdate();
                    _reactOnCreatureSelectionChange = true;
                    listViewLibrary_SelectedIndexChanged(null, null);
                    break;
                case Keys.B when e.Control:
                    CopyFocusedCreatureName();
                    break;
                case Keys.C when e.Control:
                    CopySelectedCreatureFromLibraryToClipboard(false);
                    break;
                case Keys.V when e.Control:
                    PasteCreatureFromClipboard();
                    break;
                default: return;
            }

            e.Handled = true;
        }

        /// <summary>
        /// Copies the data of the selected creatures to the clipboard for use in a spreadsheet.
        /// </summary>
        private void ExportForSpreadsheet()
        {
            if (tabControlMain.SelectedTab == tabPageLibrary)
            {
                if (Properties.Settings.Default.CreatureTableExportFields?.Any() == false)
                {
                    if (MessageBox.Show("No fields for the table export selected.\nDo you want to go to the options to edit the export fields?", "No Export Fields set",
                         MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        OpenSettingsDialog(Settings.SettingsTabPages.General);
                    return;
                }
                if (listViewLibrary.SelectedIndices.Count > 0)
                {
                    var exportCount = ExportImportCreatures.ExportTable(listViewLibrary.SelectedIndices.Cast<int>().Select(i => _creaturesDisplayed[i]).ToArray());
                    if (exportCount != 0)
                        SetMessageLabelText($"{exportCount} creatures were exported to the clipboard for pasting in a spreadsheet.", MessageBoxIcon.Information);

                    return;
                }
                MessageBox.Show("No creatures in the library selected to copy to the clipboard", "No Creatures Selected",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (tabControlMain.SelectedTab == tabPageExtractor)
                CopyExtractionToClipboard();
        }

        private void editSpreadsheetExportFieldsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenSettingsDialog(Settings.SettingsTabPages.General);
        }

        /// <summary>
        /// Display a window to edit multiple creatures at once. Also used to set tags.
        /// </summary>
        private void ShowMultiSetter()
        {
            // shows a dialog to set multiple settings to all selected creatures
            if (listViewLibrary.SelectedIndices.Count <= 0)
                return;
            List<Creature> selectedCreatures = new List<Creature>();

            // check if multiple species are selected
            bool multipleSpecies = false;
            Species sp = _creaturesDisplayed[listViewLibrary.SelectedIndices[0]].Species;
            foreach (int i in listViewLibrary.SelectedIndices)
            {
                var cr = _creaturesDisplayed[i];
                selectedCreatures.Add(cr);
                if (!multipleSpecies && cr.speciesBlueprint != sp.blueprintPath)
                {
                    multipleSpecies = true;
                }
            }
            List<Creature>[] parents = null;
            if (!multipleSpecies)
                parents = FindPossibleParents(new Creature(sp));

            using (MultiSetter ms = new MultiSetter(selectedCreatures,
                parents,
                _creatureCollection.tags,
                Values.V.Species,
                _creatureCollection.ownerList,
                _creatureCollection.tribes.Select(t => t.TribeName).ToArray(),
                _creatureCollection.serverList))
            {
                if (ms.ShowDialog() == DialogResult.OK)
                {
                    if (ms.ParentsChanged)
                        UpdateParents(selectedCreatures);
                    if (ms.TagsChanged)
                        CreateCreatureTagList();
                    if (ms.SpeciesChanged)
                    {
                        UpdateSpeciesLists(_creatureCollection.creatures);
                        foreach (var c in selectedCreatures)
                            c.RecalculateCreatureValues(_creatureCollection.wildLevelStep);
                    }
                    UpdateOwnerServerTagLists();
                    SetCollectionChanged(true, !multipleSpecies ? sp : null);
                    RecalculateTopStatsIfNeeded();
                    FilterLibRecalculate();
                }
            }
        }

        private readonly Debouncer _filterLibraryDebouncer = new Debouncer();

        private void ToolStripTextBoxLibraryFilter_TextChanged(object sender, EventArgs e)
        {
            _filterLibraryDebouncer.Debounce(ToolStripTextBoxLibraryFilter.Text == string.Empty ? 0 : 500, FilterLib, Dispatcher.CurrentDispatcher, false);
        }

        private void ToolStripButtonLibraryFilterClear_Click(object sender, EventArgs e)
        {
            if (_libraryFilterTemplates != null && !_libraryFilterTemplates.IsDisposed)
                _libraryFilterTemplates.ControlVisibility = false;
            ToolStripTextBoxLibraryFilter.Clear();
            ToolStripTextBoxLibraryFilter.Focus();
        }

        /// <summary>
        /// User can select a folder where infoGraphics for all selected creatures are saved.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void saveInfographicsToFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewLibrary.SelectedIndices.Count == 0) return;

            try
            {
                var initialFolder = Properties.Settings.Default.InfoGraphicExportFolder;
                if (string.IsNullOrEmpty(initialFolder) || !Directory.Exists(initialFolder))
                    initialFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                string folderPath = null;
                using (var fs = new FolderBrowserDialog
                {
                    SelectedPath = initialFolder
                })
                {
                    if (fs.ShowDialog() == DialogResult.OK)
                        folderPath = fs.SelectedPath;
                }

                if (string.IsNullOrEmpty(folderPath) || !Directory.Exists(folderPath)) return;

                Properties.Settings.Default.InfoGraphicExportFolder = folderPath;

                // test if files can be written to the folder
                var testFileName = "testFile.txt";
                try
                {
                    var testFilePath = Path.Combine(folderPath, testFileName);
                    File.WriteAllText(testFilePath, string.Empty);
                    FileService.TryDeleteFile(testFilePath);
                }
                catch (UnauthorizedAccessException ex)
                {
                    MessageBoxes.ExceptionMessageBox(ex, $"The selected folder\n{folderPath}\nis protected, the files cannot be saved there. Select a different folder.");
                    return;
                }

                var imagesCreated = 0;
                string firstImageFilePath = null;

                foreach (int i in listViewLibrary.SelectedIndices)
                {
                    var c = _creaturesDisplayed[i];

                    var fileName = $"{c.SpeciesName}_{(string.IsNullOrEmpty(c.name) ? c.guid.ToString() : c.name)}";
                    fileName = FileService.ReplaceInvalidCharacters(fileName);

                    var filePath = Path.Combine(folderPath, $"ARK_info_{fileName}.png");

                    if (File.Exists(filePath))
                    {
                        switch (MessageBox.Show($"The file\n{filePath}\nalready exists.\nOverwrite the file?", "File exists already", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning))
                        {
                            case DialogResult.No: continue;
                            case DialogResult.Yes: break;
                            default: return;
                        }
                    }
                    (await c.InfoGraphicAsync(_creatureCollection)).Save(filePath);
                    if (firstImageFilePath == null) firstImageFilePath = filePath;

                    imagesCreated++;
                }

                if (imagesCreated == 0) return;

                var pluralS = imagesCreated != 1 ? "s" : string.Empty;
                SetMessageLabelText($"Infographic{pluralS} for {imagesCreated} creature{pluralS} created at\r\n{(imagesCreated == 1 ? firstImageFilePath : folderPath)}", MessageBoxIcon.Information, firstImageFilePath);
            }
            catch (Exception ex)
            {
                MessageBoxes.ExceptionMessageBox(ex);
            }
        }

        private async void saveStitchedInfographicsToFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewLibrary.SelectedIndices.Count == 0) return;
            if (listViewLibrary.SelectedIndices.Count > 100
                && MessageBox.Show($"Creating {listViewLibrary.SelectedIndices.Count} images could take some time, do you want to start the process?",
                    "ARK Smart Breeding Infographic creation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

            try
            {
                var lastFilePath = Properties.Settings.Default.InfoGraphicStitchLastFilePath;
                var initialFolder = !string.IsNullOrEmpty(lastFilePath) ? Path.GetDirectoryName(Properties.Settings.Default.InfoGraphicStitchLastFilePath) : Properties.Settings.Default.InfoGraphicExportFolder;
                if (string.IsNullOrEmpty(initialFolder) || !Directory.Exists(initialFolder))
                    initialFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                string filePathSaveTo = null;
                using (var fs = new SaveFileDialog
                {
                    InitialDirectory = initialFolder,
                    FileName = string.IsNullOrEmpty(lastFilePath) ? string.Empty : Path.GetFileName(lastFilePath),
                    Filter = "Image Files|*.jpg;*.jpeg;*.png|All Files|*.*"
                })
                {
                    if (fs.ShowDialog() != DialogResult.OK || string.IsNullOrEmpty(fs.FileName))
                        return;
                    filePathSaveTo = fs.FileName;
                }

                Properties.Settings.Default.InfoGraphicStitchLastFilePath = filePathSaveTo;

                await InvokeAsync(() =>
                {
                    ToolStripStatusLabelImport.Text = "Creating infographics";
                    ToolStripStatusLabelImport.Visible = true;
                });
                var creatures = (from int i in listViewLibrary.SelectedIndices select _creaturesDisplayed[i]).ToArray();
                var imagesCreated = await Task.Run(() => InfoGraphic.Stitching.CreateStitchedImages(creatures, _creatureCollection,
                    filePathSaveTo, Properties.Settings.Default.InfoGraphicStitchMaxWidth, Properties.Settings.Default.InfoGraphicStitchBackground, Properties.Settings.Default.InfoGraphicStitchGap));

                var pluralS = imagesCreated != 1 ? "s" : string.Empty;
                SetMessageLabelText(
                    $"Infographic{pluralS} for {imagesCreated} creature{pluralS} created at\r\n{filePathSaveTo}",
                    MessageBoxIcon.Information, filePathSaveTo);
            }
            catch (Exception ex)
            {
                MessageBoxes.ExceptionMessageBox(ex, "Error while creating multiple infographics.");
            }
            finally
            {
                ToolStripStatusLabelImport.Visible = false;
            }
        }

        #region Library ContextMenu

        private void toolStripMenuItemEdit_Click(object sender, EventArgs e)
        {
            if (TryGetSelectedLibraryCreature(out var c))
                EditCreatureInTester(c);
        }

        private void toolStripMenuItemRemove_Click(object sender, EventArgs e)
        {
            DeleteSelectedCreatures();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            SetStatusOfSelectedCreatures(CreatureStatus.Available);
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            SetStatusOfSelectedCreatures(CreatureStatus.Unavailable);
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            SetStatusOfSelectedCreatures(CreatureStatus.Dead);
        }

        private void obeliskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetStatusOfSelectedCreatures(CreatureStatus.Obelisk);
        }

        private void cryopodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetStatusOfSelectedCreatures(CreatureStatus.Cryopod);
        }

        private void currentValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (TryGetSelectedLibraryCreature(out var c))
                SetCreatureValuesToExtractor(c);
        }

        private void wildValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (TryGetSelectedLibraryCreature(out var c))
                SetCreatureValuesToExtractor(c, true);
        }

        private void SetMatureBreedingStateOfSelectedCreatures(bool setMaturity = false, double maturity = 1, bool clearMatingCooldown = false,
            bool justMated = false)
        {
            listViewLibrary.BeginUpdate();
            foreach (int i in listViewLibrary.SelectedIndices)
            {
                var c = _creaturesDisplayed[i];
                if (setMaturity)
                    c.Maturation = maturity;

                if (clearMatingCooldown && c.cooldownUntil > DateTime.Now)
                    c.cooldownUntil = null;

                if (justMated)
                    c.cooldownUntil = DateTime.Now.AddSeconds(c.Species.breeding?.matingCooldownMinAdjusted ?? 0);

                UpdateCreatureListViewItem(c);
            }

            breedingPlan1.BreedingPlanNeedsUpdate = true;
            listViewLibrary.EndUpdate();
        }

        private void SetMaturityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetMatureBreedingStateOfSelectedCreatures(setMaturity: true, maturity: ((ToolStripMenuItem)sender).Tag is double d ? d : 1);
        }

        private void clearMatingCooldownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetMatureBreedingStateOfSelectedCreatures(clearMatingCooldown: true);
        }

        private void justMatedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetMatureBreedingStateOfSelectedCreatures(justMated: true);
        }

        private void applyMutagenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewLibrary.SelectedIndices.Count == 0
               || MessageBox.Show("Set the mutagen flag on the selected creatures and increase their levels accordingly?",
                   "Apply mutagen?", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes
               ) return;

            // a tamed creature receives 5 level in hp, st, we, dm (i.e. a total of 20 levels)
            // a bred creature receives 1 level in hp, st, we, dm (i.e. a total of 4 levels)

            bool libraryChanged = false;
            var affectedSpeciesBlueprints = new List<string>();

            var statCountAffectedByMutagen = Ark.StatIndicesAffectedByMutagen.Length;

            foreach (int i in listViewLibrary.SelectedIndices)
            {
                var c = _creaturesDisplayed[i];

                if (!c.isDomesticated
                    || c.flags.HasFlag(CreatureFlags.MutagenApplied)) continue;

                var levelIncrease = c.isBred ? Ark.MutagenLevelUpsBred : Ark.MutagenLevelUpsNonBred;

                foreach (var si in Ark.StatIndicesAffectedByMutagen)
                    c.levelsWild[si] += levelIncrease;
                c.levelsWild[Stats.Torpidity] += statCountAffectedByMutagen * levelIncrease;

                c.flags |= CreatureFlags.MutagenApplied;

                libraryChanged = true;
                if (!affectedSpeciesBlueprints.Contains(c.speciesBlueprint))
                    affectedSpeciesBlueprints.Add(c.speciesBlueprint);
            }

            if (!libraryChanged) return;

            // update list / recalculate topStats
            CalculateTopStats(_creatureCollection.creatures
                .Where(c => affectedSpeciesBlueprints.Contains(c.speciesBlueprint)).ToList());
            FilterLibRecalculate();
            UpdateStatusBar();
            SetCollectionChanged(true,
                affectedSpeciesBlueprints.Count == 1 ? Values.V.SpeciesByBlueprint(affectedSpeciesBlueprints.First()) : null);
        }

        private void BtRecalculateTopStatsAfterChange_Click(object sender, EventArgs e)
        {
            // Recalculate top stats after considered stats have changed.
            CalculateTopStats(_creatureCollection.creatures);
            FilterLibRecalculate();
        }

        private void adminCommandToSetColorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (TryGetSelectedLibraryCreature(out var cr))
                ArkConsoleCommands.AdminCommandToSetColors(cr.colors, cr.Species);
        }

        private void adminCommandToSpawnExactDinoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (TryGetSelectedLibraryCreature(out var c))
                CreateExactSpawnCommand(c);
        }

        private void adminCommandToSpawnExactDinoDS2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (TryGetSelectedLibraryCreature(out var c))
                CreateExactSpawnDS2Command(c);
        }

        private void adminCommandSetMutationLevelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (TryGetSelectedLibraryCreature(out var c))
                CreateExactMutationLevelCommand(c);
        }

        private void exactSpawnCommandToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var cr = GetCreatureFromExtractorOrTesterOrLibrary();
            if (cr != null)
                CreateExactSpawnCommand(cr);
        }

        private void exactSpawnCommandDS2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var cr = GetCreatureFromExtractorOrTesterOrLibrary();
            if (cr != null)
                CreateExactSpawnDS2Command(cr);
        }

        private void commandMutationLevelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var cr = GetCreatureFromExtractorOrTesterOrLibrary();
            if (cr != null)
                CreateExactMutationLevelCommand(cr);
        }

        /// <summary>
        /// Returns the creature currently set in the extractor or testing tab, depending on which tab is active.
        /// </summary>
        private Creature GetCreatureFromExtractorOrTesterOrLibrary()
        {
            if (tabControlMain.SelectedTab == tabPageExtractor)
                return CreateCreatureFromExtractorOrTester(creatureInfoInputExtractor);
            if (tabControlMain.SelectedTab == tabPageStatTesting)
                return CreateCreatureFromExtractorOrTester(creatureInfoInputTester);
            if (tabControlMain.SelectedTab == tabPageLibrary)
                return TryGetSelectedLibraryCreature(out var c) ? c : null;
            return null;
        }

        private void CreateExactSpawnCommand(Creature cr)
        {
            ArkConsoleCommands.UnstableSpawnCommandToClipboard(cr, _creatureCollection.Game);
        }

        private void CreateExactSpawnDS2Command(Creature cr)
        {
            ArkConsoleCommands.DinoStorageV2CommandToClipboard(cr);
        }

        private void CreateExactMutationLevelCommand(Creature cr)
        {
            ArkConsoleCommands.MutationLevelCommandToClipboard(cr);
        }

        #endregion

        #region LibraryFilterPresets

        private LibraryFilterTemplates _libraryFilterTemplates;

        private void ToolStripButtonSaveFilterPresetClick(object sender, EventArgs e)
        {
            var text = ToolStripTextBoxLibraryFilter.Text.Trim();
            if (string.IsNullOrEmpty(text)) return;

            var presets = Properties.Settings.Default.LibraryFilterPresets;
            if (presets != null && presets.Contains(text)) return;

            int oldLength = presets?.Length ?? 0;
            var newPresets = new string[oldLength + 1];
            if (presets != null)
                Array.Copy(presets, newPresets, oldLength);
            newPresets[oldLength] = text;

            Properties.Settings.Default.LibraryFilterPresets = newPresets;
            _libraryFilterTemplates?.AddPreset(text);
        }

        private void ToolStripTextBoxLibraryFilter_Click(object sender, EventArgs e)
        {
            ToggleLibraryFilterPresets();
            ToolStripTextBoxLibraryFilter.Focus();
        }

        private void ToggleLibraryFilterPresets()
        {
            if (_libraryFilterTemplates == null || _libraryFilterTemplates.IsDisposed)
            {
                if (Properties.Settings.Default.LibraryFilterPresets == null)
                    return;

                _libraryFilterTemplates = new LibraryFilterTemplates
                {
                    Presets = Properties.Settings.Default.LibraryFilterPresets
                };
                _libraryFilterTemplates.StringSelected += _libraryFilterTemplates_StringSelected;
                _libraryFilterTemplates.Location = new Point(Location.X + ToolStripTextBoxLibraryFilter.Bounds.X, Location.Y + ToolStripTextBoxLibraryFilter.Bounds.Bottom + 60);
                _libraryFilterTemplates.Show(this);
                return;
            }

            _libraryFilterTemplates.ControlVisibility = !_libraryFilterTemplates.Visible;
        }

        private void _libraryFilterTemplates_StringSelected(string filterPreset)
        {
            ToolStripTextBoxLibraryFilter.Text = filterPreset;
            _libraryFilterTemplates.ControlVisibility = false;
        }

        #endregion

        private void importFromTabSeparatedFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string filePath = null;
            using (var ofd = new OpenFileDialog
            {
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                CheckFileExists = true
            })
            {
                if (ofd.ShowDialog(this) == DialogResult.OK)
                    filePath = ofd.FileName;
            }

            if (string.IsNullOrEmpty(filePath)) return;

            if (!ExportImportCreatures.ImportCreaturesFromTsvFile(filePath, out var creatures, out var result))
            {
                MessageBoxes.ShowMessageBox(result, "Error while importing from tsv file");
                return;
            }

            _creatureCollection.MergeCreatureList(creatures);

            // update UI
            UpdateCreatureListings();
            SetCollectionChanged(true);

            if (_creatureCollection.creatures.Any())
                tabControlMain.SelectedTab = tabPageLibrary;

            // reapply last sorting
            SortLibrary();

            MessageBoxes.ShowMessageBox(result, "Creatures imported from tsv file", MessageBoxIcon.Information);
        }

        private void GenerateCreatureNames(object sender, EventArgs e) => GenerateCreatureNames((int)((ToolStripMenuItem)sender).Tag, false);

        /// <summary>
        /// Replaces the names of the selected creatures with a pattern generated name.
        /// </summary>
        private void GenerateCreatureNames(int namePatternIndex, bool askForConfirmation)
        {
            if (listViewLibrary.SelectedIndices.Count == 0
                || string.IsNullOrEmpty(Properties.Settings.Default.NamingPatterns?[namePatternIndex])
                || (askForConfirmation
                    && MessageBox.Show($"Apply the naming pattern {namePatternIndex + 1} to the selected creatures?",
                    "Apply naming pattern?", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
                )
                return;

            var creaturesToUpdate = new List<Creature>();
            Creature[] sameSpecies = null;
            var libraryCreatureCount = _creatureCollection.GetTotalCreatureCount();
            string lastGeneratedName = null;

            foreach (int i in listViewLibrary.SelectedIndices)
            {
                var cr = _creaturesDisplayed[i];
                if (cr.Species == null) continue;

                if (sameSpecies?.FirstOrDefault()?.Species != cr.Species)
                    sameSpecies = _creatureCollection.creatures.Where(c => c.Species == cr.Species).ToArray();

                // set new name
                lastGeneratedName = NamePattern.GenerateCreatureName(cr, cr, sameSpecies, _creatureCollection.TopLevels.TryGetValue(cr.Species, out var tl) ? tl : null,
                    _customReplacingNamingPattern, false, namePatternIndex,
                    Properties.Settings.Default.DisplayWarningAboutTooLongNameGenerated, libraryCreatureCount: libraryCreatureCount);
                cr.name = lastGeneratedName;

                creaturesToUpdate.Add(cr);
            }

            listViewLibrary.BeginUpdate();
            foreach (var cr in creaturesToUpdate)
                UpdateDisplayedCreatureValues(cr, false, false);

            listViewLibrary.EndUpdate();
            if (Properties.Settings.Default.CopyNameToClipboardWhenAppliedInLibrary)
                ClipboardHandler.SetText(lastGeneratedName);
        }
        private void CopyGeneratedNamePatternToClipboard(object sender, EventArgs e) => CopyCreatureNamePatternToClipboard((int)((ToolStripMenuItem)sender).Tag);

        private void CopyCreatureNamePatternToClipboard(int namePatternIndex)
        {
            if (TryGetSelectedLibraryCreature(out var creature))
                CopyCreatureNamePatternToClipboard(creature, namePatternIndex);
        }

        internal void CopyCreatureNamePatternToClipboard(Creature creature, int namePatternIndex)
        {
            if (creature == null) return;
            var generatedName = GenerateSingleCreatureNamePattern(creature, namePatternIndex);
            if (string.IsNullOrEmpty(generatedName))
            {
                SetMessageLabelText($"Generated name for creature {creature} using pattern {namePatternIndex + 1} resulted in an empty name, nothing was copied to the clipboard.", MessageBoxIcon.Error);
                return;
            }
            if (utils.ClipboardHandler.SetText(generatedName, out var error))
                SetMessageLabelText($"Copied generated name of creature {creature} using pattern {namePatternIndex + 1} to the clipboard.{Environment.NewLine}The generated name is: {generatedName}");
            else SetMessageLabelText($"Error while trying to copy name to clipboard. Error: {error}", MessageBoxIcon.Error);
        }

        private string GenerateSingleCreatureNamePattern(Creature creature, int namePatternIndex)
        {
            var libraryCreatureCount = _creatureCollection.GetTotalCreatureCount();

            if (creature.Species == null) return null;
            var sameSpecies = _creatureCollection.creatures.Where(c => !c.flags.HasFlag(CreatureFlags.Placeholder) && c.Species == creature.Species).ToArray();

            return NamePattern.GenerateCreatureName(creature, creature, sameSpecies, _creatureCollection.TopLevels.TryGetValue(creature.Species, out var tl) ? tl : null,
                _customReplacingNamingPattern, false, namePatternIndex,
                false, libraryCreatureCount: libraryCreatureCount);
        }

        #region library list view columns

        private void resetColumnOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listViewLibrary.BeginUpdate();
            var colIndices = new[] { 1, 2, 4, 5, 6, 36, 31, 32, 33, 34, 35, 37, 7, 9, 29, 11, 13, 15, 17, 19, 21, 23, 25, 27, 8, 10, 30, 12, 14, 16, 18, 20, 22, 24, 26, 28, 40, 41, 42, 43, 44, 45, 46, 38, 3, 0, 39 };

            // indices have to be set increasingly, or they will "push" other values up
            var colIndicesOrdered = colIndices.Select((i, c) => (columnIndex: c, displayIndex: i))
                .OrderBy(c => c.displayIndex).ToArray();
            for (int c = 0; c < colIndicesOrdered.Length && c < listViewLibrary.Columns.Count; c++)
                listViewLibrary.Columns[colIndicesOrdered[c].columnIndex].DisplayIndex = colIndicesOrdered[c].displayIndex;

            listViewLibrary.EndUpdate();
        }

        private void toolStripMenuItemResetLibraryColumnWidths_Click(object sender, EventArgs e)
        {
            ResetColumnWidthListViewLibrary(false);
        }

        private void resetColumnWidthNoMutationLevelColumnsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetColumnWidthListViewLibrary(true);
        }

        private void restoreMutationLevelsASAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ToggleLibraryMutationLevelColumns(true, true);
        }

        private void collapseMutationsLevelsASEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ToggleLibraryMutationLevelColumns(false);
        }

        private void ResetColumnWidthListViewLibrary(bool mutationColumnWidthsZero)
        {
            listViewLibrary.BeginUpdate();
            var statWidths = Stats.UsuallyVisibleStats.Select(w => w ? 30 : 0).ToArray();
            for (int ci = 0; ci < listViewLibrary.Columns.Count; ci++)
                listViewLibrary.Columns[ci].Width = ci == ColumnIndexMutagenApplied ? 30
                    : ci < ColumnIndexFirstStat || ci >= ColumnIndexPostColor ? 60
                    : ci >= ColumnIndexFirstStat + Stats.StatsCount + Stats.StatsCount ? 30 // color
                    : ci < ColumnIndexFirstStat + Stats.StatsCount ? statWidths[ci - ColumnIndexFirstStat] // wild levels
                    : ci - ColumnIndexFirstStat - Stats.StatsCount == Stats.Torpidity ? 0 // no mutations for torpidity
                    : (int)(statWidths[ci - ColumnIndexFirstStat - Stats.StatsCount] * 1.24); // mutated needs space for one more letter

            // save in settings so it can be used when toggle the mutation columns, which use the settings
            var widths = new int[listViewLibrary.Columns.Count];
            for (int c = 0; c < widths.Length; c++)
                widths[c] = listViewLibrary.Columns[c].Width;
            Properties.Settings.Default.columnWidths = widths;

            if (mutationColumnWidthsZero)
                ToggleLibraryMutationLevelColumns(false);

            listViewLibrary.EndUpdate();
        }

        private void toolStripMenuItemMutationColumns_CheckedChanged(object sender, EventArgs e)
        {
            var showMutationColumns = toolStripMenuItemMutationColumns.Checked;
            Properties.Settings.Default.LibraryShowMutationLevelColumns = showMutationColumns;
            ToggleLibraryMutationLevelColumns(showMutationColumns);
        }

        /// <summary>
        /// Set width of library mutation level columns to 0 or restore.
        /// </summary>
        private void ToggleLibraryMutationLevelColumns(bool show, bool resetWidth = false)
        {
            var widths = Properties.Settings.Default.columnWidths;
            if (widths == null || widths.Length < ColumnIndexFirstStat + 2 * Stats.StatsCount)
            {
                SaveListViewSettings(listViewLibrary, nameof(Properties.Settings.columnWidths), nameof(Properties.Settings.libraryColumnDisplayIndices));
                widths = Properties.Settings.Default.columnWidths;
            }

            listViewLibrary.BeginUpdate();
            if (show)
            {
                if (resetWidth)
                {
                    var mutationStatWidths = Stats.UsuallyVisibleStats.Select((v, i) => v && i != Stats.Torpidity ? 37 : 0).ToArray();
                    mutationStatWidths.CopyTo(widths, ColumnIndexFirstStat + Stats.StatsCount);
                }

                for (int ci = ColumnIndexFirstStat + Stats.StatsCount; ci < ColumnIndexFirstStat + 2 * Stats.StatsCount; ci++)
                    listViewLibrary.Columns[ci].Width = widths[ci];
            }
            else
            {
                for (int ci = ColumnIndexFirstStat + Stats.StatsCount; ci < ColumnIndexFirstStat + 2 * Stats.StatsCount; ci++)
                {
                    widths[ci] = listViewLibrary.Columns[ci].Width;
                    listViewLibrary.Columns[ci].Width = 0;
                }
            }
            listViewLibrary.EndUpdate();
        }

        #endregion

        private void editTraitsToolStripMenuItem_Click(object sender, EventArgs e) => EditTraitsOfSelectedCreaturesInLibrary();

        private void EditTraitsOfSelectedCreaturesInLibrary()
        {
            if (listViewLibrary.SelectedIndices.Count == 0) return;
            EditTraits(listViewLibrary.SelectedIndices.Cast<int>().Select(i => _creaturesDisplayed[i]).ToArray());
        }

        private void EditTraits(IList<Creature> creatures)
        {
            if (creatures?.Any() != true) return;
            if (!TraitSelection.ShowTraitSelectionWindow(creatures[0].Traits?.ToList(),
                $"Trait Selection for {creatures[0].name} ({creatures[0].Species}){(creatures.Count > 1 ? $" and {creatures.Count - 1} other creature{(creatures.Count > 2 ? "s" : string.Empty)}" : string.Empty)}",
                out var appliedTraits))
                return;

            foreach (int i in listViewLibrary.SelectedIndices)
            {
                _creaturesDisplayed[i].Traits = appliedTraits?.ToArray();
            }
            // update list display
            FilterLib();
        }

        private void viewColorsInLibraryInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!TryGetSelectedLibraryCreature(out var c)) return;
            libraryInfoControl1.SetSpecies(c.Species, false);
            libraryInfoControl1.SetColors(c.colors.ToArray());
            tabControlMain.SelectedTab = tabPageLibraryInfo;
        }

        /// <summary>
        /// Returns the currently focused creature in the library if it is also selected, else it will return the first selected creature.
        /// </summary>
        private bool TryGetSelectedLibraryCreature(out Creature creature)
        {
            if (listViewLibrary.SelectedIndices.Count == 0)
            {
                creature = null;
                return false;
            }

            var focusedIndex = listViewLibrary.FocusedItem?.Index ?? -1;
            var useIndex = focusedIndex >= 0 && listViewLibrary.SelectedIndices.Contains(focusedIndex)
                ? focusedIndex
                : listViewLibrary.SelectedIndices[0];
            creature = _creaturesDisplayed[useIndex];
            return true;
        }

        private void ViewLibraryWithFilter(string libraryFilter)
        {
            tabControlMain.SelectedTab = tabPageLibrary;
            ToolStripTextBoxLibraryFilter.Text = libraryFilter;
        }
    }
}
