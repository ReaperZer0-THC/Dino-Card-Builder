﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Threading;
using ARKBreedingStats.Library;
using ARKBreedingStats.Pedigree;
using ARKBreedingStats.Properties;
using ARKBreedingStats.raising;
using ARKBreedingStats.species;
using ARKBreedingStats.uiControls;
using ARKBreedingStats.utils;
using ARKBreedingStats.values;
using static ARKBreedingStats.uiControls.StatWeighting;
using System.ComponentModel;

namespace ARKBreedingStats.BreedingPlanning
{
    public partial class BreedingPlan : UserControl
    {
        public event Action<Creature, bool> EditCreature;
        public event Action<Creature> BestBreedingPartners;
        public event Action<Creature> DisplayInPedigree;
        public event Action<Creature, Creature> PairMated;
        public event Raising.createIncubationEventHandler CreateIncubationTimer;
        public event Form1.SetMessageLabelTextEventHandler SetMessageLabelText;
        public event Action<Species> SetGlobalSpecies;
        private Creature[] _females;
        private Creature[] _males;
        private List<BreedingPair> _breedingPairs;
        private Species _currentSpecies;
        /// <summary>
        /// How much are the stats weighted when looking for the best
        /// </summary>
        private double[] _statWeights = new double[Stats.StatsCount];
        /// <summary>
        /// Indicates if high stats are only considered if any, odd or even.
        /// </summary>
        private StatValueEvenOdd[] _statOddEvens = new StatValueEvenOdd[Stats.StatsCount];
        /// <summary>
        /// The best possible levels of the selected species for each stat.
        /// If the weighting is negative, a low level is considered better.
        /// </summary>
        private readonly int[] _bestLevelsWild = new int[Stats.StatsCount];
        /// <summary>
        /// The best possible levels of the selected species for each stat, after the filters are applied.
        /// If the weighting is negative, a low level is considered better.
        /// </summary>
        private readonly int[] _bestLevelsFiltered = new int[Stats.StatsCount];
        /// <summary>
        /// The best possible mutation levels of the selected species for each stat.
        /// If the weighting is negative, a low level is considered better.
        /// </summary>
        private readonly int[] _bestLevelsMutated = new int[Stats.StatsCount];
        /// <summary>
        /// The best possible mutation levels of the selected species for each stat, after the filters are applied.
        /// If the weighting is negative, a low level is considered better.
        /// </summary>
        private readonly int[] _bestLevelsMutatedFiltered = new int[Stats.StatsCount];

        private readonly List<PedigreeCreature> _pcs = new List<PedigreeCreature>();
        private readonly List<PictureBox> _pbs = new List<PictureBox>();
        private bool[] _enabledColorRegions;
        private TimeSpan _incubationTime;
        private Creature _chosenCreature;
        private BreedingScore.BreedingMode _breedingMode;
        public readonly StatWeighting StatWeighting;
        public bool BreedingPlanNeedsUpdate;
        private bool _speciesInfoNeedsUpdate;
        private readonly Debouncer _breedingPlanDebouncer = new Debouncer();
        /// <summary>
        /// If that is true, not all creatures of a species are considered, just a manually selected subset.
        /// </summary>
        private bool _onlyShowingASubset;

        /// <summary>
        /// Set to false if settings are changed and update should only be performed after that.
        /// </summary>
        private bool _updateBreedingPlanAllowed;
        public CreatureCollection CreatureCollection;
        private readonly ToolTip _tt = new ToolTip { AutoPopDelay = 10000 };

        public BreedingPlan()
        {
            InitializeComponent();
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            for (int i = 0; i < Stats.StatsCount; i++)
                _statWeights[i] = 1;

            _breedingMode = BreedingScore.BreedingMode.TopStatsConservative;

            _breedingPairs = new List<BreedingPair>();
            pedigreeCreatureBest.SetIsVirtual(true);
            pedigreeCreatureWorst.SetIsVirtual(true);
            pedigreeCreatureBestPossibleInSpecies.SetIsVirtual(true);
            pedigreeCreatureBestPossibleInSpeciesFiltered.SetIsVirtual(true);
            pedigreeCreatureBest.OnlyLevels = true;
            pedigreeCreatureWorst.OnlyLevels = true;
            pedigreeCreatureBestPossibleInSpecies.OnlyLevels = true;
            pedigreeCreatureBestPossibleInSpeciesFiltered.OnlyLevels = true;
            pedigreeCreatureBest.Clear();
            pedigreeCreatureWorst.Clear();
            pedigreeCreatureBestPossibleInSpecies.Clear();
            pedigreeCreatureBestPossibleInSpeciesFiltered.Clear();
            pedigreeCreatureBest.HandCursor = false;
            pedigreeCreatureWorst.HandCursor = false;
            pedigreeCreatureBestPossibleInSpecies.HandCursor = false;
            pedigreeCreatureBestPossibleInSpeciesFiltered.HandCursor = false;

            StatWeighting = statWeighting1;
            StatWeighting.WeightingsChanged += StatWeighting_WeightingsChanged;
            BreedingPlanNeedsUpdate = false;
            BtRecalculatePlan.Visible = false;

            cbServerFilterLibrary.Checked = Settings.Default.UseServerFilterForBreedingPlan;
            cbOwnerFilterLibrary.Checked = Settings.Default.UseOwnerFilterForBreedingPlan;
            cbBPIncludeCooldowneds.Checked = Settings.Default.IncludeCooldownsInBreedingPlan;
            cbBPIncludeCryoCreatures.Checked = Settings.Default.IncludeCryoedInBreedingPlan;
            cbBPOnlyOneSuggestionForFemales.Checked = Settings.Default.BreedingPlanOnlyBestSuggestionForEachFemale;
            cbBPMutationLimitOnlyOnePartner.Checked = Settings.Default.BreedingPlanOnePartnerMoreMutationsThanLimit;
            CbIgnoreSexInPlanning.Checked = Settings.Default.IgnoreSexInBreedingPlan;
            CbDontSuggestOverLimitOffspring.Checked = Settings.Default.BreedingPlanDontSuggestOverLimitOffspring;
            CbConsiderMutationLevels.Checked = Settings.Default.BreedingPlanConsiderMutatedLevels;
            CbOnlySameSpecies.Checked = Settings.Default.BreedingPlanOnlySameSpecies;

            tagSelectorList1.OnTagChanged += TagSelectorList1_OnTagChanged;

            nudBPMutationLimit.NeutralNumber = -1;
            _updateBreedingPlanAllowed = true;
            _tt.SetToolTip(lbBPProbabilityBest, "Probability to get the desired top stats, ignoring the probability to get other non-top stats");
        }

        private void StatWeighting_WeightingsChanged()
        {
            // check if sign of a weighting changed (then the best levels change)
            bool signChangedOrOddEven = false;
            var newWeightings = StatWeighting.Weightings;
            var newOddEvens = StatWeighting.AnyOddEven;
            for (int s = 0; s < Stats.StatsCount; s++)
            {
                if (_statOddEvens[s] != newOddEvens[s]
                    || Math.Sign(_statWeights[s]) != Math.Sign(newWeightings[s]))
                {
                    signChangedOrOddEven = true;
                    break;
                }
            }
            _statWeights = newWeightings;
            _statOddEvens = newOddEvens;
            if (signChangedOrOddEven) DetermineBestLevels();

            CalculateBreedingScoresAndDisplayPairs();
        }

        private void TagSelectorList1_OnTagChanged()
        {
            CalculateBreedingScoresAndDisplayPairs();
        }

        public void BindChildrenControlEvents()
        {
            // has to be done after the BreedingPlan-class got the binding
            pedigreeCreatureBest.CreatureEdit += EditCreature;
            pedigreeCreatureWorst.CreatureEdit += EditCreature;
            pedigreeCreatureBestPossibleInSpecies.CreatureEdit += EditCreature;
            pedigreeCreatureBestPossibleInSpeciesFiltered.CreatureEdit += EditCreature;
            pedigreeCreatureBest.CreatureClicked += SetBreedingPair;
            pedigreeCreatureWorst.CreatureClicked += SetBreedingPair;
        }

        /// <summary>
        /// Set species or specific creature and calculate the breeding pairs.
        /// </summary>
        public void DetermineBestBreeding(Creature chosenCreature = null, bool forceUpdate = false, Species setSpecies = null, List<Creature> onlyConsiderTheseCreatures = null)
        {
            if (CreatureCollection == null) return;

            _onlyShowingASubset = onlyConsiderTheseCreatures != null && onlyConsiderTheseCreatures.Count > 1;

            Species selectedSpecies = null;
            if (_onlyShowingASubset)
                selectedSpecies = onlyConsiderTheseCreatures[0].Species;
            if (chosenCreature != null)
                selectedSpecies = chosenCreature.Species;
            _speciesInfoNeedsUpdate = false;
            if (selectedSpecies == null)
                selectedSpecies = setSpecies ?? _currentSpecies;
            if (selectedSpecies != null && _currentSpecies != selectedSpecies)
            {
                CurrentSpecies = selectedSpecies;
                _speciesInfoNeedsUpdate = true;

                EnabledColorRegions = _currentSpecies?.EnabledColorRegions;

                BreedingPlanNeedsUpdate = true;
            }

            _statWeights = StatWeighting.Weightings;
            _statOddEvens = StatWeighting.AnyOddEven;

            HashSet<string> includeBpSpecies = null;
            if (_currentSpecies != null)
            {
                includeBpSpecies = new HashSet<string> { _currentSpecies.blueprintPath };
                if (_currentSpecies.matesWith != null && !Settings.Default.BreedingPlanOnlySameSpecies)
                    includeBpSpecies.UnionWith(_currentSpecies.matesWith);
            }

            if (includeBpSpecies != null && (forceUpdate || BreedingPlanNeedsUpdate || _onlyShowingASubset))
            {
                if (_onlyShowingASubset)
                {
                    Creatures = onlyConsiderTheseCreatures.Where(c => includeBpSpecies.Contains(c.speciesBlueprint)
                                                                      && !c.flags.HasFlag(CreatureFlags.Neutered)
                                                                      && !c.flags.HasFlag(CreatureFlags.Placeholder)
                        )
                        .ToList();
                }
                else
                {
                    var includeWithCooldown = cbBPIncludeCooldowneds.Checked;
                    var ignoreBreedingCooldown = _currentSpecies?.NoGender == true; // for hermaphrodites only one partner needs to be not on cooldown
                    Creatures = CreatureCollection.creatures
                        .Where(c => includeBpSpecies.Contains(c.speciesBlueprint)
                                    && !c.flags.HasFlag(CreatureFlags.Neutered)
                                    && !c.flags.HasFlag(CreatureFlags.Placeholder)
                                    && (c.Status == CreatureStatus.Available
                                        || (c.Status == CreatureStatus.Cryopod && cbBPIncludeCryoCreatures.Checked))
                                    && (includeWithCooldown
                                        || !(c.growingUntil > DateTime.Now
                                             || (!ignoreBreedingCooldown && c.cooldownUntil > DateTime.Now))
                                    )
                        )
                        .ToList();
                }
            }

            _chosenCreature = chosenCreature;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private IEnumerable<Creature> FilterByTags(IEnumerable<Creature> cl)
        {
            if (cl == null) return null;

            List<string> excludingTagList = tagSelectorList1.excludingTags;
            List<string> includingTagList = tagSelectorList1.includingTags;

            List<Creature> filteredList = new List<Creature>();

            if (excludingTagList.Any() || cbBPTagExcludeDefault.Checked)
            {
                foreach (Creature c in cl)
                {
                    bool exclude = cbBPTagExcludeDefault.Checked;
                    if (!exclude && excludingTagList.Any())
                    {
                        foreach (string t in c.tags)
                        {
                            if (excludingTagList.Contains(t))
                            {
                                exclude = true;
                                break;
                            }
                        }
                    }
                    if (exclude && includingTagList.Any())
                    {
                        foreach (string t in c.tags)
                        {
                            if (includingTagList.Contains(t))
                            {
                                exclude = false;
                                break;
                            }
                        }
                    }
                    if (!exclude)
                        filteredList.Add(c);
                }
                return filteredList;
            }
            return cl;
        }

        /// <summary>
        /// Update breeding plan with current settings and current species, debounced.
        /// </summary>
        private void CalculateBreedingScoresAndDisplayPairs()
        {
            if (_updateBreedingPlanAllowed && _currentSpecies != null)
                _breedingPlanDebouncer.Debounce(400, DoCalculateBreedingScoresAndDisplayPairs, Dispatcher.CurrentDispatcher);
        }

        private void DoCalculateBreedingScoresAndDisplayPairs()
        {
            if (_currentSpecies == null
                || _females == null
                )
                return;

            this.SuspendDrawingAndLayout();
            ClearControls();

            // chosen Creature (only consider this one for its sex)
            bool considerChosenCreature = _chosenCreature != null;

            bool considerMutationLimit = nudBPMutationLimit.Value >= 0;

            bool creaturesMutationsFilteredOut = false;
            bool noCreaturesWithTopStatsInBothSexes = false;

            // only consider creatures with top stats if breeding for that
            Creature[] females, males;
            if (_breedingMode == BreedingScore.BreedingMode.BestNextGen)
            {
                females = _females;
                males = _males;
            }
            else
            {
                females = _females.Where(c => c.topStatsCountBP > 0).ToArray();
                males = _males?.Where(c => c.topStatsCountBP > 0).ToArray();
                noCreaturesWithTopStatsInBothSexes = !females.Any() || (males?.Any() != true && !_currentSpecies.NoGender);
            }

            // filter by tags
            int crCountF = females.Length;
            int crCountM = males?.Length ?? 0;
            IEnumerable<Creature> selectFemales;
            IEnumerable<Creature> selectMales = null;
            if (considerChosenCreature && (_chosenCreature.sex == Sex.Female || _currentSpecies.NoGender))
            {
                selectFemales = new List<Creature>(); // the specific creature is added after the filtering
            }
            else if (!cbBPMutationLimitOnlyOnePartner.Checked && considerMutationLimit)
            {
                selectFemales = FilterByTags(females.Where(c => c.Mutations <= nudBPMutationLimit.Value));
                creaturesMutationsFilteredOut = females.Any(c => c.Mutations > nudBPMutationLimit.Value);
            }
            else selectFemales = FilterByTags(females);

            if (considerChosenCreature && !_currentSpecies.NoGender && _chosenCreature.sex == Sex.Male)
            {
                selectMales = new List<Creature>(); // the specific creature is added after the filtering
            }
            else if (!cbBPMutationLimitOnlyOnePartner.Checked && considerMutationLimit)
            {
                if (males != null)
                {
                    selectMales = FilterByTags(males.Where(c => c.Mutations <= nudBPMutationLimit.Value));
                    creaturesMutationsFilteredOut = creaturesMutationsFilteredOut ||
                                                    males.Any(c => c.Mutations > nudBPMutationLimit.Value);
                }
            }
            else selectMales = FilterByTags(males);

            // filter by servers
            if (cbServerFilterLibrary.Checked && (Settings.Default.FilterHideServers?.Any() ?? false))
            {
                selectFemales = selectFemales.Where(c => !Settings.Default.FilterHideServers.Contains(c.server));
                selectMales = selectMales?.Where(c => !Settings.Default.FilterHideServers.Contains(c.server));
            }
            // filter by owner
            if (cbOwnerFilterLibrary.Checked && (Settings.Default.FilterHideOwners?.Any() ?? false))
            {
                selectFemales = selectFemales.Where(c => !Settings.Default.FilterHideOwners.Contains(c.owner));
                selectMales = selectMales?.Where(c => !Settings.Default.FilterHideOwners.Contains(c.owner));
            }
            // filter by tribe
            if (cbTribeFilterLibrary.Checked && (Settings.Default.FilterHideTribes?.Any() ?? false))
            {
                selectFemales = selectFemales.Where(c => !Settings.Default.FilterHideTribes.Contains(c.tribe));
                selectMales = selectMales?.Where(c => !Settings.Default.FilterHideTribes.Contains(c.tribe));
            }

            var selectedFemales = selectFemales.ToArray();
            var selectedMales = selectMales?.ToArray();

            // if only pairings for one specific creatures are shown, add the creature after the filtering
            if (considerChosenCreature)
            {
                if (_chosenCreature.sex == Sex.Female)
                    selectedFemales = new[] { _chosenCreature };
                if (_chosenCreature.sex == Sex.Male)
                    selectedMales = new[] { _chosenCreature };
            }

            bool creaturesTagFilteredOut = (crCountF != selectedFemales.Length)
                                              || (crCountM != (selectedMales?.Length ?? 0));

            bool displayFilterWarning = true;

            lbBreedingPlanHeader.Text = _currentSpecies.DescriptiveNameAndMod
                                        + (considerChosenCreature ? " (" + string.Format(Loc.S("onlyPairingsWith"), _chosenCreature.name) + ")" : string.Empty)
                                        + (_onlyShowingASubset ? " (only subset)" : string.Empty);
            if (considerChosenCreature && (_chosenCreature.flags.HasFlag(CreatureFlags.Neutered) || _chosenCreature.Status != CreatureStatus.Available))
                lbBreedingPlanHeader.Text += $"{Loc.S("BreedingNotPossible")} ! ({(_chosenCreature.flags.HasFlag(CreatureFlags.Neutered) ? Loc.S("Neutered") : Loc.S("notAvailable"))})";

            var combinedCreatures = new List<Creature>(selectedFemales);
            if (selectedMales != null)
                combinedCreatures.AddRange(selectedMales);

            if (Settings.Default.IgnoreSexInBreedingPlan || _currentSpecies.NoGender)
            {
                selectedFemales = combinedCreatures.ToArray();
                selectedMales = combinedCreatures.ToArray();
            }

            if (creaturesTagFilteredOut)
            {
                // if creatures are filtered out, set the best possible creature according to the filtering
                SetBestLevels(_bestLevelsFiltered, _bestLevelsMutatedFiltered, combinedCreatures, false);
                pedigreeCreatureBestPossibleInSpeciesFiltered.Visible = true;
            }
            else
            {
                pedigreeCreatureBestPossibleInSpeciesFiltered.Visible = false;
            }

            if (!selectedFemales.Any() || !selectedMales.Any())
            {
                NoPossiblePairingsFound(creaturesMutationsFilteredOut, noCreaturesWithTopStatsInBothSexes);
            }
            else
            {
                pedigreeCreature1.Show();
                pedigreeCreature2.Show();
                lbBPBreedingScore.Show();

                short[] bestPossLevels = new short[Stats.StatsCount]; // best possible levels

                var levelLimitWithOutDomLevels = (CreatureCollection.CurrentCreatureCollection?.maxServerLevel ?? 0) - (CreatureCollection.CurrentCreatureCollection?.maxDomLevel ?? 0);
                if (levelLimitWithOutDomLevels < 0) levelLimitWithOutDomLevels = 0;

                _breedingPairs = BreedingScore.CalculateBreedingScores(selectedFemales, selectedMales, _currentSpecies,
                    bestPossLevels, _statWeights, _bestLevelsWild, _breedingMode,
                    considerChosenCreature, considerMutationLimit, (int)nudBPMutationLimit.Value,
                    ref creaturesMutationsFilteredOut, levelLimitWithOutDomLevels, CbDontSuggestOverLimitOffspring.Checked,
                    cbBPOnlyOneSuggestionForFemales.Checked, _statOddEvens, !cbBPIncludeCooldowneds.Checked && _currentSpecies.NoGender, CbConsiderMutationLevels.Checked);

                DisplayBreedingCombinations();

                if (_breedingPairs.Any())
                {
                    DisplayInfoForSetPairing(0);

                    // if breeding mode is conservative and a creature with top-stats already exists, the scoring might seem off
                    if (_breedingMode == BreedingScore.BreedingMode.TopStatsConservative)
                    {
                        bool bestCreatureAlreadyAvailable = true;
                        Creature bestCreature = null;
                        var chosenFemalesAndMales = selectedFemales.Concat(selectedMales);
                        var usedBestStats = creaturesTagFilteredOut ? _bestLevelsFiltered : _bestLevelsWild;
                        foreach (Creature cr in chosenFemalesAndMales)
                        {
                            bestCreatureAlreadyAvailable = true;
                            for (int s = 0; s < Stats.StatsCount; s++)
                            {
                                // if the stat is not a top stat and the stat is leveled in wild creatures
                                if (cr.Species.UsesStat(s) && cr.levelsWild[s] != usedBestStats[s])
                                {
                                    bestCreatureAlreadyAvailable = false;
                                    break;
                                }
                            }

                            if (bestCreatureAlreadyAvailable)
                            {
                                bestCreature = cr;
                                break;
                            }
                        }

                        if (bestCreatureAlreadyAvailable)
                        {
                            displayFilterWarning = false;
                            SetMessageLabelText(
                                string.Format(Loc.S("AlreadyCreatureWithTopStats"), bestCreature.name,
                                    Utils.SexSymbol(bestCreature.sex)), MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                    DisplayInfoForSetPairing(-1);
            }

            if (_speciesInfoNeedsUpdate)
                SetBreedingData(_currentSpecies);

            if (displayFilterWarning)
            {
                // display warning if breeding pairs are filtered out
                string warningText = null;
                if (creaturesTagFilteredOut) warningText = Loc.S("BPsomeCreaturesAreFilteredOutTags") + ".\r\n" + Loc.S("BPTopStatsShownMightNotTotalTopStats");
                if (creaturesMutationsFilteredOut) warningText = (!string.IsNullOrEmpty(warningText) ? warningText + "\r\n" : string.Empty) + Loc.S("BPsomePairingsAreFilteredOutMutations");
                if (!string.IsNullOrEmpty(warningText)) SetMessageLabelText(warningText, MessageBoxIcon.Warning);
            }

            if (considerChosenCreature) btShowAllCreatures.Text = string.Format(Loc.S("BPCancelRestrictionOn"), _chosenCreature.name);
            if (_onlyShowingASubset) btShowAllCreatures.Text = string.Format(Loc.S("BPCancelRestrictionOn"), "subset");
            btShowAllCreatures.Visible = considerChosenCreature || _onlyShowingASubset;

            SetMinTotalLevelWithTopStats();
            BreedingPlanNeedsUpdate = false;
            BtRecalculatePlan.Visible = false;
            this.ResumeDrawingAndLayout();
        }

        private void DisplayBreedingCombinations()
        {
            var minScore = _breedingPairs.LastOrDefault()?.BreedingScore.OneNumber ?? 0;
            var displayScoreOffset = (minScore < 0 ? -minScore : 0) + .5; // don't display negative scores, could be confusing

            _breedingPairs = _breedingPairs.Take(CreatureCollection.maxBreedingSuggestions).ToList();

            var displaySpeciesOnCreatureControls = _currentSpecies.matesWith?.Any() == true && !Properties.Settings.Default.BreedingPlanOnlySameSpecies;

            var deltaLightnessOutline = UiColors.IsDark ? -0.4 : -0.2;
            var deltaLightnessFill = UiColors.IsDark ? -0.7 : 0.5;

            // draw best parents
            var sb = new StringBuilder();
            using (var brush = new SolidBrush(SystemColors.ControlText))
            {
                for (int i = 0; i < _breedingPairs.Count; i++)
                {
                    PedigreeCreature pc;
                    if (2 * i < _pcs.Count)
                    {
                        _pcs[2 * i].DisplaySpecies = displaySpeciesOnCreatureControls;
                        _pcs[2 * i].Creature = _breedingPairs[i].Mother;
                        _pcs[2 * i].enabledColorRegions = _enabledColorRegions;
                        _pcs[2 * i].comboId = i;
                        _pcs[2 * i].Show();
                    }
                    else
                    {
                        pc = new PedigreeCreature(_breedingPairs[i].Mother, _enabledColorRegions, i, true, displaySpeciesOnCreatureControls);
                        pc.CreatureClicked += SetBreedingPair;
                        pc.CreatureEdit += CreatureEdit;
                        pc.RecalculateBreedingPlan += RecalculateBreedingPlan;
                        pc.BestBreedingPartners += BestBreedingPartners;
                        pc.DisplayInPedigree += DisplayInPedigree;
                        flowLayoutPanelPairs.Controls.Add(pc);
                        _pcs.Add(pc);
                    }

                    // draw score
                    PictureBox pb;
                    if (i < _pbs.Count)
                    {
                        pb = _pbs[i];
                        _pbs[i].Show();
                    }
                    else
                    {
                        pb = new PictureBox { Size = new Size(87, PedigreeCreation.PedigreeElementHeight), SizeMode = PictureBoxSizeMode.CenterImage };
                        _pbs.Add(pb);
                        flowLayoutPanelPairs.Controls.Add(pb);
                    }

                    if (2 * i + 1 < _pcs.Count)
                    {
                        _pcs[2 * i + 1].DisplaySpecies = displaySpeciesOnCreatureControls;
                        _pcs[2 * i + 1].Creature = _breedingPairs[i].Father;
                        _pcs[2 * i + 1].enabledColorRegions = _enabledColorRegions;
                        _pcs[2 * i + 1].comboId = i;
                        _pcs[2 * i + 1].Show();
                    }
                    else
                    {
                        pc = new PedigreeCreature(_breedingPairs[i].Father, _enabledColorRegions, i, true, displaySpeciesOnCreatureControls);
                        pc.CreatureClicked += SetBreedingPair;
                        pc.CreatureEdit += CreatureEdit;
                        pc.RecalculateBreedingPlan += RecalculateBreedingPlan;
                        pc.BestBreedingPartners += BestBreedingPartners;
                        pc.DisplayInPedigree += DisplayInPedigree;
                        flowLayoutPanelPairs.Controls.Add(pc);
                        flowLayoutPanelPairs.SetFlowBreak(pc, true);
                        _pcs.Add(pc);
                    }

                    sb.Clear();

                    Bitmap bm = new Bitmap(pb.Width, 29);
                    using (Graphics g = Graphics.FromImage(bm))
                    {
                        g.TextRenderingHint = TextRenderingHint.AntiAlias;
                        brush.Color = UiColors.Current.Mutation;
                        if (_breedingPairs[i].Mother.Mutations < Ark.MutationPossibleWithLessThan)
                        {
                            g.FillRectangle(brush, 0, 5, 10, 10);
                            sb.AppendLine(_breedingPairs[i].Mother + " can produce a mutation.");
                        }
                        if (_breedingPairs[i].Father.Mutations < Ark.MutationPossibleWithLessThan)
                        {
                            g.FillRectangle(brush, 77, 5, 10, 10);
                            sb.AppendLine(_breedingPairs[i].Father + " can produce a mutation.");
                        }

                        var colorPercent = (int)((_breedingPairs[i].BreedingScore.OneNumber + displayScoreOffset) * 12.5);
                        // outline
                        brush.Color = Utils.GetColorFromPercent(colorPercent, deltaLightnessOutline);
                        g.FillRectangle(brush, 0, 15, 87, 5);
                        g.FillRectangle(brush, 20, 10, 47, 15);
                        // fill
                        var colorBackground = Utils.GetColorFromPercent(colorPercent, deltaLightnessFill);
                        brush.Color = colorBackground;
                        g.FillRectangle(brush, 1, 16, 85, 3);
                        g.FillRectangle(brush, 21, 11, 45, 13);
                        if (_breedingPairs[i].HighestOffspringOverLevelLimit)
                        {
                            brush.Color = UiColors.Current.OverLevelWarning;
                            g.FillRectangle(brush, 15, 26, 55, 3);
                            sb.AppendLine("The highest possible and fully leveled offspring is over the level limit!");
                        }
                        // breeding score text
                        brush.Color = Utils.ForeColor(colorBackground);
                        g.DrawString((_breedingPairs[i].BreedingScore.Primary + displayScoreOffset).ToString("N4"),
                            new Font(Properties.Settings.Default.DefaultFontName, 9f), brush, 24, 9);
                        pb.SetImageAndDisposeOld(bm);
                    }

                    _tt.SetToolTip(pb, sb.Length > 0 ? sb.ToString() : null);
                }
            }

            // hide unused controls
            for (int i = CreatureCollection.maxBreedingSuggestions; 2 * i + 1 < _pcs.Count && i < _pbs.Count; i++)
            {
                _pcs[2 * i].Hide();
                _pcs[2 * i + 1].Hide();
                _pbs[i].Hide();
            }
        }

        /// <summary>
        /// Hide unused controls and display info.
        /// </summary>
        private void NoPossiblePairingsFound(bool creaturesMutationsFilteredOut, bool noCreaturesWithTopStatsInBothSexes)
        {
            // hide unused controls
            pedigreeCreature1.Hide();
            pedigreeCreature2.Hide();
            lbBPBreedingScore.Hide();
            for (int i = 0; i < CreatureCollection.maxBreedingSuggestions && 2 * i + 1 < _pcs.Count && i < _pbs.Count; i++)
            {
                _pcs[2 * i].Hide();
                _pcs[2 * i + 1].Hide();
                _pbs[i].Hide();
            }

            if (noCreaturesWithTopStatsInBothSexes)
            {
                lbBreedingPlanInfo.Text = $"The breeding mode is set to {Loc.S("rbBPTopStatsCn")}, but currently there is no pair where top stats can be combined."
                                          + Environment.NewLine + $"You can change the breeding mode to {Loc.S("rbBPHighStats")} to get the best recommendations in this situation."
                                          + Environment.NewLine + Environment.NewLine
                                          + string.Format(Loc.S("NoPossiblePairingForSpeciesFound"), _currentSpecies);
            }
            else
            {
                lbBreedingPlanInfo.Text = string.Format(Loc.S("NoPossiblePairingForSpeciesFound"), _currentSpecies);
            }
            lbBreedingPlanInfo.Visible = true;
            if (!cbBPIncludeCryoCreatures.Checked
                && CreatureCollection.creatures.Any(c
                    => c.Species == _currentSpecies
                       && !c.flags.HasFlag(CreatureFlags.Neutered)
                       && !c.flags.HasFlag(CreatureFlags.Placeholder)
                       && c.Status == CreatureStatus.Cryopod
                       )
                )
                cbBPIncludeCryoCreatures.SetBackColorAndAccordingForeColor(UiColors.Current.Warning);
            if (creaturesMutationsFilteredOut)
                nudBPMutationLimit.SetBackColorAndAccordingForeColor(UiColors.Current.Warning);
        }

        /// <summary>
        /// Recreates the breeding plan after the same library is loaded.
        /// </summary>
        /// <param name="isActiveControl">if true, the data is updated immediately.</param>
        public void RecreateAfterLoading(bool isActiveControl = false)
        {
            if (_chosenCreature != null)
                _chosenCreature = CreatureCollection.creatures.FirstOrDefault(c => c.guid == _chosenCreature.guid);

            if (_currentSpecies != null)
            {
                _currentSpecies = Values.V.SpeciesByBlueprint(_currentSpecies.blueprintPath);
                if (isActiveControl)
                    DetermineBestBreeding(_chosenCreature, true);
                else
                    BreedingPlanNeedsUpdate = true;
            }
        }

        private void RecalculateBreedingPlan()
        {
            DetermineBestBreeding(_chosenCreature, true);
        }

        internal void UpdateIfNeeded(Asb.TriggerSource triggerSource = Asb.TriggerSource.User)
        {
            if (!BreedingPlanNeedsUpdate) return;
            if (triggerSource == Asb.TriggerSource.FileWatcher)
                BtRecalculatePlan.Visible = true;
            else
                DetermineBestBreeding(_chosenCreature);
        }

        private void ClearControls()
        {
            var maxBreedingSuggestions = CreatureCollection?.maxBreedingSuggestions ?? 10;
            // hide unused controls
            for (int i = 0; i < maxBreedingSuggestions && 2 * i + 1 < _pcs.Count && i < _pbs.Count; i++)
            {
                _pcs[2 * i].Hide();
                _pcs[2 * i + 1].Hide();
                _pbs[i].Hide();
            }

            // remove controls larger than the limit
            if (_pbs.Count > maxBreedingSuggestions)
            {
                for (int i = _pbs.Count - 1; i > maxBreedingSuggestions && i >= 0; i--)
                {
                    _pcs[2 * i + 1].Dispose();
                    _pcs.RemoveAt(2 * i + 1);
                    _pcs[2 * i].Dispose();
                    _pcs.RemoveAt(2 * i);
                    _pbs[i].Dispose();
                    _pbs.RemoveAt(i);
                }
            }

            pedigreeCreatureBest.Clear();
            pedigreeCreatureWorst.Clear();
            lbBreedingPlanInfo.Visible = false;
            lbBPProbabilityBest.Text = string.Empty;
            lbMutationProbability.Text = string.Empty;
            offspringPossibilities1.Clear();
            SetMessageLabelText?.Invoke();
            cbBPIncludeCryoCreatures.SetBackColorAndAccordingForeColor(Color.Transparent);
            nudBPMutationLimit.SetBackColorAndAccordingForeColor(SystemColors.Window);
        }

        public void Clear()
        {
            ClearControls();
            SetBreedingData();
            listViewRaisingTimes.Items.Clear();
            _currentSpecies = null;
            _males = null;
            _females = null;
            lbBreedingPlanHeader.Text = Loc.S("SelectSpeciesBreedingPlanner");
            BtRecalculatePlan.Visible = false;
        }

        private void SetBreedingData(Species species = null)
        {
            listViewRaisingTimes.Items.Clear();
            if (species?.breeding == null)
            {
                listViewRaisingTimes.Items.Add(Loc.S("naYet"));
                labelBreedingInfos.Text = string.Empty;
            }
            else
            {
                pedigreeCreature1.SetCustomStatNames(species.statNames);
                pedigreeCreature2.SetCustomStatNames(species.statNames);
                if (Raising.GetRaisingTimes(species, out TimeSpan matingTime, out string incubationMode, out _incubationTime, out TimeSpan babyTime, out TimeSpan maturationTime, out TimeSpan nextMatingMin, out TimeSpan nextMatingMax))
                {
                    if (matingTime != TimeSpan.Zero)
                        listViewRaisingTimes.Items.Add(new ListViewItem(new[] { Loc.S("matingTime"), matingTime.ToString("d':'hh':'mm':'ss") }));

                    TimeSpan totalTime = _incubationTime;
                    DateTime until = DateTime.Now.Add(totalTime);
                    string[] times = { incubationMode, _incubationTime.ToString("d':'hh':'mm':'ss"), totalTime.ToString("d':'hh':'mm':'ss"), Utils.ShortTimeDate(until) };
                    listViewRaisingTimes.Items.Add(new ListViewItem(times));

                    totalTime += babyTime;
                    until = DateTime.Now.Add(totalTime);
                    times = new[] { Loc.S("Baby"), babyTime.ToString("d':'hh':'mm':'ss"), totalTime.ToString("d':'hh':'mm':'ss"), Utils.ShortTimeDate(until) };
                    listViewRaisingTimes.Items.Add(new ListViewItem(times));

                    totalTime = _incubationTime + maturationTime;
                    until = DateTime.Now.Add(totalTime);
                    times = new[] { Loc.S("Maturation"), maturationTime.ToString("d':'hh':'mm':'ss"), totalTime.ToString("d':'hh':'mm':'ss"), Utils.ShortTimeDate(until) };
                    listViewRaisingTimes.Items.Add(new ListViewItem(times));

                    string eggInfo = Raising.EggTemperature(species);

                    labelBreedingInfos.Text = (nextMatingMin != TimeSpan.Zero ? $"{Loc.S("TimeBetweenMating")}: {nextMatingMin:d':'hh':'mm':'ss} to {nextMatingMax:d':'hh':'mm':'ss}" : string.Empty)
                        + ((!string.IsNullOrEmpty(eggInfo) ? "\n" + eggInfo : string.Empty));
                }
            }

            _speciesInfoNeedsUpdate = false;
        }

        public void CreateTagList()
        {
            tagSelectorList1.tags = CreatureCollection.tags;
            foreach (string t in CreatureCollection.tagsInclude)
                tagSelectorList1.setTagStatus(t, TagSelector.tagStatus.include);
            foreach (string t in CreatureCollection.tagsExclude)
                tagSelectorList1.setTagStatus(t, TagSelector.tagStatus.exclude);
        }

        private List<Creature> Creatures
        {
            set
            {
                if (value == null) return;

                if (_currentSpecies.NoGender)
                {
                    _females = value.ToArray();
                    _males = null;
                }
                else
                {
                    _females = value.Where(c => c.sex == Sex.Female).ToArray();
                    _males = value.Where(c => c.sex == Sex.Male).ToArray();
                }

                DetermineBestLevels(value);
            }
        }

        private void DetermineBestLevels(List<Creature> creatures = null)
        {
            pedigreeCreatureBestPossibleInSpecies.Clear();
            if (creatures == null)
            {
                if (_females == null) return;
                creatures = _females.ToList();
                if (_males != null)
                    creatures.AddRange(_males);
            }

            SetBestLevels(_bestLevelsWild, _bestLevelsMutated, creatures, true);
        }

        /// <summary>
        /// Sets the best levels in the passed array according to the stat weights and the passed creature list.
        /// </summary>
        /// <param name="bestLevelsWild"></param>
        /// <param name="creatures"></param>
        /// <param name="bestInSpecies">If true, the display of the best species library will be updated, if false the best filtered species will be updated.</param>
        private void SetBestLevels(int[] bestLevelsWild, int[] bestLevelsMutated, IEnumerable<Creature> creatures, bool bestInSpecies)
        {
            BreedingScore.SetBestLevels(creatures, bestLevelsWild, bestLevelsMutated, _statWeights, _statOddEvens);

            // display top levels in species
            int? levelStep = CreatureCollection.getWildLevelStep();

            var bestLevelsOfWhat = _onlyShowingASubset ? "Best of manual selection"
                : string.Format(Loc.S(bestInSpecies ? "BestPossibleSpeciesLibrary" : "BestPossibleSpeciesLibraryFiltered"), _currentSpecies.name);

            Creature crB = new Creature(_currentSpecies, bestLevelsOfWhat,
                null, null, 0, new int[Stats.StatsCount], null, new int[Stats.StatsCount], 1, true, levelStep: levelStep);
            bool totalLevelUnknown = false;
            for (int s = 0; s < Stats.StatsCount; s++)
            {
                if (s == Stats.Torpidity) continue;
                crB.levelsWild[s] = bestLevelsWild[s];
                if (crB.levelsWild[s] == -1)
                    totalLevelUnknown = true;
                crB.SetTopStat(s, crB.levelsWild[s] > 0 && crB.levelsWild[s] == _bestLevelsWild[s]);
                crB.levelsMutated[s] = bestLevelsMutated[s];
                crB.SetTopMutationStat(s, crB.levelsMutated[s] > 0 && crB.levelsMutated[s] == _bestLevelsMutated[s]);
            }
            crB.levelsWild[Stats.Torpidity] = crB.levelsWild.Sum() + crB.levelsMutated.Sum();
            crB.RecalculateCreatureValues(levelStep);
            var pc = bestInSpecies
                ? pedigreeCreatureBestPossibleInSpecies
                : pedigreeCreatureBestPossibleInSpeciesFiltered;
            pc.TotalLevelUnknown = totalLevelUnknown;
            pc.Creature = crB;
        }

        private void SetBreedingPair(Creature c, int comboIndex, MouseEventArgs e)
        {
            if (comboIndex >= 0)
                DisplayInfoForSetPairing(comboIndex);
        }

        private void CreatureEdit(Creature c, bool isVirtual)
        {
            EditCreature?.Invoke(c, isVirtual);
        }

        /// <summary>
        /// Updates info for possible results of selected pairing.
        /// </summary>
        private void DisplayInfoForSetPairing(int comboIndex)
        {
            if (comboIndex < 0 || comboIndex >= _breedingPairs.Count)
            {
                pedigreeCreatureBest.Clear();
                pedigreeCreatureWorst.Clear();
                lbBreedingPlanInfo.Visible = false;
                lbBPProbabilityBest.Text = string.Empty;
                lbMutationProbability.Text = string.Empty;
                return;
            }

            int? levelStep = CreatureCollection.getWildLevelStep();
            Creature crB = new Creature(_currentSpecies, string.Empty, levelsWild: new int[Stats.StatsCount], levelsMutated: new int[Stats.StatsCount], isBred: true, levelStep: levelStep);
            Creature crW = new Creature(_currentSpecies, string.Empty, levelsWild: new int[Stats.StatsCount], levelsMutated: new int[Stats.StatsCount], isBred: true, levelStep: levelStep);
            Creature mother = _breedingPairs[comboIndex].Mother;
            Creature father = _breedingPairs[comboIndex].Father;
            crB.Mother = mother;
            crB.Father = father;
            crW.Mother = mother;
            crW.Father = father;
            double probabilityBest = 1;
            bool totalLevelUnknown = false; // if stats are unknown, total level is as well (==> oxygen, speed)
            bool topStatBreedingMode = _breedingMode == BreedingScore.BreedingMode.TopStatsConservative || _breedingMode == BreedingScore.BreedingMode.TopStatsLucky;
            for (int s = 0; s < Stats.StatsCount; s++)
            {
                if (s == Stats.Torpidity || !mother.Species.UsesStat(s)) continue;
                var higherLevelPreferred = _statWeights[s] >= 0;
                crB.levelsWild[s] = higherLevelPreferred ? BreedingScore.GetHigherBestLevel(mother.levelsWild[s], father.levelsWild[s], _statOddEvens[s]) : Math.Min(mother.levelsWild[s], father.levelsWild[s]);
                crB.levelsMutated[s] = higherLevelPreferred ? Math.Max(mother.levelsMutated?[s] ?? 0, father.levelsMutated?[s] ?? 0) : Math.Min(mother.levelsMutated?[s] ?? 0, father.levelsMutated?[s] ?? 0);
                crB.valuesBreeding[s] = StatValueCalculation.CalculateValue(_currentSpecies, s, crB.levelsWild[s], crB.levelsMutated[s], 0, true, 1, 0);
                crB.SetTopStat(s, _currentSpecies.stats[s].IncPerTamedLevel != 0 && crB.levelsWild[s] == _bestLevelsWild[s]);
                crB.SetTopMutationStat(s, crB.levelsMutated[s] == _bestLevelsMutated[s]);
                crW.levelsWild[s] = higherLevelPreferred ? Math.Min(mother.levelsWild[s], father.levelsWild[s]) : Math.Max(mother.levelsWild[s], father.levelsWild[s]);
                crW.levelsMutated[s] = higherLevelPreferred ? Math.Min(mother.levelsMutated?[s] ?? 0, father.levelsMutated?[s] ?? 0) : Math.Max(mother.levelsMutated?[s] ?? 0, father.levelsMutated?[s] ?? 0);
                crW.valuesBreeding[s] = StatValueCalculation.CalculateValue(_currentSpecies, s, crW.levelsWild[s], crW.levelsMutated[s], 0, true, 1, 0);
                crW.SetTopStat(s, _currentSpecies.stats[s].IncPerTamedLevel != 0 && crW.levelsWild[s] == _bestLevelsWild[s]);
                crB.SetTopMutationStat(s, crW.levelsMutated[s] == _bestLevelsMutated[s]);
                if (crB.levelsWild[s] == -1 || crW.levelsWild[s] == -1)
                    totalLevelUnknown = true;

                var probabilityInheritingHigherLevel = Ark.ProbabilityInheritHigherLevel + mother.ProbabilityOffsetInheritingHigherLevel(s) + father.ProbabilityOffsetInheritingHigherLevel(s);

                // in top stats breeding mode consider only probability of top stats
                if (crB.levelsWild[s] > crW.levelsWild[s]
                    && (!topStatBreedingMode || crB.IsTopStat(s) || crB.IsTopMutationStat(s)))
                    probabilityBest *= probabilityInheritingHigherLevel;
                else if (crB.levelsWild[s] < crW.levelsWild[s]
                         && (!topStatBreedingMode || crB.IsTopStat(s) || crB.IsTopMutationStat(s)))
                    probabilityBest *= 1 - probabilityInheritingHigherLevel;
            }
            crB.levelsWild[Stats.Torpidity] = crB.levelsWild.Sum() + crB.levelsMutated.Sum();
            crW.levelsWild[Stats.Torpidity] = crW.levelsWild.Sum() + crW.levelsMutated.Sum();
            crB.name = Loc.S("BestPossible");
            crW.name = Loc.S("WorstPossible");
            crB.RecalculateCreatureValues(levelStep);
            crW.RecalculateCreatureValues(levelStep);
            pedigreeCreatureBest.TotalLevelUnknown = totalLevelUnknown;
            pedigreeCreatureWorst.TotalLevelUnknown = totalLevelUnknown;
            int mutationCounterMaternal = mother.Mutations;
            int mutationCounterPaternal = father.Mutations;
            crB.mutationsMaternal = mutationCounterMaternal;
            crB.mutationsPaternal = mutationCounterPaternal;
            crW.mutationsMaternal = mutationCounterMaternal;
            crW.mutationsPaternal = mutationCounterPaternal;
            pedigreeCreatureBest.Creature = crB;
            pedigreeCreatureWorst.Creature = crW;
            lbBPProbabilityBest.Text = $"{Loc.S("ProbabilityForBest")}: {probabilityBest:P}";
            lbMutationProbability.Text = $"{Loc.S("ProbabilityForOneMutation")}: {_breedingPairs[comboIndex].MutationProbability:P}";

            // set probability barChart
            offspringPossibilities1.Calculate(_currentSpecies, mother, father);

            // highlight parents
            int hiliId = comboIndex * 2;
            for (int i = 0; i < _pcs.Count; i++)
                _pcs[i].Highlight = (i == hiliId || i == hiliId + 1);
        }

        private bool[] EnabledColorRegions
        {
            set
            {
                if (value != null && value.Length == 6)
                {
                    _enabledColorRegions = value;
                }
                else
                {
                    _enabledColorRegions = new[] { true, true, true, true, true, true };
                }
            }
        }

        private void buttonJustMated_Click(object sender, EventArgs e)
        {
            CreateIncubationEntry();
            PairMated?.Invoke(pedigreeCreatureBest.Creature?.Mother, pedigreeCreatureBest.Creature?.Father);
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Species CurrentSpecies
        {
            get => _currentSpecies;
            set
            {
                _currentSpecies = value;
                StatWeighting.SetSpecies(value);
            }
        }

        private void SetMinTotalLevelWithTopStats()
        {
            if (_currentSpecies == null || CreatureCollection == null) return;

            if (CreatureCollection.TopLevels.TryGetValue(_currentSpecies, out var topLevels)
                && topLevels.MinLevelForTopCreature >= 0)
            {
                LbMinTotalLevelTopStats.Text = $"Min level for creatures with all desired high top stats: {topLevels.MinLevelForTopCreature}";
            }
            else
                LbMinTotalLevelTopStats.Text = "Min level for creatures with all desired high top stats: unknown";
        }

        private void listViewSpeciesBP_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewSpeciesBP.SelectedIndices.Count > 0
                && !string.IsNullOrEmpty(listViewSpeciesBP.SelectedItems[0].Text)
                && (_currentSpecies == null
                    || listViewSpeciesBP.SelectedItems[0].Text != _currentSpecies.DescriptiveNameAndMod)
                )
            {
                SetGlobalSpecies?.Invoke((Species)listViewSpeciesBP.SelectedItems[0].Tag);
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int MaxWildLevels
        {
            set => offspringPossibilities1.maxWildLevel = value <= 0 ? Ark.MaxWildLevelDefault : value;
        }

        public void SetSpecies(Species species, Asb.TriggerSource triggerSource = Asb.TriggerSource.User)
        {
            if (_currentSpecies == species
                || triggerSource != Asb.TriggerSource.User
                )
                return;

            // automatically set preset if preset with the species name exists
            _updateBreedingPlanAllowed = false;
            StatWeighting.TrySetPresetBySpecies(species);
            _updateBreedingPlanAllowed = true;

            DetermineBestBreeding(setSpecies: species);

            // update listViewSpeciesBP
            // deselect currently selected species
            if (listViewSpeciesBP.SelectedItems.Count > 0)
                listViewSpeciesBP.SelectedItems[0].Selected = false;
            for (int i = 0; i < listViewSpeciesBP.Items.Count; i++)
            {
                if (listViewSpeciesBP.Items[i].Text == _currentSpecies.DescriptiveNameAndMod)
                {
                    listViewSpeciesBP.Items[i].Focused = true;
                    listViewSpeciesBP.Items[i].Selected = true;
                    break;
                }
            }
        }

        private void checkBoxIncludeCooldowneds_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.IncludeCooldownsInBreedingPlan = cbBPIncludeCooldowneds.Checked;
            DetermineBestBreeding(_chosenCreature, true);
        }

        private void cbBPIncludeCryoCreatures_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.IncludeCryoedInBreedingPlan = cbBPIncludeCryoCreatures.Checked;
            DetermineBestBreeding(_chosenCreature, true);
        }

        private void nudMutationLimit_ValueChanged(object sender, EventArgs e)
        {
            DetermineBestBreeding(_chosenCreature, true);
        }

        private void radioButtonBPTopStatsCn_CheckedChanged(object sender, EventArgs e)
        {
            if (rbBPTopStatsCn.Checked)
            {
                _breedingMode = BreedingScore.BreedingMode.TopStatsConservative;
                CalculateBreedingScoresAndDisplayPairs();
            }
        }

        private void radioButtonBPTopStats_CheckedChanged(object sender, EventArgs e)
        {
            if (rbBPTopStats.Checked)
            {
                _breedingMode = BreedingScore.BreedingMode.TopStatsLucky;
                CalculateBreedingScoresAndDisplayPairs();
            }
        }

        private void radioButtonBPHighStats_CheckedChanged(object sender, EventArgs e)
        {
            if (rbBPHighStats.Checked)
            {
                _breedingMode = BreedingScore.BreedingMode.BestNextGen;
                CalculateBreedingScoresAndDisplayPairs();
            }
        }

        public void SetSpeciesList(IList<Species> species, List<Creature> creatures)
        {
            Species previouslySelectedSpecies = listViewSpeciesBP.SelectedItems.Count > 0 ? listViewSpeciesBP.SelectedItems[0].Tag as Species : null;

            listViewSpeciesBP.BeginUpdate();
            listViewSpeciesBP.Items.Clear();

            var breedableSpecies = new List<ListViewItem>();
            var unbreedableSpecies = new List<ListViewItem>();

            var availableCreaturesBySpecies = creatures
                .Where(c => c.Species != null && (c.Status == CreatureStatus.Available || c.Status == CreatureStatus.Cryopod))
                .GroupBy(c => c.Species).ToDictionary(g => g.Key, g => g.ToArray());

            var ignoreSex = Properties.Settings.Default.IgnoreSexInBreedingPlan;

            foreach (Species s in species)
            {
                ListViewItem lvi = new ListViewItem { Text = s.DescriptiveNameAndMod, Tag = s };
                var ignoreSexInSpecies = ignoreSex || s.NoGender;

                // check if species has both available males and females
                if (availableCreaturesBySpecies.TryGetValue(s, out var cs)
                    && ((ignoreSexInSpecies && cs.Length > 1)
                        || (cs.Any(c => c.sex == Sex.Female) && cs.Any(c => c.sex == Sex.Male))))
                {
                    breedableSpecies.Add(lvi);
                }
                else
                {
                    lvi.ForeColor = SystemColors.GrayText;
                    unbreedableSpecies.Add(lvi);
                }
            }
            if (breedableSpecies.Any())
                listViewSpeciesBP.Items.AddRange(breedableSpecies.ToArray());
            if (unbreedableSpecies.Any())
                listViewSpeciesBP.Items.AddRange(unbreedableSpecies.ToArray());

            // select previous selected species again
            if (previouslySelectedSpecies != null)
            {
                for (int i = 0; i < listViewSpeciesBP.Items.Count; i++)
                {
                    if (listViewSpeciesBP.Items[i].Tag is Species s
                        && s == previouslySelectedSpecies)
                    {
                        listViewSpeciesBP.Items[i].Focused = true;
                        listViewSpeciesBP.Items[i].Selected = true;
                        break;
                    }
                }
            }
            listViewSpeciesBP.EndUpdate();
        }

        private void CreateIncubationEntry(bool startNow = true)
        {
            if (pedigreeCreatureBest.Creature?.Mother != null && pedigreeCreatureBest.Creature.Father != null)
            {
                CreateIncubationTimer?.Invoke(pedigreeCreatureBest.Creature.Mother, pedigreeCreatureBest.Creature.Father, _incubationTime, startNow);

                // set cooldown for mother
                Species species = pedigreeCreatureBest.Creature.Mother.Species;
                if (species?.breeding != null)
                {
                    pedigreeCreatureBest.Creature.Mother.cooldownUntil = DateTime.Now.AddSeconds(species.breeding.matingCooldownMinAdjusted);
                    // update breeding plan
                    DetermineBestBreeding(_chosenCreature, true);
                }
            }
        }

        public void UpdateBreedingData()
        {
            SetBreedingData(_currentSpecies);
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int MutationLimit
        {
            get => (int)nudBPMutationLimit.Value;
            set => nudBPMutationLimit.Value = value;
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IgnoreSexInBreedingPlan
        {
            set => CbIgnoreSexInPlanning.Checked = value;
        }

        private void cbTagExcludeDefault_CheckedChanged(object sender, EventArgs e)
        {
            CalculateBreedingScoresAndDisplayPairs();
        }

        public void SetLocalizations()
        {
            Loc.ControlText(lbBreedingPlanHeader, "SelectSpeciesBreedingPlanner");
            Loc.ControlText(gbBPOffspring);
            Loc.ControlText(gbBPBreedingMode);
            Loc.ControlText(rbBPTopStatsCn);
            Loc.ControlText(rbBPTopStats);
            Loc.ControlText(rbBPHighStats);
            Loc.ControlText(cbBPIncludeCooldowneds);
            Loc.ControlText(gbBPBreedingMode);
            Loc.ControlText(lbBPBreedingTimes);
            Loc.ControlText(btBPJustMated);
            Loc.ControlText(cbBPOnlyOneSuggestionForFemales);
            Loc.ControlText(cbBPMutationLimitOnlyOnePartner);
            columnHeader2.Text = Loc.S("Time");
            columnHeader3.Text = Loc.S("TotalTime");
            columnHeader4.Text = Loc.S("FinishedAt");

            // tooltips
            Loc.ControlText(lbBPBreedingScore, _tt);
            Loc.ControlText(rbBPTopStatsCn, _tt);
            Loc.ControlText(rbBPTopStats, _tt);
            Loc.ControlText(rbBPHighStats, _tt);
            Loc.ControlText(btBPJustMated, _tt);
            Loc.SetToolTip(nudBPMutationLimit, _tt);
            Loc.SetToolTip(cbBPTagExcludeDefault, _tt);
        }

        private void btShowAllCreatures_Click(object sender, EventArgs e)
        {
            // remove restriction on manually selected creatures
            _chosenCreature = null;
            if (_onlyShowingASubset)
            {
                BreedingPlanNeedsUpdate = true;
                DetermineBestBreeding();
            }
            else
                CalculateBreedingScoresAndDisplayPairs();
        }

        private void cbServerFilterLibrary_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.UseServerFilterForBreedingPlan = cbServerFilterLibrary.Checked;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private void cbOwnerFilterLibrary_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.UseOwnerFilterForBreedingPlan = cbOwnerFilterLibrary.Checked;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private void cbTribeFilterLibrary_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.UseTribeFilterForBreedingPlan = cbTribeFilterLibrary.Checked;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private void cbOnlyOneSuggestionForFemales_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.BreedingPlanOnlyBestSuggestionForEachFemale = cbBPOnlyOneSuggestionForFemales.Checked;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private void cbMutationLimitOnlyOnePartner_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.BreedingPlanOnePartnerMoreMutationsThanLimit = cbBPMutationLimitOnlyOnePartner.Checked;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private void CbIgnoreSexInPlanning_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.IgnoreSexInBreedingPlan = CbIgnoreSexInPlanning.Checked;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private void CbDontSuggestOverLimitOffspring_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.BreedingPlanDontSuggestOverLimitOffspring = CbDontSuggestOverLimitOffspring.Checked;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private void CbConsiderMutationLevels_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.BreedingPlanConsiderMutatedLevels = CbConsiderMutationLevels.Checked;
            CalculateBreedingScoresAndDisplayPairs();
        }

        private void CbOnlySameSpecies_CheckedChanged(object sender, EventArgs e)
        {
            Settings.Default.BreedingPlanOnlySameSpecies = CbOnlySameSpecies.Checked;
            DetermineBestBreeding(_chosenCreature, true);
        }

        private void BtRecalculatePlan_Click(object sender, EventArgs e) => CalculateBreedingScoresAndDisplayPairs();
    }
}
