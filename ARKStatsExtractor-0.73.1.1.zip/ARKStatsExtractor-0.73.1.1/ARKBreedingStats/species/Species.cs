﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using ARKBreedingStats.Library;
using ARKBreedingStats.mods;
using System.IO;
using System.Windows.Documents;

namespace ARKBreedingStats.species
{
    [JsonObject]
    public class Species
    {
        /// <summary>
        /// The name as it is displayed for the user in most controls.
        /// </summary>
        [JsonProperty]
        public string name;
        /// <summary>
        /// Optional name for females if different from name.
        /// </summary>
        [JsonProperty]
        public string nameFemale;
        /// <summary>
        /// Optional name for males if different from name.
        /// </summary>
        [JsonProperty]
        public string nameMale;
        /// <summary>
        /// The name used for sorting in lists.
        /// </summary>
        public string SortName;
        /// <summary>
        /// The name suffixed by possible additional infos like cave, minion, etc.
        /// </summary>
        public string DescriptiveName { get; private set; }

        /// <summary>
        /// Info about the species variant, or null.
        /// </summary>
        public string VariantSuffix { get; private set; }

        /// <summary>
        /// Info about the species mod, or null.
        /// </summary>
        public string ModSuffix { get; private set; }

        /// <summary>
        /// List of variant infos about that species.
        /// </summary>
        [JsonProperty]
        public string[] variants;
        /// <summary>
        /// The name of the species suffixed by additional variant infos and the mod it comes from.
        /// </summary>
        public string VariantInfo;
        public string DescriptiveNameAndMod { get; private set; }
        [JsonProperty]
        public string blueprintPath;
        /// <summary>
        /// The raw stat values without multipliers.
        /// For each stat there is 0: baseValue, 1: incPerWildLevel, 2: incPerDomLevel, 3: addBonus, 4: multBonus.
        /// </summary>
        [JsonProperty]
        public double[][] fullStatsRaw;
        /// <summary>
        /// The  alternative / Troodonism / bugged raw stat values without multipliers.
        /// The key is the stat index, the value is the base value (the only one that can have alternate values).
        /// Values depending on the base value, e.g. incPerWild or incPerDom etc. can use either the correct or alternative base value.
        /// </summary>
        [JsonProperty("altBaseStats")]
        public Dictionary<int, double> altBaseStatsRaw;
        /// <summary>
        /// The stat values with all multipliers applied and ready to use.
        /// </summary>
        public SpeciesStat[] stats;
        /// <summary>
        /// The alternative / Troodonism base stat values with all multipliers applied and ready to use.
        /// Values depending on the base value, e.g. incPerWild or incPerDom etc. can use either the correct or alternative base value.
        /// </summary>
        public SpeciesStat[] altStats;

        /// <summary>
        /// Multipliers for each stat for the mutated levels. Introduced in ASA.
        /// </summary>
        [JsonProperty]
        public float[] mutationMult;

        /// <summary>
        /// Indicates if a stat is shown in game represented by bit-flags
        /// </summary>
        [JsonProperty("displayedStats")]
        public int DisplayedStats { private set; get; } = -1;
        public const int displayedStatsDefault = 927;
        /// <summary>
        /// Indicates if a species uses a stat represented by bit-flags
        /// </summary>
        private int usedStats;

        /// <summary>
        /// Indicates if a creature stat won't get wild levels or mutations represented by bit-flags.
        /// </summary>
        [JsonProperty]
        private int skipWildLevelStats;

        /// <summary>
        /// Indicates if a creature stat won't get wild levels or mutations represented by bit-flags, also considering server settings.
        /// </summary>
        private int _skipWildLevelStatsWithServerSettings;

        /// <summary>
        /// Info about multiple color region patterns.
        /// </summary>
        public ColorPattern patterns;

        [JsonProperty] private bool? isFlyer;
        /// <summary>
        /// Indicates if the species is affected by the setting AllowFlyerSpeedLeveling
        /// </summary>
        public bool IsFlyer => isFlyer == true;

        /// <summary>
        /// Blueprintpaths of species this species can mate with.
        /// </summary>
        [JsonProperty]
        public string[] matesWith;

        [JsonProperty]
        public float? TamedBaseHealthMultiplier;

        /// <summary>
        /// Indicates the default multipliers for this species for each stat applied to the imprinting-bonus
        /// </summary>
        [JsonProperty]
        private double[] statImprintMult;

        /// <summary>
        /// Custom override for stat imprinting multipliers.
        /// </summary>
        private double[] statImprintMultOverride;

        /// <summary>
        /// The used multipliers for each stat applied to the imprinting-bonus, affected by custom overrides and global leveling settings.
        /// </summary>
        public double[] StatImprintMultipliers;

        /// <summary>
        /// The raw species imprinting stat multipliers. This property should only be used for custom species.
        /// </summary>
        public double[] StatImprintMultipliersRaw;

        [JsonProperty]
        public ColorRegion[] colors;
        [JsonProperty]
        public double[] regionIntensities;
        [JsonProperty]
        public TamingData taming;
        [JsonProperty]
        public BreedingData breeding;

        /// <summary>
        /// If the species uses no gender, ignore the sex in the breeding planner.
        /// </summary>
        [JsonProperty]
        private bool? noGender;
        /// <summary>
        /// If the species uses no gender, ignore the sex in the breeding planner.
        /// </summary>
        public bool NoGender => noGender == true;

        [JsonProperty]
        public Dictionary<string, double> boneDamageAdjusters;
        [JsonProperty]
        public List<string> immobilizedBy;
        /// <summary>
        /// Information about the mod. If this value equals null, the species is probably from the base-game.
        /// </summary>
        private Mod _mod;

        /// <summary>
        /// Custom stat names of the species, e.g. glowSpecies use this.
        /// The key is the stat index as string, the value the statName.
        /// If this property is null, the default names are used.
        /// </summary>
        [JsonProperty]
        public Dictionary<string, string> statNames;

        /// <summary>
        /// True if the species is tameable or domesticable in other ways (e.g. raising from collected eggs).
        /// </summary>
        public bool IsDomesticable;

        /// <summary>
        /// Value caps of stats. If a stat reaches a value, it cannot be levelled anymore.
        /// </summary>
        [JsonProperty("statCaps")]
        private Dictionary<int, double> _statCaps;

        /// <summary>
        /// If a stat index is set to true here, the level ups are additive, i.e. independent on the base value for wild levels and independent on the post tame value for domestic levels.
        /// </summary>
        [JsonProperty("statLevelUpsAdditive")]
        private Dictionary<int, bool> _statLevelUpsAdditive;

        /// <summary>
        /// creates properties that are not created during deserialization. They are set later with the raw-values with the multipliers applied.
        /// </summary>
        [OnDeserialized]
        private void Initialize(StreamingContext _) => Initialize();

        private static string[] _ignoreVariantInName;

        /// <summary>
        /// Used as prefix for the sort name if marked as favorite.
        /// </summary>
        public const string FavoritePrefix = "!fav_";

        public void Initialize()
        {
            // TODO: Base species are maybe not used in game and may only lead to confusion (e.g. Giganotosaurus).

            if (string.IsNullOrEmpty(blueprintPath)) return; // blueprint path is needed for identification

            InitializeNames();

            stats = new SpeciesStat[Stats.StatsCount];
            var altStatsExist = altBaseStatsRaw?.Any() == true;
            if (altStatsExist)
                altStats = new SpeciesStat[Stats.StatsCount];

            var fullStatsRawLength = fullStatsRaw?.Length ?? 0;

            _skipWildLevelStatsWithServerSettings = skipWildLevelStats & ~CanHaveWildLevelExceptions.GetWildLevelExceptions(name);
            usedStats = 0;

            if (statImprintMult == null)
                statImprintMult = StatImprintMultipliersDefaultAse;

            StatImprintMultipliers = statImprintMult.ToArray();
            if (mutationMult == null) mutationMult = MutationMultipliersDefault;

            double[][] completeRaws = new double[Stats.StatsCount][];
            for (int s = 0; s < Stats.StatsCount; s++)
            {
                var usesStat = false;

                if (fullStatsRawLength > s && fullStatsRaw[s] != null)
                {
                    usesStat = true;
                    stats[s] = new SpeciesStat();
                    if (altStatsExist)
                    {
                        if (altBaseStatsRaw.ContainsKey(s))
                            altStats[s] = new SpeciesStat();
                        else altStats[s] = stats[s];
                    }

                    completeRaws[s] = new double[] { 0, 0, 0, 0, 0 };

                    for (int i = 0; i < 5; i++)
                    {
                        if (fullStatsRaw[s].Length > i)
                        {
                            completeRaws[s][i] = fullStatsRaw[s]?[i] ?? 0;
                        }
                    }

                    // For the taming multiplicative bonus Ark ignores values <0 and handles them like they're 0.
                    if (completeRaws[s][StatsRawIndexMultiplicativeBonus] < 0)
                        completeRaws[s][StatsRawIndexMultiplicativeBonus] = 0;

                    stats[s].IncreaseStatAsPercentage = _statLevelUpsAdditive?.TryGetValue(s, out var useAdditive) != true || !useAdditive;
                    stats[s].ValueCap = _statCaps?.TryGetValue(s, out var cap) == true ? cap : double.MaxValue;
                }

                var statBit = (1 << s);
                if (usesStat)
                    usedStats |= statBit;
                else
                    _skipWildLevelStatsWithServerSettings |= statBit;
            }

            if (fullStatsRawLength != 0)
                fullStatsRaw = completeRaws;

            if (DisplayedStats == -1 && usedStats != 0)
                DisplayedStats = usedStats;

            if (colors?.Length == 0)
                colors = null;
            if (colors != null && colors.Length < Ark.ColorRegionCount)
            {
                var allColorRegions = new ColorRegion[Ark.ColorRegionCount];
                colors.CopyTo(allColorRegions, 0);
                colors = allColorRegions;
            }

            if (boneDamageAdjusters != null && boneDamageAdjusters.Any())
            {
                // cleanup boneDamageMultipliers. Remove duplicates. Improve names.
                var boneDamageAdjustersCleanedUp = new Dictionary<string, double>();
                Regex rCleanBoneDamage = new Regex(@"(^r_|^l_|^c_|Cnt_|JNT|Jnt|\d+|SKL|_L$|_R$|_M$)");
                Regex rBoneDamageHyphen = new Regex(@"(?<=[A-Za-z])_+(?=[A-Za-z])");
                foreach (KeyValuePair<string, double> bd in boneDamageAdjusters)
                {
                    string boneName = rBoneDamageHyphen.Replace(
                            rCleanBoneDamage.Replace(bd.Key, ""),
                            "-")
                        .Replace("_", "");
                    if (boneName.Length > 1)
                        boneName = boneName.Substring(0, 1).ToUpper() + boneName.Substring(1);
                    boneDamageAdjustersCleanedUp[boneName] = Math.Round(bd.Value, 2);
                }
                boneDamageAdjusters = boneDamageAdjustersCleanedUp;
            }

            IsDomesticable = (taming != null && (taming.nonViolent || taming.violent))
                             || (breeding != null && (breeding.incubationTime > 0 || breeding.gestationTime > 0));

            matesWith = matesWith?.Select(bp => bp.EndsWith("_C") ? bp.Substring(0, bp.Length - 2) : bp).ToArray();
        }

        /// <summary>
        /// Default values for the stat imprint multipliers in ASE
        /// </summary>
        internal static readonly double[] StatImprintMultipliersDefaultAse = { 0.2, 0, 0.2, 0, 0.2, 0.2, 0, 0.2, 0.2, 0.2, 0, 0 };

        /// <summary>
        /// Default values for the mutated levels multipliers.
        /// </summary>
        private static readonly float[] MutationMultipliersDefault = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

        /// <summary>
        /// Sets the name, descriptive name and variant info.
        /// </summary>
        public void InitializeNames()
        {
            string variantInfoForName = null;
            if (variants != null && variants.Any())
            {
                var ignoreVariants = _getIgnoreVariantInName();
                VariantInfo = string.Join(", ", variants);
                variantInfoForName = string.Join(", ", string.IsNullOrEmpty(name) ? variants : variants.Where(v => !name.Contains(v) && !ignoreVariants.Contains(v)));
            }

            VariantInfo = string.IsNullOrEmpty(variantInfoForName) ? null : " (" + variantInfoForName + ")";
            DescriptiveName = name + VariantInfo;

            string modSuffix = _mod?.ShortTitle ?? _mod?.Title;
            ModSuffix = string.IsNullOrEmpty(modSuffix) ? string.Empty : " (" + modSuffix + ")";
            DescriptiveNameAndMod = DescriptiveName + ModSuffix;
            SortName = DescriptiveNameAndMod;
        }

        /// <summary>
        /// Sets the ArkColor objects for the natural occurring colors. Call after colors are loaded or changed by loading mods.
        /// </summary>
        public void InitializeColors(ArkColors arkColors)
        {
            if (colors != null)
            {
                for (int i = 0; i < Ark.ColorRegionCount; i++)
                    colors[i]?.Initialize(arkColors);
            }

            InitializeColorRegions();
        }

        /// <summary>
        /// Sets which color regions are enabled. Call after Properties.Settings.Default.HideInvisibleColorRegions was changed.
        /// </summary>
        public void InitializeColorRegions()
        {
            EnabledColorRegions = colors != null && !Properties.Settings.Default.AlwaysShowAllColorRegions
                ? colors.Select(n =>
                      !string.IsNullOrEmpty(n?.name) && (!n.invisible || !Properties.Settings.Default.HideInvisibleColorRegions)
                ).ToArray()
                : new[] { true, true, true, true, true, true, };
        }

        /// <summary>
        /// Array indicating which color regions are used by this species.
        /// </summary>
        public bool[] EnabledColorRegions;

        /// <summary>
        /// The default stat imprinting multipliers.
        /// </summary>
        public double[] StatImprintingMultipliersDefault => statImprintMult;

        /// <summary>
        /// Sets the stat imprinting multipliers to custom values. If null is passed, the default values are used.
        /// </summary>
        /// <param name="overrides"></param>
        public void SetCustomImprintingMultipliers(double?[] overrides)
        {
            if (overrides == null)
            {
                statImprintMultOverride = null;
                return;
            }

            // if a value is null, use the default value
            double[] overrideValues = new double[Stats.StatsCount];

            // if value is equal to default, set override to null
            bool isEqual = true;
            for (int s = 0; s < Stats.StatsCount; s++)
            {
                if (overrides[s] == null)
                {
                    overrideValues[s] = statImprintMult[s];
                    continue;
                }
                overrideValues[s] = overrides[s].Value;
                if (statImprintMult[s] != overrideValues[s])
                {
                    isEqual = false;
                }
            }
            if (isEqual) statImprintMultOverride = null;
            else statImprintMultOverride = overrideValues;
            StatImprintMultipliers = statImprintMultOverride ?? statImprintMult.ToArray();
        }

        /// <summary>
        /// Sets the usesStats and imprinting values according to the global settings. Call this method after calling SetCustomImprintingMultipliers() if the latter is needed.
        /// </summary>
        public void ApplyCanLevelOptions(bool canLevelSpeedStat, bool canFlyerLevelSpeedStat)
        {
            var statBit = (1 << Stats.SpeedMultiplier);

            bool speedStatCanBeLeveled = canLevelSpeedStat && (canFlyerLevelSpeedStat || !IsFlyer);
            if (speedStatCanBeLeveled)
            {
                DisplayedStats |= statBit;
                StatImprintMultipliers[Stats.SpeedMultiplier] =
                    (statImprintMultOverride ?? statImprintMult)[Stats.SpeedMultiplier];
                _skipWildLevelStatsWithServerSettings &= ~statBit;
            }
            else
            {
                DisplayedStats &= ~statBit;
                StatImprintMultipliers[Stats.SpeedMultiplier] = 0;
                _skipWildLevelStatsWithServerSettings |= statBit;
            }
        }

        /// <summary>
        /// Returns if the species uses a stat, i.e. it has a base value > 0.
        /// </summary>
        public bool UsesStat(int statIndex) => (usedStats & (1 << statIndex)) != 0;

        /// <summary>
        /// Returns if the species displays a stat ingame in the inventory.
        /// </summary>
        public bool DisplaysStat(int statIndex) => (DisplayedStats & (1 << statIndex)) != 0;

        /// <summary>
        /// Returns if a spawned creature can have wild or mutated levels in a stat.
        /// If Ark.IgnoreSkipWildLevelFlags is true, this method will always return true.
        /// </summary>
        public bool CanLevelUpWildOrHaveMutations(int statIndex) => (_skipWildLevelStatsWithServerSettings & (1 << statIndex)) == 0;

        public override string ToString()
        {
            return DescriptiveNameAndMod ?? name;
        }

        public override int GetHashCode()
        {
            return blueprintPath.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            return obj is Species other && !string.IsNullOrEmpty(other.blueprintPath) && other.blueprintPath == blueprintPath;
        }

        public static bool operator ==(Species a, Species b)
        {
            if (a is null)
                return b is null;

            return ReferenceEquals(a, b) || a.Equals(b);
        }

        public static bool operator !=(Species a, Species b) => !(a == b);

        public Mod Mod
        {
            set
            {
                _mod = value;
                InitializeNames();
            }
            get => _mod;
        }

        /// <summary>
        /// True if the species has any alternative stats (due to the troodonism bug).
        /// </summary>
        public bool HasAltStats => altBaseStatsRaw?.Any() == true;

        /// <summary>
        /// Returns an array of colors for a creature of this species with the naturally occurring colors.
        /// </summary>
        public byte[] RandomSpeciesColors(Random rand = null)
        {
            if (rand == null) rand = new Random();

            var randomColors = new byte[Ark.ColorRegionCount];
            for (int ci = 0; ci < Ark.ColorRegionCount; ci++)
            {
                if (!EnabledColorRegions[ci]) continue;
                var colorCount = colors?[ci]?.naturalColors?.Count ?? 0;
                if (colorCount == 0)
                    randomColors[ci] = (byte)(6 + rand.Next(100));
                else randomColors[ci] = colors[ci].naturalColors[rand.Next(colorCount)].Id;
            }

            return randomColors;
        }

        /// <summary>
        /// Override provided properties of the species, e.g. from a mod values file. This is only done if the blueprint path is the same.
        /// </summary>
        public void LoadOverrides(Species overrides)
        {
            if (overrides.name != null) name = overrides.name;
            if (overrides.nameFemale != null) name = overrides.nameFemale;
            if (overrides.nameMale != null) name = overrides.nameMale;
            if (overrides.variants != null) variants = overrides.variants;
            if (overrides.fullStatsRaw != null) fullStatsRaw = overrides.fullStatsRaw;
            if (overrides.altBaseStatsRaw != null) altBaseStatsRaw = overrides.altBaseStatsRaw;
            if (overrides.DisplayedStats != -1) DisplayedStats = overrides.DisplayedStats;
            if (overrides.skipWildLevelStats != 0) skipWildLevelStats = overrides.skipWildLevelStats;
            if (overrides.TamedBaseHealthMultiplier != null) TamedBaseHealthMultiplier = overrides.TamedBaseHealthMultiplier;
            if (overrides.statImprintMult != null && overrides.statImprintMult != StatImprintMultipliersDefaultAse) statImprintMult = overrides.statImprintMult.ToArray();
            if (overrides.mutationMult != null) mutationMult = overrides.mutationMult;
            if (overrides.colors != null) colors = overrides.colors;
            if (overrides.taming != null) taming = overrides.taming;
            if (overrides.breeding != null) breeding = overrides.breeding;
            if (overrides.boneDamageAdjusters != null) boneDamageAdjusters = overrides.boneDamageAdjusters;
            if (overrides.immobilizedBy != null) immobilizedBy = overrides.immobilizedBy;
            if (overrides.statNames != null) statNames = overrides.statNames;
            if (overrides.isFlyer != null) isFlyer = overrides.isFlyer;
            if (overrides.noGender != null) noGender = overrides.noGender;
            if (overrides.matesWith != null) matesWith = overrides.matesWith;
            if (overrides._statLevelUpsAdditive != null) _statLevelUpsAdditive = overrides._statLevelUpsAdditive;
            if (overrides._statCaps != null) _statCaps = overrides._statCaps;

            Initialize(new StreamingContext());
        }

        /// <summary>
        /// Index of the base value in fullStatsRaw.
        /// </summary>
        public const int StatsRawIndexBase = 0;

        /// <summary>
        /// Index of the increase per wild level value in fullStatsRaw.
        /// </summary>
        public const int StatsRawIndexIncPerWildLevel = 1;

        /// <summary>
        /// Index of the increase per dom level value in fullStatsRaw.
        /// </summary>
        public const int StatsRawIndexIncPerDomLevel = 2;

        /// <summary>
        /// Index of the additive bonus value in fullStatsRaw.
        /// </summary>
        public const int StatsRawIndexAdditiveBonus = 3;

        /// <summary>
        /// Index of the multiplicative bonus value in fullStatsRaw.
        /// </summary>
        public const int StatsRawIndexMultiplicativeBonus = 4;

        /// <summary>
        /// Returns species name depending on sex if available.
        /// </summary>
        /// <param name="creatureSex"></param>
        /// <returns></returns>
        public string Name(Sex creatureSex, bool variantInfo = false, bool modInfo = false)
        {
            var suffix = (variantInfo ? VariantInfo : string.Empty) + (modInfo ? ModSuffix : string.Empty);
            return creatureSex switch
            {
                Sex.Female => (nameFemale ?? name) + suffix,
                Sex.Male => (nameMale ?? name) + suffix,
                _ => name + suffix
            };
        }

        private static string[] _getIgnoreVariantInName()
        {
            if (_ignoreVariantInName != null) return _ignoreVariantInName;

            var filePath = FileService.GetJsonPath(FileService.HideVariantsInSpeciesNameFile);
            _ignoreVariantInName = !File.Exists(filePath) ? Array.Empty<string>() : File.ReadAllLines(filePath).Where(l => !string.IsNullOrEmpty(l)).ToArray();
            return _ignoreVariantInName;
        }

        public static void ClearIgnoreVariantsInName() => _ignoreVariantInName = null;
    }
}
