﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using ARKBreedingStats.mods;
using ARKBreedingStats.species;
using ARKBreedingStats.utils;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ARKBreedingStats.values
{
    [JsonObject(MemberSerialization.OptIn)]
    public class ValuesFile
    {
        /// <summary>
        /// Checks if the version string is a format version that is supported by the version of this application.
        /// </summary>
        protected static bool IsValidFormatVersion(string formatVersion) =>
            formatVersion == "1.12" // format with 12 stats (minimum required format)
            || formatVersion == "1.13" // introduced remaps for blueprintPaths
            || formatVersion == "1.14-flyerspeed" // introduced isFlyer property for AllowFlyerSpeedLeveling
            || formatVersion == "1.15-asa" // for new properties in ARK: Survival Ascended
            || formatVersion == "1.16-mod-remap" // support for blueprint remap for mod files
            ;

        [JsonProperty("version")]
        private string _version;
        public Version Version;

        /// <summary>
        /// Must be present and a supported value. Defaults to an invalid value
        /// </summary>
        [JsonProperty("format")]
        public string Format { get; private set; }

        [JsonProperty("species")]
        public List<Species> Species;

        /// <summary>
        /// If not zero it indicates the values file contains new dye definitions that should overwrite the existing base definitions.
        /// </summary>
        [JsonProperty("dyeStartIndex")]
        public int DyeStartIndex;

        [JsonProperty("colorDefinitions")]
        private object[][] _colorDefinitions;

        [JsonProperty("dyeDefinitions")]
        private object[][] _dyeDefinitions;

        internal List<ArkColor> ArkColorsDyesParsed;

        /// <summary>
        /// If a species for a blueprintPath is requested, the blueprintPath will be remapped if an according key is present.
        /// This is needed if species are remapped ingame, e.g. if a variant is removed.
        /// </summary>
        [JsonProperty("remaps")]
        public Dictionary<string, string> BlueprintRemapping;

        /// <summary>
        /// If this represents values for a mod, the mod-infos are found here.
        /// </summary>
        [JsonProperty("mod")]
        public Mod Mod;

        [OnDeserialized]
        private void ParseVersionAndColors(StreamingContext _)
        {
            Version = Utils.TryParseVersionAlsoWithOnlyMajor(_version);

            ArkColorsDyesParsed = ArkColors.ParseColorDefinitions(_colorDefinitions, ArkColorsDyesParsed);
            ArkColorsDyesParsed = ArkColors.ParseColorDefinitions(_dyeDefinitions, ArkColorsDyesParsed, true);

            //// for debugging, test if there are duplicates in the species-names
            //var duplicateSpeciesNames = string.Join("\n", species
            //                                   //.GroupBy(s => s.DescriptiveName)
            //                                   .GroupBy(s => s.NameAndMod)
            //                                   .Where(g => g.Count() > 1)
            //                                   .Select(x => x.Key)
            //                                   .ToArray());
            //if (!string.IsNullOrEmpty(duplicateSpeciesNames))
            //    utils.ClipboardHandler.SetText(duplicateSpeciesNames);
        }

        protected static Values LoadBaseValuesFile(string filePath)
        {
            if (FileService.LoadJsonFile(filePath, out Values readData, out string errorMessage))
            {
                if (!IsValidFormatVersion(readData.Format)) throw new FormatException($"Unsupported values format version: {(readData.Format ?? "null")}");
                return readData;
            }
            throw new FileLoadException(errorMessage);
        }

        protected static ValuesFile LoadValuesFile(string filePath)
        {
            if (FileService.LoadJsonFile(filePath, out ValuesFile readData, out string errorMessage))
            {
                if (!IsValidFormatVersion(readData.Format)) throw new FormatException($"Unsupported values format version: {(readData.Format ?? "null")}");
                return readData;
            }
            throw new FileLoadException(errorMessage);
        }

        /// <summary>
        /// Tries to load a mod file.
        /// If the mod-values will be used, setModFileName should be true.
        /// If the file cannot be found or the format is wrong, the file is ignored and no exception is thrown if throwExceptionOnFail is false.
        /// </summary>
        internal static bool TryLoadValuesFile(string filePath, bool setModFileName, bool throwExceptionOnFail, out ValuesFile values, out string errorMessage, bool checkIfModPropertyIsExisting = false)
        {
            values = null;
            errorMessage = null;
            try
            {
                values = LoadValuesFile(filePath);
                if (checkIfModPropertyIsExisting && string.IsNullOrEmpty(values.Mod?.Id))
                {
                    errorMessage =
                        $"The mod file\n{filePath}\ndoesn't contains an object \"mod\" or that object doesn't contain a valid entry \"id\". The mod file cannot be loaded until this information is added";
                    return false;
                }
                if (setModFileName) values.Mod.FileName = Path.GetFileName(filePath);

                return true;
            }
            catch (FileNotFoundException ex)
            {
                errorMessage = "Values-File '" + filePath + "' not found. "
                               + "This collection seems to have modified stat values that are saved in a separate file, "
                               + "which couldn't be found at the saved location.";
                if (throwExceptionOnFail)
                    throw new FileNotFoundException(errorMessage, ex);
            }
            catch (FormatException ex)
            {
                errorMessage = "Values-File '" + filePath + $"' has an invalid version.\n{ex.Message}\nTry updating ARK Smart Breeding.";
                if (throwExceptionOnFail)
                    throw new FormatException(errorMessage);
            }
            catch (FileLoadException ex)
            {
                errorMessage = ex.Message;
                if (throwExceptionOnFail)
                    throw;
            }
            return false;
        }

        /// <summary>
        /// Only loads the ModInfo header of a values file. This can be used if the other parts of the file are not needed.
        /// </summary>
        public static bool TryLoadingModInfoHeader(string filePath, out ModInfo modInfo)
        {
            modInfo = null;
            if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath)) return false;

            try
            {
                using (var fs = File.OpenRead(filePath))
                using (var sr = new StreamReader(fs))
                using (var jr = new JsonTextReader(sr) { SupportMultipleContent = false })
                {
                    // validate root
                    if (!jr.Read() || jr.TokenType != JsonToken.StartObject)
                    {
                        MessageBoxes.ShowMessageBox("Error while trying to read the json values file, no json root object found in" + Environment.NewLine + filePath);
                        return false;
                    }

                    modInfo = new ModInfo();
                    string currentProp = null;
                    while (jr.Read())
                    {
                        if (jr.TokenType == JsonToken.PropertyName)
                        {
                            currentProp = (string)jr.Value;
                            // if species array, no further reading needed (only the header is needed)
                            if (string.Equals(currentProp, "species", StringComparison.OrdinalIgnoreCase))
                                break;
                            continue; // move to token after property name
                        }
                        switch (currentProp)
                        {
                            case "version":
                                modInfo.Version = Utils.TryParseVersionAlsoWithOnlyMajor(jr.Value?.ToString());
                                break;
                            case "format":
                                modInfo.Format = jr.Value?.ToString();
                                break;
                            case "mod":
                                modInfo.Mod = JToken.ReadFrom(jr).ToObject<Mod>();
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBoxes.ExceptionMessageBox(ex,
                    "Error while trying to read the mod info header of the values file" + Environment.NewLine +
                    filePath);
                return false;
            }

            return true;
        }
    }
}
