﻿using ARKBreedingStats.species;
using ARKBreedingStats.utils;
using ARKBreedingStats.values;
using System;

namespace ARKBreedingStats
{
    public static class StatValueCalculation
    {
        //private const double ROUND_UP_DELTA = 0.0001; // remove for now. Rounding issues should be handled during extraction with value-ranges.

        /// <summary>
        /// Calculate the stat value.
        /// </summary>
        public static double CalculateValue(Species species, int statIndex, int levelWild, int levelMut, int levelDom,
            bool dom, double tamingEff = 0, double imprintingBonus = 0, bool roundToIngamePrecision = true,
            Troodonism.AffectedStats useTroodonismStats = Troodonism.AffectedStats.None)
        {
            if (species?.stats == null) return 0;

            var speciesStat = useTroodonismStats == Troodonism.AffectedStats.None
                ? species.stats[statIndex]
                : Troodonism.SelectStats(species.stats[statIndex], species.altStats[statIndex], useTroodonismStats);

            if (speciesStat == null) return 0;

            // if stat is generally available but level is set to -1 (== unknown), return -1 (== unknown)
            if (levelWild < 0 && speciesStat.IncPerWildLevel != 0)
                return -1;

            double add = 0, domMult = 1, imprintingM = 1, tamedBaseHP = 1;
            if (dom)
            {
                add = speciesStat.AddWhenTamed;
                double domMultAffinity = speciesStat.MultAffinity;
                // the multiplicative bonus is only multiplied with the TE if it is positive (i.e. negative boni won't get less bad if the TE is low)
                if (domMultAffinity >= 0)
                    domMultAffinity *= tamingEff;
                domMult = tamingEff >= 0 ? 1 + domMultAffinity : 1;
                if (imprintingBonus > 0
                    && species.StatImprintMultipliers[statIndex] != 0
                    )
                    imprintingM = 1 + species.StatImprintMultipliers[statIndex] * imprintingBonus * (Values.V.currentServerMultipliers?.BabyImprintingStatScaleMultiplier ?? 1);
                if (statIndex == Stats.Health)
                    tamedBaseHP = species.TamedBaseHealthMultiplier ?? 1;
            }
            else
            {
                levelDom = 0;
            }
            //double result = Math.Round((stats.BaseValue * tamedBaseHP * (1 + stats.IncPerWildLevel * levelWild) * imprintingM + add) * domMult, Utils.precision(stat), MidpointRounding.AwayFromZero);
            // double is too precise and results in wrong values due to rounding. float results in better values, probably ARK uses float as well.
            // or rounding first to a precision of 7, then use the rounding of the precision
            //double resultt = Math.Round((stats.BaseValue * tamedBaseHP * (1 + stats.IncPerWildLevel * levelWild) * imprintingM + add) * domMult, 7);
            //resultt = Math.Round(resultt, Utils.precision(stat), MidpointRounding.AwayFromZero);

            var wildLevelIncrease = levelWild * speciesStat.IncPerWildLevel +
                                    levelMut * speciesStat.IncPerMutatedLevel;
            var domLevelIncrease = levelDom * speciesStat.IncPerTamedLevel;

            var result = speciesStat.IncreaseStatAsPercentage
                ? (speciesStat.BaseValue * (1 + wildLevelIncrease) * tamedBaseHP * imprintingM + add) * domMult * (1 + domLevelIncrease)
                : ((speciesStat.BaseValue + wildLevelIncrease) * tamedBaseHP * imprintingM + add) * domMult + domLevelIncrease
                ;

            if (result <= 0) return 0;
            result = speciesStat.ApplyCap(result);

            if (roundToIngamePrecision)
                return Math.Round(result, Stats.Precision(statIndex), MidpointRounding.AwayFromZero);

            return result;
        }


        /// <summary>
        /// ARK uses float-types for the stats which have precision errors. This method returns the possible aberration of that value.
        /// </summary>
        /// <param name="displayedStatValue">Stat value</param>
        /// <param name="displayedDecimals">Percentage values have a higher precision, they display 3 decimal digits</param>
        /// <param name="highPrecisionInput">When obtained from an export file, stat values are given with more decimal digits.</param>
        public static float DisplayedAberration(double displayedStatValue, int displayedDecimals = 1, bool highPrecisionInput = false)
        {
            // ARK displays one decimal digit, so the minimal error of a given number is assumed to be 0.06.
            // the theoretical value of a maximal error of 0.05 is too low.
            const float arkDisplayValueError = 0.06f;
            // If an export file is used, the full float precision of the stat value is given, the precision is calculated then.
            // For values > 1e6 the float precision error is larger than 0.06

            // always consider at least an error of. When using only the float-precision often the stat-calculations increase the resulting error to be much larger.
            const float minValueError = 0.001f;

            // the error can increase due to the stat-calculation. Assume a factor of 10 for now, values lower than 6 were too low. ASA needs it set to at least 18, using 20 for now.
            const float calculationErrorFactor = 20;

            return highPrecisionInput || displayedStatValue * (displayedDecimals == 3 ? 100 : 1) > 1e6
                    ? Math.Max(minValueError, ((float)displayedStatValue).FloatPrecision() * calculationErrorFactor)
                    : arkDisplayValueError * (displayedDecimals == 3 ? .01f : 1);
        }
    }
}
