﻿using ARKBreedingStats.species;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ARKBreedingStats.library;
using ARKBreedingStats.utils;
using System.ComponentModel;

namespace ARKBreedingStats.uiControls
{
    public partial class RegionColorChooser : UserControl
    {
        /// <summary>
        /// Parameter indicates if colors were changed.
        /// </summary>
        public event Action<bool> RegionColorChosen;
        private readonly NoPaddingButton[] _buttonColors;
        private byte[] _selectedRegionColorIds;
        private byte[] _selectedColorIdsAlternative;
        public bool[] ColorRegionsUseds;
        private readonly ColorPickerWindow _colorPicker;
        private ColorRegion[] _colorRegions;
        private readonly ToolTip _tt = new ToolTip();
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        /// <summary>
        /// If true, the button text will display the region and color id.
        /// </summary>
        public bool VerboseButtonTexts { get; set; }

        public RegionColorChooser()
        {
            InitializeComponent();

            _buttonColors = new NoPaddingButton[Ark.ColorRegionCount];
            for (var i = 0; i < Ark.ColorRegionCount; i++)
            {
                var b = new NoPaddingButton { Width = 27, Height = 27, Margin = new Padding(1), Text = i.ToString() };
                var ii = i;
                b.Click += (s, e) => ChooseColor(ii, b);
                _buttonColors[i] = b;
                flowLayoutPanel1.Controls.Add(b);
            }

            _selectedRegionColorIds = new byte[Ark.ColorRegionCount];
            _selectedColorIdsAlternative = new byte[Ark.ColorRegionCount];

            _colorPicker = new ColorPickerWindow();
            _tt.AutoPopDelay = 7000;
            Disposed += RegionColorChooser_Disposed;
        }

        public void SetOneButtonPerRow(bool onePerRow)
        {
            foreach (var b in _buttonColors)
                flowLayoutPanel1.SetFlowBreak(b, onePerRow);
        }

        public void SetSpecies(Species species, byte[] colorIDs)
        {
            _selectedRegionColorIds = colorIDs.ToArray();
            _selectedColorIdsAlternative = null;

            if (species?.colors != null)
            {
                _colorRegions = species.colors;
                ColorRegionsUseds = species.EnabledColorRegions;
            }
            else
            {
                // species-info is not available, show all region-buttons
                ColorRegionsUseds = new bool[Ark.ColorRegionCount];
                _colorRegions = new ColorRegion[Ark.ColorRegionCount];
                for (int i = 0; i < Ark.ColorRegionCount; i++)
                {
                    _colorRegions[i] = new ColorRegion();
                    ColorRegionsUseds[i] = true;
                }
            }

            for (int r = 0; r < Ark.ColorRegionCount; r++)
            {
                _buttonColors[r].Visible = ColorRegionsUseds[r];

                if (ColorRegionsUseds[r])
                {
                    _buttonColors[r].AlternativeColorPossible = false;
                    SetColorButton(_buttonColors[r], r);
                }
            }
        }

        public byte[] ColorIds => _selectedRegionColorIds.ToArray();
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public byte[] ColorIdsAlsoPossible
        {
            get => _selectedColorIdsAlternative?.ToArray();
            set
            {
                _selectedColorIdsAlternative = value;
                if (_selectedColorIdsAlternative == null)
                {
                    foreach (var bt in _buttonColors)
                        bt.AlternativeColorPossible = false;

                    return;
                }
                for (int i = 0; i < Ark.ColorRegionCount; i++)
                    _buttonColors[i].AlternativeColorPossible = _selectedColorIdsAlternative.Length > i && _selectedColorIdsAlternative[i] != 0;
            }
        }

        public void Clear()
        {
            _selectedColorIdsAlternative = null;
            SetColorIds(new byte[Ark.ColorRegionCount]);
        }

        /// <summary>
        /// Set colors to random ids of the available colors.
        /// </summary>
        internal void RandomColors()
        {
            _selectedColorIdsAlternative = null;
            SetColorIds(values.Values.V.Colors.GetRandomColors());
        }

        /// <summary>
        /// Set colors to random values in the set of natural occurring colors of the species.
        /// </summary>
        internal void RandomNaturalColors(Species species)
        {
            _selectedColorIdsAlternative = null;
            SetColorIds(species?.RandomSpeciesColors());
        }

        private void SetColorIds(byte[] colorIds)
        {
            if (colorIds == null)
            {
                Clear();
                return;
            }

            for (var r = 0; r < Ark.ColorRegionCount; r++)
            {
                _selectedRegionColorIds[r] = colorIds.Length > r ? colorIds[r] : (byte)0;
                _buttonColors[r].AlternativeColorPossible = false;
                SetColorButton(_buttonColors[r], r);
            }
            RegionColorChosen?.Invoke(true);
        }

        private void ChooseColor(int region, Button sender)
        {
            if (_colorPicker.isShown || _colorRegions == null || region >= Ark.ColorRegionCount) return;

            _colorPicker.Cp.PickColor(_selectedRegionColorIds[region], _colorRegions[region]?.name + " (region " + region + ")", _colorRegions[region]?.naturalColors, _selectedColorIdsAlternative?[region] ?? 0);
            if (_colorPicker.ShowDialog() != DialogResult.OK) return;

            // color was chosen
            _selectedRegionColorIds[region] = _colorPicker.Cp.SelectedColorId;
            if (_colorPicker.Cp.SelectedColorIdAlternative != 0)
            {
                if (_selectedColorIdsAlternative == null)
                    _selectedColorIdsAlternative = new byte[Ark.ColorRegionCount];
                _selectedColorIdsAlternative[region] = _colorPicker.Cp.SelectedColorIdAlternative;
                _buttonColors[region].AlternativeColorPossible = true;
            }
            else
            {
                _buttonColors[region].AlternativeColorPossible = false;
                if (_selectedColorIdsAlternative != null)
                    _selectedColorIdsAlternative[region] = 0;
            }
            SetColorButton(sender, region);
            RegionColorChosen?.Invoke(true);
        }

        /// <summary>
        /// Select color that is set for all regions.
        /// </summary>
        internal void ChooseAllColors()
        {
            if (_colorPicker.isShown || _colorRegions == null) return;
            _colorPicker.Cp.PickColor(_selectedRegionColorIds[0], "all regions");
            if (_colorPicker.ShowDialog() != DialogResult.OK) return;
            SetColorIds(Enumerable.Repeat(_colorPicker.Cp.SelectedColorId, Ark.ColorRegionCount).ToArray());
        }

        private void SetColorButton(Button bt, int region)
        {
            byte colorId = _selectedRegionColorIds[region];
            bt.SetBackColorAndAccordingForeColor(CreatureColors.CreatureColor(colorId));
            if (VerboseButtonTexts)
                bt.Text = $"[{region}]: {colorId}";
            else if (Properties.Settings.Default.ShowColorIdOnRegionButtons)
                bt.Text = colorId.ToString();
            else bt.Text = region.ToString();
            // tooltip
            _tt.SetToolTip(bt, $"[{region}] {_colorRegions?[region]?.name}:\n{colorId}: {CreatureColors.CreatureColorName(colorId)}");
        }

        private void RegionColorChooser_Disposed(object sender, EventArgs e) => _tt.RemoveAllAndDispose();

        /// <summary>
        /// True if a color is new in this species.
        /// </summary>
        internal bool ColorNewInSpecies;
        /// <summary>
        /// True if color is new in this region (but exists in other region in this species).
        /// </summary>
        internal bool ColorNewInRegion;

        internal void SetRegionColorsExisting(LevelColorStatusFlags.ColorStatus[] colorAlreadyAvailable)
        {
            ColorNewInRegion = false;
            ColorNewInSpecies = false;

            var parameter = LevelColorStatusFlags.ColorStatus.None;
            for (int ci = 0; ci < Ark.ColorRegionCount; ci++)
            {
                if (colorAlreadyAvailable != null)
                    parameter = colorAlreadyAvailable[ci];
                switch (parameter)
                {
                    case LevelColorStatusFlags.ColorStatus.NewColor:
                        _buttonColors[ci].ColorStatus = LevelColorStatusFlags.ColorStatus.NewColor;
                        ColorNewInSpecies = true;
                        break;
                    case LevelColorStatusFlags.ColorStatus.NewRegionColor:
                        _buttonColors[ci].ColorStatus = LevelColorStatusFlags.ColorStatus.NewRegionColor;
                        ColorNewInRegion = true;
                        break;
                    default:
                        _buttonColors[ci].ColorStatus = LevelColorStatusFlags.ColorStatus.ExistsInRegion;
                        break;
                }
                _buttonColors[ci].Invalidate();
            }
        }

        private class NoPaddingButton : Button
        {
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            public LevelColorStatusFlags.ColorStatus ColorStatus { get; set; }
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            public bool AlternativeColorPossible { get; set; }

            public NoPaddingButton()
            {
                FlatStyle = FlatStyle.Flat;
                FlatAppearance.BorderSize = 0;
            }

            protected override void OnPaint(PaintEventArgs pe)
            {
                Color statusColor;
                switch (ColorStatus)
                {
                    case LevelColorStatusFlags.ColorStatus.NewColor:
                        statusColor = Color.Gold;
                        break;
                    case LevelColorStatusFlags.ColorStatus.NewRegionColor:
                        statusColor = Color.DarkGreen;
                        break;
                    default:
                        statusColor = SystemColors.Control;
                        break;
                }

                using (var b = new SolidBrush(statusColor))
                {
                    var defaultVisibleRectangle = ClientRectangle;
                    var shrinkStatus = -4;
                    if (AlternativeColorPossible)
                    {
                        b.Color = Color.Red;
                        pe.Graphics.FillRectangle(b, defaultVisibleRectangle);
                        defaultVisibleRectangle.Inflate(-1, -1);
                        shrinkStatus = -3;
                    }
                    b.Color = statusColor;
                    pe.Graphics.FillRectangle(b, defaultVisibleRectangle);

                    b.Color = Color.Gray;
                    defaultVisibleRectangle.Inflate(shrinkStatus, shrinkStatus);
                    pe.Graphics.FillRectangle(b, defaultVisibleRectangle);
                    defaultVisibleRectangle.Inflate(-1, -1);
                    b.Color = BackColor;
                    pe.Graphics.FillRectangle(b, defaultVisibleRectangle);
                }

                if (string.IsNullOrEmpty(Text)) return;
                StringFormat stringFormat = new StringFormat();
                stringFormat.Alignment = StringAlignment.Center;
                stringFormat.LineAlignment = StringAlignment.Center;
                using (var b = new SolidBrush(ForeColor))
                    pe.Graphics.DrawString(Text, Font, b, ClientRectangle, stringFormat);
            }
        }

    }
}
